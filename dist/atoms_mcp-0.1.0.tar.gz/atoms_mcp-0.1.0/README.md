# Atoms MCP - Knowledge Management System

Multi-tenant knowledge management system with requirements tracking, test management, and AI-powered search capabilities.

## Quick Start

```bash
# Install dependencies (creates .venv)
uv sync

# Set environment variables
export SUPABASE_URL="https://ydogoylwenufckscqijp.supabase.co"
export SUPABASE_SERVICE_ROLE_KEY="your-key"

# Optional: point to a custom YAML config (defaults live in config/atoms-mcp.yaml)
# export ATOMS_SETTINGS_FILE="$(pwd)/config/atoms-mcp.yaml"

# Endpoint selection: environment switch (default = production / https://mcp.atoms.tech)
#   local  -> https://atomcp.kooshapari.com
#   dev    -> https://devmcp.atoms.tech
#   preview-> https://devmcp.atoms.tech
#   prod   -> https://mcp.atoms.tech
# export ATOMS_TARGET_ENVIRONMENT=local

# Start server
python start_atoms.sh
```

## CLI Shortcuts

```bash
./atoms start             # Launch local server with defaults
./atoms deploy            # Deploy to production (mcp.atoms.tech)
./atoms deploy dev        # Deploy to preview (devmcp.atoms.tech)
./atoms test local cold   # Run "cold" markers against the local stack
./atoms stats cloc        # Code statistics with cloc (honors .clocignore)
./atoms stats vulture     # Check for unused code via vulture
```

## Documentation

### User Documentation
- **[Quick Start Guide](docs/QUICK_START.md)** - Get up and running in 5 minutes
- **[User Guide](docs/USER_GUIDE.md)** - Comprehensive user documentation with examples
- **[API Reference](docs/API_REFERENCE.md)** - Complete API documentation for all tools

### Developer Documentation
- **[Developer Guide](docs/DEVELOPER_GUIDE.md)** - Architecture, development, and contribution guide
- **[Architecture Guide](docs/ARCHITECTURE.md)** - System architecture and design patterns
- **[Schema Reference](docs/SCHEMA_REFERENCE.md)** - Database schemas, types, and data models

### Additional Resources
- **[Schema Documentation](docs/schema/)** - RLS, triggers, sync system
- **[Deployment Guides](docs/deployment/)** - Vercel, WorkOS, 3-tier setup

## Archive & Inventory

- `archive/CONSOLIDATION_SUMMARY.md` – running log of every file moved to the archive.
- `archive/FULL_FILEBASE_INVENTORY_2025-10-25.md` – depth survey of the post-cleanup tree so future consolidations know what belongs where.

## Features

✅ Multi-tenant organization management
✅ Requirements tracking with INCOSE/EARS formats
✅ Test management and traceability
✅ Document blocks with properties
✅ Vector semantic search
✅ Full-text search
✅ OAuth 2.0 authentication
✅ Row-level security
✅ Real-time updates

## Architecture

- **FastAPI/FastMCP** - MCP server
- **Supabase** - PostgreSQL database with vector extensions
- **WorkOS AuthKit** - OAuth authentication
- **Type-safe schemas** - TypedDict + Pydantic validation
- **RLS validation** - Server-side permission checks
- **Trigger emulation** - Client-side data transformation

## Development

```bash
# Run tests
pytest tests/ -v

# Check schema sync
python scripts/sync_schema.py --check

# Sync with database
python scripts/sync_schema.py --update
```

## License

MIT
