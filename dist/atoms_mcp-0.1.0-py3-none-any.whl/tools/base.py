"""Base functionality for consolidated tools."""

from __future__ import annotations

from typing import Any

from utils.logging_setup import get_logger

# Support both package and standalone imports
try:
    from errors import normalize_error

    from infrastructure.factory import get_adapters
    from schemas.constants import ENTITY_TABLE_MAP
except ImportError:
        # Mock implementations for type checking
        class ApiError(Exception):
            def __init__(self, code: str, message: str, status: int = 500, details: Any | None = None):
                super().__init__(message)
                self.code = code
                self.message = message
                self.status = status
                self.details = details

        def normalize_error(err: Exception | str, fallback_message: str) -> ApiError:  # type: ignore
            if isinstance(err, str):
                return ApiError(code="INTERNAL_SERVER_ERROR", message=fallback_message)
            return ApiError(code="INTERNAL_SERVER_ERROR", message=str(err) or fallback_message)

        def get_adapters() -> dict[str, Any]:
            return {}

        ENTITY_TABLE_MAP = {}

logger = get_logger(__name__)


class ToolBase:
    """Base class for consolidated tools with common functionality."""

    def __init__(self):
        self._adapters = None
        self._user_context = {}

    def _get_adapters(self) -> dict[str, Any]:
        """Get adapters, cached."""
        if self._adapters is None:
            self._adapters = get_adapters()
        return self._adapters

    async def _validate_auth(self, auth_token: str) -> dict[str, Any]:
        """Validate authentication token and return user info.

        Also sets user's JWT on database adapter for proper RLS context.
        """
        # No fallback - require valid authentication
        if auth_token == "oauth-session" or not auth_token:
            raise ValueError("Authentication required: user_id not found in token claims")

        try:
            adapters = self._get_adapters()
            user_info = await adapters["auth"].validate_token(auth_token)

            # ✅ Set user's access token on database adapter for RLS
            # This ensures auth.uid() returns the correct user ID in database queries
            if access_token := user_info.get("access_token"):
                adapters["database"].set_access_token(access_token)

            # Cache user context for this operation
            self._user_context = user_info
            return user_info

        except Exception as e:
            error: Exception = normalize_error(e, "Authentication failed")
            raise error

    def _get_user_id(self) -> str:
        """Get current user ID from context."""
        return self._user_context.get("user_id", "")

    def _get_username(self) -> str:
        """Get current username from context."""
        return self._user_context.get("username", "")

    @property
    def supabase(self):
        """Get Supabase client from adapters."""
        try:
            adapters = self._get_adapters()
            db_adapter = adapters["database"]
            # Use the _get_client method from SupabaseDatabaseAdapter
            return db_adapter._get_client()
        except Exception:
            # Fallback: try to get it directly from supabase_client module
            try:
                from supabase_client import get_supabase
                return get_supabase()
            except Exception as e:
                raise RuntimeError(f"Could not get Supabase client: {e}")

    async def _db_query(self, table: str, **kwargs) -> list:
        """Execute database query."""
        try:
            adapters = self._get_adapters()
            return await adapters["database"].query(table, **kwargs)
        except Exception as e:
            error: Exception = normalize_error(e, f"Database query failed for table {table}")
            raise error

    async def _db_get_single(self, table: str, **kwargs) -> dict[str, Any] | None:
        """Get single record from database."""
        try:
            adapters = self._get_adapters()
            return await adapters["database"].get_single(table, **kwargs)
        except Exception as e:
            error: Exception = normalize_error(e, f"Database get_single failed for table {table}")
            raise error

    async def _db_insert(self, table: str, data: Any, **kwargs) -> Any:
        """Insert record(s) into database."""
        try:
            adapters = self._get_adapters()
            return await adapters["database"].insert(table, data, **kwargs)
        except Exception as e:
            error: Exception = normalize_error(e, f"Database insert failed for table {table}")
            raise error

    async def _db_update(self, table: str, data: dict[str, Any], filters: dict[str, Any], **kwargs) -> Any:
        """Update record(s) in database."""
        try:
            adapters = self._get_adapters()
            return await adapters["database"].update(table, data, filters, **kwargs)
        except Exception as e:
            error: Exception = normalize_error(e, f"Database update failed for table {table}")
            raise error

    async def _db_delete(self, table: str, filters: dict[str, Any]) -> int:
        """Delete record(s) from database."""
        try:
            adapters = self._get_adapters()
            return await adapters["database"].delete(table, filters)
        except Exception as e:
            raise normalize_error(e, f"Database delete failed for table {table}")

    async def _db_count(self, table: str, filters: dict[str, Any] | None = None) -> int:
        """Count records in database table."""
        try:
            adapters = self._get_adapters()
            return await adapters["database"].count(table, filters)
        except Exception as e:
            raise normalize_error(e, f"Database count failed for table {table}")

    def _resolve_entity_table(self, entity_type: str) -> str:
        """Map entity type to database table name."""
        table = ENTITY_TABLE_MAP.get(entity_type.lower())
        if not table:
            raise ValueError(f"Unknown entity type: {entity_type}")
        return table

    def _sanitize_entity(self, entity: dict[str, Any]) -> dict[str, Any]:
        """Remove large fields from entity to prevent token overflow.

        Strips out embedding vectors, large text fields, and nested structures
        while preserving essential identifying information.
        """
        if not entity:
            return {}

        # Fields to always exclude (commonly large or redundant)
        exclude_fields = {
            "embedding",  # Vector embeddings are huge (768 floats)
            "properties",  # Can contain arbitrary large nested data
            "metadata",  # Can be recursive
            "blocks",  # Large nested structures
            "requirements",  # Large arrays
            "tests",  # Large arrays
            "trace_links",  # Large arrays
            "ai_analysis",  # Can be very large with history
            "fts_vector",  # Full-text search vectors
            "content",  # Document content can be huge
            "description",  # Descriptions can be very long
            "preferences",  # User preferences object
        }

        # Keep only essential fields
        sanitized: dict[str, Any] = {}
        for key, value in entity.items():
            if key in exclude_fields:
                continue

            # Skip None values
            if value is None:
                continue

            # Include primitives and small values
            if isinstance(value, (str, int, float, bool)):
                # Limit string length more aggressively
                if isinstance(value, str) and len(value) > 80:
                    sanitized[key] = value[:80] + "..."
                else:
                    sanitized[key] = value
            elif isinstance(value, dict) and len(str(value)) < 200:
                # Truncate dict if still too large
                sanitized[key] = value
            elif isinstance(value, list) and len(value) < 3:
                # Only include very small lists
                sanitized[key] = value

        return sanitized

    def _add_timing_metrics(self, result: dict[str, Any], timings: dict[str, float]) -> dict[str, Any]:
        """Add timing metrics to result for performance debugging."""
        result["_performance"] = {
            "timings_ms": {k: round(v * 1000, 2) for k, v in timings.items()},
            "total_time_ms": round(sum(timings.values()) * 1000, 2)
        }
        return result

    def _format_result(self, data: Any, format_type: str = "detailed") -> dict[str, Any]:
        """Format result data based on requested format."""
        # Always sanitize data before formatting to prevent token overflow
        if isinstance(data, list):
            data = [self._sanitize_entity(item) if isinstance(item, dict) else item for item in data]
        elif isinstance(data, dict):
            data = self._sanitize_entity(data)

        if format_type == "raw":
            return {"data": data}
        if format_type == "summary":
            if isinstance(data, list):
                return {
                    "count": len(data),
                    "items": data[:3] if len(data) > 3 else data,
                    "truncated": len(data) > 3
                }
            return {"summary": str(data)[:200] + "..." if len(str(data)) > 200 else str(data)}
        # Auto-paginate if list is too large (>10 items for MCP)
        if isinstance(data, list) and len(data) > 10:
            return {
                "success": True,
                "data": data[:10],  # Only return first 10
                "count": len(data),
                "truncated": True,
                "total_count": len(data),
                "showing": "1-10",
                "hint": "Use limit/offset parameters for pagination",
                "user_id": self._get_user_id(),
                "timestamp": __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat()
            }
        return {
            "success": True,
            "data": data,
            "count": len(data) if isinstance(data, list) else 1,
            "user_id": self._get_user_id(),
            "timestamp": __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat()
        }
