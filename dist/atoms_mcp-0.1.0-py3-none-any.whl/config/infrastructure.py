"""Compatibility wrapper for :mod:`config.python.infrastructure`."""

from __future__ import annotations

from .python.infrastructure import *  # noqa: F401,F403
