"""Compatibility wrapper for :mod:`config.python.settings`."""

from __future__ import annotations

from .python.settings import *  # noqa: F401,F403
