"""
Atoms MCP Library

Modular, framework-agnostic deployment and server management.

Architecture:
- pheno-sdk/deploy-kit/base/         → Abstract interfaces (migrated to pheno-sdk)
- pheno-sdk/deploy-kit/platforms/    → Platform implementations (migrated to pheno-sdk)
- lib/atoms/                         → Atoms-specific implementations (stays in atoms_mcp-old)

Base and platform layers have been migrated to pheno-sdk/deploy-kit.
Atoms-specific logic remains in the atoms_mcp-old repository.
"""

# Atoms-specific implementations (stays in atoms_mcp-old)

# Core types (from pheno-sdk deployment module)
try:
    # Try pheno-sdk if installed
    from pheno.deployment import (
        DeploymentConfig,
        DeploymentState,
        DeploymentStatus,
    )
except ImportError:
    try:
        # Fallback: define minimal stubs
        class DeploymentConfig:
            pass
        class DeploymentState:
            pass
        class DeploymentStatus:
            pass
    except Exception as e:
        raise ImportError(
            "Could not import deployment types from pheno-sdk. "
            "Make sure pheno-sdk is properly installed."
        ) from e

from .atoms import (
    AtomsDeploymentConfig,
    AtomsServerManager,
    AtomsVercelDeployer,
    deploy_atoms_to_vercel,
    start_atoms_server,
)


# Provider configurations (mock interfaces for now - can be extended)
class DeploymentEnvironment:
    """Environment enumeration for deployments."""
    # Environment types (used for deployment configuration)
    LOCAL = "local"
    PREVIEW = "preview"
    PRODUCTION = "production"

class DeploymentResult:
    """Deployment result wrapper."""
    def __init__(self, success: bool, message: str = ""):
        self.success = success
        self.message = message

class DeploymentProvider:
    """Base provider interface."""

class HealthCheckProvider:
    """Base health check interface."""

class ServerProvider:
    """Base server interface."""

class TunnelProvider:
    """Base tunnel interface."""

class ConfigurationProvider:
    """Base configuration interface."""

# Platform implementations (from pheno-sdk/deploy-kit)
try:
    # Try pheno-sdk if installed
    from pheno.kits.deploy.platforms.vercel import VercelClient as _VercelDeploymentProvider1
    VercelDeploymentProvider = _VercelDeploymentProvider1
    HTTPHealthCheckProvider = object  # Will be defined in atoms layer
    VercelConfigProvider = object  # Will be defined in atoms layer
    AdvancedHealthChecker = object  # Will be defined in atoms layer
except ImportError:
    try:
        # Fall back to vendored version
        from pheno_vendor.deploy_kit.platforms.modern.vercel import VercelClient as _VercelDeploymentProvider2
        VercelDeploymentProvider = _VercelDeploymentProvider2
        HTTPHealthCheckProvider = object  # Will be defined in atoms layer
        VercelConfigProvider = object  # Will be defined in atoms layer
        AdvancedHealthChecker = object  # Will be defined in atoms layer
    except ImportError:
        # Final fallback - define minimal mock classes
        class VercelDeploymentProvider:
            pass
        class HTTPHealthCheckProvider:
            pass
        class VercelConfigProvider:
            pass
        class AdvancedHealthChecker:
            pass

__all__ = [
    "AdvancedHealthChecker",
    # Atoms-specific (stays in atoms_mcp-old)
    "AtomsDeploymentConfig",
    "AtomsServerManager",
    "AtomsVercelDeployer",
    "ConfigurationProvider",
    "DeploymentConfig",
    # Base abstractions (from pheno-sdk/deploy-kit)
    "DeploymentEnvironment",
    "DeploymentProvider",
    "DeploymentResult",
    "DeploymentStatus",
    "HTTPHealthCheckProvider",
    "HealthCheckProvider",
    "ServerProvider",
    "TunnelProvider",
    "VercelConfigProvider",
    # Platform implementations (from pheno-sdk/deploy-kit)
    "VercelDeploymentProvider",
    "deploy_atoms_to_vercel",
    "start_atoms_server",
]

