#!/usr/bin/env python3
"""
C.1 Automation Script: Apply Markers & Docstrings to All Tests

This script adds @pytest.mark decorators and comprehensive docstrings to all test functions
following the patterns in B6_B7_REFACTORING_TEMPLATE.md

Usage:
    source .venv/bin/activate
    python tests/C1_APPLY_MARKERS_AND_DOCSTRINGS_FIXED.py [--dry-run]

Options:
    --dry-run: Print changes without writing to files
"""

import re
import sys
from pathlib import Path
from typing import Dict, List, Tuple

# Marker configurations by directory pattern
MARKER_CONFIG = {
    'tests/unit/tools': ['unit'],
    'tests/unit/infrastructure': ['unit', 'database'],
    'tests/integration': ['integration'],
    'tests/e2e': ['e2e'],
    'tests/performance': ['performance'],
    'tests/security': ['security'],
}

SECONDARY_MARKERS = {
    # Tests that should have @pytest.mark.slow (>5 seconds)
    'test_complete_user_workflow': ['slow'],
    'test_api_concurrent_requests': ['slow'],
    'test_throughput_concurrent': ['slow'],
    'test_concurrent': ['slow'],
    'benchmark': ['slow'],
    # Database-specific
    'test_supabase': ['database'],
    'test_auth': ['database'],
    'test_config': ['database'],
    # Requires live services
    'test_e2e': ['requires_db'],
    'test_integration_workflows': ['requires_db'],
}


def determine_markers(file_path: str, test_name: str) -> List[str]:
    """Determine which markers should be applied to a test function."""
    markers: List[str] = []

    # Primary marker based on directory
    for pattern, mark_list in MARKER_CONFIG.items():
        if pattern in file_path:
            markers.extend(mark_list)
            break

    # Secondary markers based on test name
    for pattern, mark_list in SECONDARY_MARKERS.items():
        if pattern.lower() in test_name.lower():
            markers.extend(mark_list)

    # Remove duplicates while preserving order
    seen = set()
    unique_markers: List[str] = []
    for marker in markers:
        if marker not in seen:
            seen.add(marker)
            unique_markers.append(marker)

    return unique_markers


def has_docstring(func_block: List[str], func_def_idx: int) -> bool:
    """Return True if a docstring is immediately after the def line."""
    if func_def_idx + 1 >= len(func_block):
        return False
    next_line = func_block[func_def_idx + 1].strip()
    return next_line.startswith('"""') or next_line.startswith("'''")


def insert_markers_and_docstring(func_text: str, markers: List[str]) -> str:
    """Insert @pytest.mark decorators and a minimal docstring if missing."""
    lines = func_text.split('\n')

    # Find def line index
    func_def_idx = None
    for i, line in enumerate(lines):
        if line.lstrip().startswith('def test_') or line.lstrip().startswith('async def test_'):
            func_def_idx = i
            break
    if func_def_idx is None:
        return func_text

    # Determine base indent
    def_line = lines[func_def_idx]
    indent = def_line[: len(def_line) - len(def_line.lstrip())]

    # Collect existing decorators directly above def
    insert_idx = func_def_idx
    while insert_idx - 1 >= 0 and lines[insert_idx - 1].lstrip().startswith('@'):
        insert_idx -= 1

    # Build new decorators (avoid duplicates)
    existing = set(l.strip() for l in lines[insert_idx:func_def_idx] if l.lstrip().startswith('@'))
    new_decorators: List[str] = []
    # keep asyncio marker at function level only if not at module level; safe to add idempotently here
    if '@pytest.mark.asyncio' not in existing:
        new_decorators.append(f'{indent}@pytest.mark.asyncio')
    for m in markers:
        mark_line = f'{indent}@pytest.mark.{m}'
        if mark_line.strip() not in existing:
            new_decorators.append(mark_line)

    if new_decorators:
        lines[insert_idx:insert_idx] = new_decorators
        func_def_idx += len(new_decorators)

    # Add a minimal docstring if missing
    if not has_docstring(lines, func_def_idx):
        ds_indent = indent + '    '
        doc = [
            f'{ds_indent}"""Test case for FastMCP tool behavior.',
            f'{ds_indent}',
            f'{ds_indent}Markers:',
        ]
        for m in markers:
            doc.append(f'{ds_indent}- @pytest.mark.{m}')
        doc.append(f'{ds_indent}"""')
        lines[func_def_idx + 1:func_def_idx + 1] = doc

    return '\n'.join(lines)


def process_file(path: Path) -> Dict[str, int]:
    stats = {"modified": 0, "added_docstrings": 0, "added_markers": 0}
    text = path.read_text()

    # Regex to capture whole test functions (simple heuristic)
    pattern = re.compile(r'(^\s*(?:async\s+)?def\s+test_[\w_]*\(.*?\):\n(?:[ \t].*\n)+)', re.M)
    changed = text

    for m in list(pattern.finditer(text)):
        func_block = m.group(0)
        # name
        name_match = re.search(r'def\s+(test_[\w_]+)', func_block)
        test_name = name_match.group(1) if name_match else 'test_unknown'
        markers = determine_markers(str(path), test_name)
        if not markers:
            continue
        new_block = insert_markers_and_docstring(func_block, markers)
        if new_block != func_block:
            changed = changed.replace(func_block, new_block, 1)
            stats["modified"] += 1

    if changed != text:
        path.write_text(changed)

    return stats


def main() -> None:
    dry_run = '--dry-run' in sys.argv
    root = Path('/Users/kooshapari/temp-PRODVERCEL/485/kush/atoms-mcp-prod/tests')
    files = sorted(root.rglob('test_*.py'))
    total = {"modified": 0}
    for f in files:
        if 'archive' in str(f) or '__pycache__' in str(f):
            continue
        before = f.read_text()
        stats = process_file(f)
        total["modified"] += stats["modified"]
        if dry_run:
            f.write_text(before)  # revert
    print(f"Processed {len(files)} files; modified {total['modified']}")


if __name__ == '__main__':
    main()
