# B.2: httpx → FastMCP Client Conversion Analysis

## Current State Analysis

### Current Pattern (httpx-based)
Located in test files: `test_entity_tool_comprehensive.py`, `test_entity_tool_comprehensive_live.py`, `test_relationship_operations.py`, `test_workspace_tool_comprehensive.py`, `test_error_handling.py`, `test_integration_workflows.py`, `test_relationship_tool.py`, `test_all_workflows_live.py`, `test_performance.py`, etc.

**Current implementation**:
```python
import httpx
import uuid
import time

MCP_BASE_URL = os.getenv("ATOMS_FASTMCP_BASE_URL", "http://127.0.0.1:8000")
MCP_PATH = os.getenv("ATOMS_FASTMCP_HTTP_PATH", "/api/mcp")

@pytest.fixture(scope="session")
def call_mcp(check_server_running, supabase_jwt):
    """Return a helper that invokes MCP tools over HTTP."""
    base_url = f"{MCP_BASE_URL.rstrip('/')}{MCP_PATH}"
    headers = {
        "Authorization": f"Bearer {supabase_jwt}",
        "Content-Type": "application/json",
    }

    async def _call(tool_name: str, params: Dict[str, Any]) -> tuple[Dict[str, Any], float]:
        payload = {
            "jsonrpc": "2.0",
            "id": str(uuid.uuid4()),
            "method": f"tools/{tool_name}",
            "params": params,
        }
        
        start_time = time.perf_counter()
        
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(base_url, json=payload, headers=headers)
            
            duration_ms = (time.perf_counter() - start_time) * 1000
            
            if response.status_code != 200:
                return {
                    "success": False,
                    "error": f"HTTP {response.status_code}: {response.text}"
                }, duration_ms
            
            # JSON-RPC parsing
            data = response.json()
            if "error" in data:
                return {"success": False, "error": data["error"]}, duration_ms
            
            result = data.get("result", {})
            return {"success": True, "result": result}, duration_ms
        
        except Exception as e:
            return {"success": False, "error": str(e)}, duration_ms
    
    return _call

# Usage in tests
async def test_entity_creation(call_mcp):
    result, duration = await call_mcp(
        "entity_tool",
        {
            "operation": "create",
            "entity_type": "organization",
            "data": {"name": "Test Org"}
        }
    )
    assert result["success"]
```

## Conversion Strategy

### Target Pattern (FastMCP Client)
Following FastMCP best practices for in-memory and HTTP testing.

**Unit Tests** (in-memory):
```python
@pytest.mark.unit
async def test_entity_creation(mcp_client_inmemory):
    """Test entity creation using in-memory client."""
    result = await mcp_client_inmemory.call_tool(
        "entity_tool",
        {
            "operation": "create",
            "entity_type": "organization",
            "data": {"name": "Test Org"}
        }
    )
    # FastMCP Client returns result directly (no JSON-RPC wrapping)
    assert result.success or isinstance(result, dict)
```

**Integration Tests** (HTTP):
```python
@pytest.mark.integration
@pytest.mark.requires_db
async def test_entity_creation_http(mcp_client_http):
    """Test entity creation via HTTP transport."""
    result = await mcp_client_http.call_tool(
        "entity_tool",
        {
            "operation": "create",
            "entity_type": "organization",
            "data": {"name": "Test Org"}
        }
    )
    # FastMCP Client abstracts HTTP/JSON-RPC details
    assert result.success
```

## Files Requiring Conversion

### Priority 1: Unit Tool Tests (move to unit/tools/)
These will use **in-memory** client after conversion:

1. **test_entity_tool_comprehensive.py** (1548 lines)
   - Current: httpx.AsyncClient + JSON-RPC
   - Target: mcp_client_inmemory fixture
   - Uses: Supabase JWT (keep for auth)
   - Focus: All entity types and operations

2. **test_entity_tool_comprehensive_live.py** (840 lines)
   - Current: httpx + live Supabase
   - Target: Split into unit/tools/test_entity.py (in-memory) + integration/test_*.py (live)
   - Keep live tests marked as @pytest.mark.integration

3. **test_relationship_tool_comprehensive.py** (660 lines)
   - Current: httpx + JSON-RPC
   - Target: mcp_client_inmemory fixture
   - Focus: Relationship operations

4. **test_workspace_tool_comprehensive.py** (580 lines)
   - Current: httpx
   - Target: mcp_client_inmemory fixture

5. **test_query_tool_comprehensive.py** (450 lines)
   - Current: httpx
   - Target: mcp_client_inmemory fixture

6. **test_workflow_tool_comprehensive.py** (920 lines)
   - Current: httpx
   - Target: mcp_client_inmemory fixture

7. **test_relationship_operations.py** (340 lines)
   - Current: httpx
   - Target: mcp_client_inmemory fixture

8. **test_entity_tool_manual.py** (280 lines)
   - Current: httpx
   - Target: mcp_client_inmemory fixture

### Priority 2: Integration Tests (move to integration/)
These will use **HTTP** client and remain integration-scoped:

1. **test_error_handling.py** (290 lines)
   - Current: httpx
   - Target: Keep as integration/test_error_handling.py with mcp_client_http
   - Mark: @pytest.mark.integration

2. **test_integration_workflows.py** (540 lines)
   - Current: httpx
   - Target: integration/test_workflows.py with mcp_client_http

3. **test_all_workflows_live.py** (450 lines)
   - Current: httpx + live
   - Target: e2e/test_workflows.py (full deployment)

4. **test_performance.py** (620 lines)
   - Current: httpx + timing
   - Target: performance/test_benchmarks.py with mcp_client_http + timing_tracker fixture

5. **test_end_to_end.py** (780 lines)
   - Current: httpx + live
   - Target: e2e/test_e2e.py with full_deployment fixture

### Priority 3: Other HTTP Users
1. **test_mcp_comprehensive.py** (line 697)
2. **test_mcp_workspace_comprehensive.py** (line 173)
3. **conftest.py** (line 30, 33) - existing httpx for health check

---

## Conversion Template

### BEFORE: httpx-based fixture
```python
# Old pattern
import httpx
import uuid

@pytest.fixture(scope="session")
def call_mcp(check_server_running, supabase_jwt):
    base_url = "http://127.0.0.1:8000/api/mcp"
    headers = {"Authorization": f"Bearer {supabase_jwt}"}
    
    async def _call(tool_name, params):
        payload = {
            "jsonrpc": "2.0",
            "id": str(uuid.uuid4()),
            "method": f"tools/{tool_name}",
            "params": params,
        }
        async with httpx.AsyncClient() as client:
            response = await client.post(base_url, json=payload, headers=headers)
            data = response.json()
            return data.get("result", {})
    
    return _call

# Old test usage
async def test_create(call_mcp):
    result, duration = await call_mcp("entity_tool", {"operation": "create", ...})
    assert result["success"]
```

### AFTER: FastMCP Client-based fixture
```python
# New pattern (in conftest at appropriate level)

# Unit tests conftest.py (tests/unit/tools/conftest.py)
@pytest.fixture
async def mcp_client_inmemory(mcp_server):
    """In-memory client for fast unit tests."""
    from fastmcp import Client
    async with Client(mcp_server) as client:
        yield client

# Integration tests conftest.py (tests/integration/conftest.py)
@pytest.fixture
async def mcp_client_http():
    """HTTP client for integration tests."""
    from fastmcp import Client
    from fastmcp.client.transports import StreamableHttpTransport
    
    transport = StreamableHttpTransport("http://127.0.0.1:8000/mcp")
    async with Client(transport=transport) as client:
        yield client

# New test usage - UNIT
@pytest.mark.unit
async def test_create_unit(mcp_client_inmemory):
    """Test with in-memory client."""
    result = await mcp_client_inmemory.call_tool(
        "entity_tool",
        {"operation": "create", "entity_type": "organization", "data": {...}}
    )
    assert result.success

# New test usage - INTEGRATION
@pytest.mark.integration
async def test_create_integration(mcp_client_http):
    """Test with HTTP client."""
    result = await mcp_client_http.call_tool(
        "entity_tool",
        {"operation": "create", "entity_type": "organization", "data": {...}}
    )
    assert result.success
```

---

## Key Conversion Points

### 1. JSON-RPC Wrapping
**BEFORE**: Manual JSON-RPC envelope construction
```python
payload = {
    "jsonrpc": "2.0",
    "id": str(uuid.uuid4()),
    "method": f"tools/{tool_name}",
    "params": params,
}
response = await client.post(url, json=payload)
```

**AFTER**: Handled by FastMCP Client
```python
result = await client.call_tool("entity_tool", {...})
# JSON-RPC is abstracted away
```

### 2. Error Handling
**BEFORE**: Manual HTTP status + JSON-RPC error parsing
```python
if response.status_code != 200:
    return {"success": False, "error": f"HTTP {response.status_code}"}
data = response.json()
if "error" in data:
    return {"success": False, "error": data["error"]}
```

**AFTER**: Unified exception handling
```python
try:
    result = await client.call_tool(...)
except Exception as e:
    # Handle all errors uniformly
    pytest.fail(f"Tool call failed: {e}")
```

### 3. Timing/Performance
**BEFORE**: Manual timing with perf_counter
```python
start_time = time.perf_counter()
response = await client.post(...)
duration_ms = (time.perf_counter() - start_time) * 1000
```

**AFTER**: Use timing_tracker fixture
```python
with timing_tracker.measure("entity_creation"):
    result = await client.call_tool(...)
# Automatically tracked
```

### 4. Authentication
**BEFORE**: Manual JWT header construction
```python
headers = {"Authorization": f"Bearer {supabase_jwt}"}
response = await client.post(..., headers=headers)
```

**AFTER**: Configuration-based (if needed)
```python
# For in-memory: authentication handled in server setup
# For HTTP: can use Client auth parameter
async with Client(transport=transport, auth=auth_provider) as client:
    ...
```

---

## Conversion Effort Estimate

| File | Lines | Type | Effort | Est. Time |
|------|-------|------|--------|-----------|
| test_entity_tool_comprehensive.py | 1548 | Unit→In-Memory | High | 45 min |
| test_entity_tool_comprehensive_live.py | 840 | Split | High | 45 min |
| test_relationship_tool_comprehensive.py | 660 | Unit→In-Memory | Medium | 30 min |
| test_workspace_tool_comprehensive.py | 580 | Unit→In-Memory | Medium | 25 min |
| test_query_tool_comprehensive.py | 450 | Unit→In-Memory | Medium | 20 min |
| test_workflow_tool_comprehensive.py | 920 | Unit→In-Memory | High | 40 min |
| test_relationship_operations.py | 340 | Unit→In-Memory | Medium | 20 min |
| test_entity_tool_manual.py | 280 | Unit→In-Memory | Low | 15 min |
| test_error_handling.py | 290 | Integration→HTTP | Medium | 20 min |
| test_integration_workflows.py | 540 | Integration→HTTP | Medium | 25 min |
| test_all_workflows_live.py | 450 | E2E→Full | Medium | 25 min |
| test_performance.py | 620 | Perf→Benchmarks | High | 35 min |
| test_end_to_end.py | 780 | E2E→Full | High | 40 min |
| **Total** | **9,358** | | | **~420 min (7 hrs)** |

---

## Benefits of Conversion

### Performance
- **Unit tests**: 10-100x faster (no network)
- **Deterministic**: No flakiness from network/service issues
- **Parallel execution**: Can run all unit tests concurrently

### Developer Experience
- **Debugging**: Set breakpoints anywhere, step through code
- **Clarity**: Clear separation of unit vs. integration tests
- **Maintainability**: Standard FastMCP patterns, easier to understand

### Reliability
- **Isolation**: No shared state, tests run independently
- **Repeatability**: Same results every run
- **CI/CD**: Faster feedback loop

---

## Implementation Order

1. **Phase 1 (B.4)**: Create conftest.py files with fixtures
2. **Phase 2 (B.5.1)**: Convert tool tests (entity, workflow, relationship, query, workspace)
3. **Phase 3 (B.5.2)**: Convert integration tests (error_handling, workflows, API)
4. **Phase 4 (B.5.3)**: Convert E2E and performance tests

---

## References

- FastMCP Client Documentation: Provided in FIXTURE_TEMPLATES.md
- httpx Documentation: https://www.python-httpx.org/
- JSON-RPC Spec: https://www.jsonrpc.org/specification
- Pytest Async Testing: https://docs.pytest.org/en/latest/how-to-write-plugins.html#async-contrib
