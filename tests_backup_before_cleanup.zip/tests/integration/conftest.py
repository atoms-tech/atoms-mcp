"""Fixtures for integration tests.

Provides:
- mcp_client_http: HTTP client for testing against running server
- live_supabase: Live Supabase client (requires DB credentials)
- request_mock: Mock HTTP requests
"""

import pytest
import os
from typing import AsyncGenerator
from unittest.mock import AsyncMock


@pytest.fixture
async def mcp_client_http(check_server_running) -> AsyncGenerator:
    """MCP client via HTTP transport.
    
    Requires: MCP server running on localhost:8000
    
    Usage:
        @pytest.mark.integration
        async def test_http_api(mcp_client_http):
            result = await mcp_client_http.call_tool(
                "entity_tool",
                {"operation": "list", "entity_type": "organization"}
            )
            assert result.success
    """
    try:
        from fastmcp import Client
        from fastmcp.client.transports import StreamableHttpTransport
        
        base_url = os.getenv("ATOMS_FASTMCP_BASE_URL", "http://127.0.0.1:8000")
        mcp_path = os.getenv("ATOMS_FASTMCP_HTTP_PATH", "/api/mcp")
        transport = StreamableHttpTransport(f"{base_url}{mcp_path}")
        
        async with Client(transport=transport) as client:
            yield client
    except ImportError:
        pytest.skip("FastMCP Client not available")


@pytest.fixture
def live_supabase():
    """Live Supabase client for integration tests.
    
    Requires: NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY
    
    Usage:
        @pytest.mark.integration
        @pytest.mark.requires_db
        def test_database_operation(live_supabase):
            result = live_supabase.table('users').select('*').execute()
            assert result.success
    """
    import os
    from supabase import create_client
    
    url = os.getenv("NEXT_PUBLIC_SUPABASE_URL")
    key = os.getenv("NEXT_PUBLIC_SUPABASE_ANON_KEY")
    
    if not url or not key:
        pytest.skip("Supabase not configured")
    
    return create_client(url, key)


@pytest.fixture
def request_mock():
    """Mock HTTP requests for testing API interactions."""
    mock_request = AsyncMock()
    mock_request.get = AsyncMock()
    mock_request.post = AsyncMock()
    mock_request.put = AsyncMock()
    mock_request.delete = AsyncMock()
    return mock_request


@pytest.fixture
def httpx_client_mock():
    """Mock httpx.AsyncClient for testing HTTP calls."""
    import httpx
    mock_client = AsyncMock(spec=httpx.AsyncClient)
    mock_client.post = AsyncMock()
    mock_client.get = AsyncMock()
    mock_client.put = AsyncMock()
    mock_client.delete = AsyncMock()
    return mock_client


@pytest.fixture
def api_base_url() -> str:
    """Get MCP API base URL from environment."""
    base_url = os.getenv("ATOMS_FASTMCP_BASE_URL", "http://127.0.0.1:8000")
    path = os.getenv("ATOMS_FASTMCP_HTTP_PATH", "/api/mcp")
    return f"{base_url}{path}"
