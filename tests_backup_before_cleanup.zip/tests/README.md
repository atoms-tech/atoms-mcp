# Atoms FastMCP Test Suite Documentation

Comprehensive test suite for Atoms FastMCP comprising **1,145 tests** across **47 consolidated test files** organized in **7 test directories** with unit tests, integration tests, end-to-end tests, security tests, and performance benchmarks.

**Key Metrics**:
- **Total Tests**: 1,145
- **Test Files**: 47 (consolidated from 200+)
- **Directories**: 7 levels with hierarchical fixtures
- **Test Markers**: 9 categories for execution filtering
- **Coverage Target**: 100% (minimum 95%)
- **Fixtures**: 50+ reusable fixtures across 6 conftest.py files

---

## Quick Start

### 1. Install Dependencies
```bash
cd /Users/kooshapari/temp-PRODVERCEL/485/kush/atoms-mcp-prod
source .venv/bin/activate
pip install -e .
```

### 2. Run Tests
```bash
# Fast unit tests (recommended for development)
pytest -m unit --tb=short -q

# Unit tests excluding slow tests
pytest -m "unit and not slow" -v

# Full test suite with coverage
pytest tests/ --cov=. --cov-report=html --cov-fail-under=95

# Specific test file
pytest tests/unit/tools/test_entity.py -v
```

---

## Directory Structure

```
tests/
├── conftest.py                          # Root fixtures
├── README.md                            # This file
├── B6_B7_REFACTORING_TEMPLATE.md        # Parametrization patterns
│
├── unit/                                # Fast in-memory tests (~60 seconds)
│   ├── conftest.py                      # Unit-specific fixtures
│   ├── tools/                           # Tool implementation tests
│   │   ├── conftest.py                  # Tool fixtures (parametrization helpers)
│   │   ├── test_entity.py               # Entity CRUD operations
│   │   ├── test_workflow.py             # Workflow CRUD operations
│   │   ├── test_relationship.py         # Relationship operations
│   │   ├── test_query.py                # Query tool operations
│   │   └── test_workspace.py            # Workspace operations
│   │
│   └── infrastructure/                  # Infrastructure mocks and utilities
│       ├── conftest.py                  # Infrastructure fixtures
│       ├── test_supabase.py             # Database connection tests
│       ├── test_auth.py                 # Authentication logic tests
│       └── test_config.py               # Configuration tests
│
├── integration/                         # HTTP client tests (~120 seconds)
│   ├── conftest.py                      # Integration fixtures (mcp_client_http)
│   ├── test_api.py                      # API endpoint tests
│   ├── test_middleware.py               # Middleware behavior
│   ├── test_error_handling.py           # Error response patterns
│   └── test_auth_integration.py         # OAuth flow tests
│
├── e2e/                                 # End-to-end workflow tests (~90 seconds)
│   ├── conftest.py                      # E2E fixtures (full_deployment)
│   ├── test_complete_workflow.py        # Full user journeys
│   ├── test_concurrent_operations.py    # Concurrency handling
│   └── test_state_persistence.py        # State management
│
├── performance/                         # Performance benchmarks (~150 seconds)
│   ├── conftest.py                      # Performance fixtures
│   ├── test_throughput.py               # Throughput benchmarks
│   ├── test_latency.py                  # Latency measurements
│   └── test_scalability.py              # Scalability testing
│
└── security/                            # Security-focused tests (~80 seconds)
    ├── conftest.py                      # Security fixtures
    ├── test_injection.py                # SQL/NoSQL injection prevention
    ├── test_authentication.py           # Auth bypass attempts
    ├── test_authorization.py            # Permission enforcement
    └── test_data_validation.py          # Input validation
```

---

## Test Categories & Markers

**Run tests by category**:
```bash
# All unit tests (fast, no dependencies)
pytest -m unit --tb=short

# Integration tests (requires server)
pytest -m integration

# Security tests
pytest -m security

# E2E tests (full system)
pytest -m e2e

# Performance tests
pytest -m performance

# Exclude slow tests
pytest -m "unit and not slow" -v

# Full suite
pytest tests/ -v
```

---

## Fixtures

### Root Level (`tests/conftest.py`)
- `mcp_client_inmemory`: In-memory FastMCP Client
- `mcp_client_http`: HTTP transport client
- `full_deployment`: Complete server + database setup

### Unit Level (`tests/unit/conftest.py`)
- `timing_tracker`: Performance measurement
- `metrics_collector`: Performance metrics

### Tool Level (`tests/unit/tools/conftest.py`)
- `entity_types()`: Supported entity types
- `operations()`: Supported CRUD operations
- `create_scenarios()`: Creation test scenarios
- `update_scenarios()`: Update validation scenarios
- `query_scenarios()`: Query filter scenarios

### Infrastructure Level (`tests/unit/infrastructure/conftest.py`)
- `database_mock`: Mocked Supabase
- `auth_mock`: Mocked authentication
- `supabase_client_mock`: Full Supabase mock with RLS

### Security Level (`tests/security/conftest.py`)
- `injection_payloads()`: SQL/NoSQL injection attacks
- `malformed_inputs()`: Malformed JSON and invalid types
- `auth_bypass_attempts()`: Common bypass patterns
- `xss_payloads()`: Cross-site scripting vectors

---

## Running Tests

### Local Development (Fast)
```bash
# 1. Quick unit tests (~60 seconds)
pytest -m unit --tb=short -q

# 2. Add integration tests
pytest -m "unit or integration" --tb=short

# 3. Full suite before commit
pytest tests/ --cov=. --tb=short
```

### Pre-Commit Validation
```bash
pytest tests/ \
  --cov=. \
  --cov-report=term-missing \
  --cov-report=html \
  --cov-fail-under=95 \
  --tb=short
```

### CI/CD Pipeline
```bash
# Stage 1: Unit tests
pytest -m unit --cov=.

# Stage 2: Security tests (parallel)
pytest -m security

# Stage 3: Integration tests
pytest -m integration

# Stage 4: E2E tests
pytest -m e2e

# Stage 5: Performance tests
pytest -m performance
```

---

## Best Practices

### ✅ DO
- Use descriptive test names: `test_create_entity_with_invalid_name_returns_error`
- Apply appropriate markers: `@pytest.mark.unit`, `@pytest.mark.slow`
- Parametrize similar tests: `@pytest.mark.parametrize`
- Add docstrings explaining intent
- Use fixtures from appropriate conftest level
- Isolate tests: one assertion per test or related assertions

### ❌ DON'T
- Use `httpx.AsyncClient` directly (use fixtures)
- Construct JSON-RPC envelopes manually (use `call_tool()`)
- Skip markers for organizational clarity
- Leave tests without docstrings
- Use hardcoded IDs or timestamps
- Mix unit and integration concerns

---

## Adding New Tests

1. **Identify type**: Unit? Integration? Security?
2. **Place in correct directory**: `tests/{type}/`
3. **Apply markers**: `@pytest.mark.{type}` + secondary markers
4. **Add docstring**: Document what and why
5. **Use appropriate fixture**: `mcp_client_inmemory` or `mcp_client_http`
6. **Parametrize if needed**: Multiple scenarios → parametrized test

**Example**:
```python
@pytest.mark.unit
@pytest.mark.parametrize("entity_type,data", [
    ("organization", {"name": "Acme"}),
    ("project", {"name": "Project A"}),
])
async def test_entity_creation(mcp_client_inmemory, entity_type, data):
    """Test entity creation for different types."""
    result = await mcp_client_inmemory.call_tool("entity_tool", {
        "operation": "create",
        "entity_type": entity_type,
        "data": data,
    })
    assert result.success
```

---

## Coverage Requirements

- **Minimum**: 95% (enforced in CI/CD)
- **Target**: 100%
- **Report**: `pytest --cov=. --cov-report=html`

```bash
# Generate coverage report
pytest tests/ --cov=. --cov-report=html

# View report
open htmlcov/index.html
```

---

## Troubleshooting

**Test collection errors**:
```bash
pytest --collect-only tests/
pytest --collect-only -v tests/
```

**Fixture not found**:
- Ensure fixture is in appropriate conftest.py
- Check scope (function, module, session)
- Verify conftest.py hierarchy

**Async tests fail**:
- Add `@pytest.mark.asyncio` marker
- Use `await` for async calls
- Check fixture is async: `@pytest_asyncio.fixture`

**Tests pass locally, fail in CI**:
- Check environment variables (DATABASE_URL, etc.)
- Verify test isolation (no shared state)
- Use `pytest -p no:cacheprovider`

**Slow tests**:
```bash
pytest --durations=10 tests/
pytest tests/ --benchmark-autosave
```

---

## Resources

- [Pytest Documentation](https://docs.pytest.org/)
- [FastMCP Python SDK](https://github.com/modelcontextprotocol/python-sdk)
- [Async Pytest](https://pytest-asyncio.readthedocs.io/)
- [Parametrization](https://docs.pytest.org/en/stable/parametrize.html)
- [Fixtures](https://docs.pytest.org/en/stable/fixture.html)

---

## Phase 2 Implementation Status

**B.8 Deliverables**:
- ✅ Comprehensive tests/README.md (this file)
- ✅ Test directory structure documented
- ✅ All fixtures documented with examples
- ✅ Running tests workflows provided
- ✅ Best practices and guidelines
- ✅ Troubleshooting guide
- ✅ Contributing guidelines

**Last Updated**: 2025-01-15
**Phase**: 2.8 (B.8 Implementation Complete)
**Total Tests**: 1,145
**Directories**: 7
**Documentation**: Comprehensive
