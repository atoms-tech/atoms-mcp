# B.6-B.7: Parametrization & Markers Template

## Overview
This document shows the refactoring pattern applied to consolidate tests and add proper markers/docstrings.

---

## B.6: Parametrization Pattern

### ENTITY_TOOL Example: Consolidating 30 separate tests → 6 parametrized tests

#### BEFORE (test_entity.py - 30 separate test functions)
```python
async def test_create_organization(mcp_client_inmemory):
    """Test organization creation."""
    result = await mcp_client_inmemory.call_tool("entity_tool", {
        "operation": "create",
        "entity_type": "organization",
        "data": {"name": "Test Org"}
    })
    assert result.success

async def test_create_project(mcp_client_inmemory):
    """Test project creation."""
    result = await mcp_client_inmemory.call_tool("entity_tool", {
        "operation": "create",
        "entity_type": "project",
        "data": {"name": "Test Project"}
    })
    assert result.success

async def test_create_document(mcp_client_inmemory):
    """Test document creation."""
    # ... same pattern repeated for each entity type
```

#### AFTER (test_entity.py - 1 parametrized test covering all)
```python
@pytest.mark.unit
@pytest.mark.parametrize("entity_type,entity_data", [
    ("organization", {"name": "Test Org"}),
    ("project", {"name": "Test Project"}),
    ("document", {"name": "Test Doc"}),
    ("requirement", {"name": "REQ-001", "priority": "high"}),
    ("test_entity", {"title": "Test Case"}),
    ("property", {"key": "prop1", "value": "val1"}),
])
async def test_entity_create_variants(mcp_client_inmemory, entity_type: str, entity_data: dict):
    """Test entity creation across all entity types.
    
    Validates that each entity type can be created with appropriate data
    and returns success response. Tests cover organization, project, document,
    requirement, test entity, and property types.
    
    Args:
        mcp_client_inmemory: In-memory MCP client fixture
        entity_type: Type of entity to create (from parametrize)
        entity_data: Entity-specific creation data (from parametrize)
    """
    result = await mcp_client_inmemory.call_tool("entity_tool", {
        "operation": "create",
        "entity_type": entity_type,
        "data": entity_data,
    })
    
    assert result.success, f"Failed to create {entity_type}: {result}"
    assert result.data.get("id"), f"No ID returned for {entity_type}"
    assert result.data.get("created_at"), f"No created_at for {entity_type}"

# Result: 30 tests reduced to 6 parametrized tests (80% consolidation)
# Maintainability: Adding a new entity type requires only adding one line to the parametrize list
```

---

## B.7: Adding Markers & Docstrings

### Marker Application Strategy

**By Directory**:
```python
# tests/unit/tools/test_entity.py
@pytest.mark.unit              # ← All unit/tools tests
@pytest.mark.parametrize(...)
async def test_entity_create_variants(mcp_client_inmemory, ...):
    """..."""

# tests/unit/infrastructure/test_supabase.py
@pytest.mark.unit              # ← All unit tests
@pytest.mark.database          # ← Additional category marker
def test_rls_context(rls_context_mock):
    """..."""

# tests/integration/test_api.py
@pytest.mark.integration       # ← All integration tests
@pytest.mark.requires_db       # ← Requires live services
async def test_api_endpoint(mcp_client_http):
    """..."""

# tests/e2e/test_e2e.py
@pytest.mark.e2e               # ← All E2E tests
@pytest.mark.slow              # ← Takes >5 seconds
async def test_complete_workflow(full_deployment):
    """..."""

# tests/performance/test_benchmarks.py
@pytest.mark.performance       # ← All performance tests
@pytest.mark.slow              # ← Takes >5 seconds
async def test_throughput(timing_tracker, load_generator):
    """..."""

# tests/unit/security/test_injection.py
@pytest.mark.unit              # ← Unit test
@pytest.mark.security          # ← Security test
@pytest.mark.parametrize("payload", injection_payloads()["sql_injection"])
async def test_sql_injection_prevention(mcp_client_inmemory, payload):
    """..."""
```

### Docstring Template (All tests should follow this)

```python
@pytest.mark.unit
@pytest.mark.parametrize("entity_type,entity_data", [
    ("organization", {...}),
    ("project", {...}),
])
async def test_entity_create_variants(mcp_client_inmemory, entity_type: str, entity_data: dict):
    """Test entity creation across all entity types.
    
    This test validates that each entity type (organization, project, document, etc.)
    can be created successfully through the entity_tool with appropriate data.
    
    **What is being tested:**
    - Entity creation with type-specific data
    - Success response structure
    - ID generation and timestamps
    
    **Markers applied:**
    - @pytest.mark.unit: This is a unit test (in-memory, fast)
    - @pytest.mark.parametrize: Tests multiple entity types
    
    **Fixtures used:**
    - mcp_client_inmemory: In-memory FastMCP client (no network)
    
    **Expected behavior:**
    - Each entity type creates successfully
    - Result contains id and created_at fields
    - No network calls required
    
    Args:
        mcp_client_inmemory: In-memory MCP client fixture
        entity_type: Entity type to test (parametrized)
        entity_data: Creation data for entity type (parametrized)
    """
    result = await mcp_client_inmemory.call_tool("entity_tool", {
        "operation": "create",
        "entity_type": entity_type,
        "data": entity_data,
    })
    
    assert result.success, f"Failed to create {entity_type}: {result.error if hasattr(result, 'error') else result}"
    assert hasattr(result, 'data') and result.data.get("id"), f"No ID in {entity_type} response"
    assert result.data.get("created_at"), f"No created_at in {entity_type} response"
```

---

## Consolidated Markers Across Test Suite

```bash
# Run different test categories
pytest -m unit                                  # All unit tests (fast)
pytest -m "unit and not slow"                  # Unit tests excluding slow tests
pytest -m integration                          # All integration tests
pytest -m "integration and requires_db"        # Integration tests needing live DB
pytest -m security                             # All security tests
pytest -m "security and not slow"              # Fast security tests
pytest -m e2e                                  # All end-to-end tests
pytest -m performance                          # All performance tests
pytest -m "performance and not slow"           # Quick performance checks

# Run by directory
pytest tests/unit/                             # All unit tests
pytest tests/unit/tools/                       # All tool unit tests
pytest tests/unit/security/                    # All security unit tests
pytest tests/integration/                      # All integration tests
pytest tests/e2e/                              # All E2E tests
pytest tests/performance/                      # All performance tests
```

---

## Expected Result After B.6-B.7

### Code Metrics
- Test functions: 1145 → ~800 (after parametrization)
- Duplicate code: Eliminated ~60%
- Coverage maintained: 100% (same test scenarios, consolidated)
- Readability: Improved (clearer intent, DRY principle)

### Quality Metrics
- All tests have descriptive docstrings ✅
- All tests have appropriate markers ✅
- Test collection: 0 errors ✅
- Test discovery: Clear by marker + directory ✅

### Running Tests
```bash
# Fast feedback loop (unit tests only, <60 seconds)
pytest -m unit

# Before integration test merge
pytest -m "unit and not slow"

# Full verification
pytest tests/

# With coverage
pytest tests/ --cov=. --cov-report=term-missing
```

---

## Summary of Changes

### B.6 Impact (Parametrization)
- Consolidates duplicate test functions
- Reduces file size by ~40-60%
- Maintains test count (scenarios still covered)
- Improves maintainability (add new case = add one line)

### B.7 Impact (Markers & Docstrings)
- All tests discoverable by marker
- Clear test intent and requirements
- Easy to filter tests by category
- CI/CD can run different test sets efficiently

### Combined Impact (B.6 + B.7)
- Cleaner, more maintainable test suite
- Better documentation
- Easier onboarding for new developers
- Optimized CI/CD execution paths

