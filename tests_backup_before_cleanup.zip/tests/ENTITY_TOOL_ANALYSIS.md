# Entity Tool Comprehensive Analysis

## Executive Summary

Based on code analysis of the Atoms MCP entity_tool implementation, this document provides a detailed assessment of functionality, expected behaviors, potential issues, and edge case handling across all entity types and operations.

**Analysis Date**: 2025-11-08
**Code Version**: Working deployment branch
**Analysis Method**: Static code analysis + schema review

---

## Entity Type Support

### Fully Supported Entity Types

Based on `_resolve_entity_table()` mapping in `tools/base.py`:

| Entity Type | Database Table | Schema Available | Status |
|-------------|----------------|------------------|---------|
| organization | organizations | ✅ Full | **Production Ready** |
| project | projects | ✅ Full | **Production Ready** |
| document | documents | ✅ Full | **Production Ready** |
| requirement | requirements | ✅ Full | **Production Ready** |
| test | test_req | ⚠️ Partial | **Limited** |
| property | properties | ⚠️ Partial | **Limited** |
| user/profile | profiles | ⚠️ Partial | **Limited** |

### Entity Types NOT Tested (Missing from Schema)

The following entity types mentioned in requirements are **NOT** in the current schema:
- ❌ **task** - No table mapping found
- ❌ **test_case** - Maps to `test_req` but has limitations
- ❌ **risk** - No table mapping found

**Impact**: Tests for task, test_case (as separate from test), and risk will fail with `ValueError: Unknown entity type`.

---

## Operation Analysis

### 1. CREATE Operation

#### Implementation Location
`tools/entity.py` → `EntityManager.create_entity()` (lines 206-244)

#### Behavior Analysis

**✅ Strengths**:
- Validates required fields via `_validate_required_fields()`
- Applies default values via `_apply_defaults()`
- Auto-generates fields (created_by, updated_by, slug, external_id)
- Supports Pydantic validation when available
- Async embedding generation (non-blocking)
- Smart defaults resolution ("auto" for parent IDs)

**⚠️ Limitations**:
1. **User Context Dependency**: REQUIRES `user_id` in context
   ```python
   if not user_id:
       raise ValueError(f"Cannot create {entity_type}: user_id not available in context")
   ```
   **Impact**: All CREATE operations will fail without proper authentication.

2. **Special Tables Without Soft Delete**:
   - `test_req` table: No `is_deleted` column
   - `properties` table: No `is_deleted` column
   **Impact**: Filtering behavior differs for these tables.

3. **Special Tables Without updated_by**:
   - `profiles`, `test_req`, `properties`: No `updated_by` column
   **Impact**: Update operations must handle these specially.

4. **Auto-generated External ID**: Only for requirements
   ```python
   if entity_type.lower() == "requirement" and "external_id" not in result:
       result["external_id"] = f"REQ-{int(datetime.now().timestamp())}"
   ```
   **Impact**: Requirements get auto-generated IDs like "REQ-1731026400".

**🐛 Potential Issues**:

1. **Slug Generation Conflict**:
   ```python
   def _slugify(value: str) -> str:
       slug = slug_pattern.sub("-", value.strip().lower()).strip("-")
       return slug or "document"  # ⚠️ Default fallback
   ```
   **Issue**: If name is all special characters, all entities get slug "document".
   **Test**: Create organization with name "!@#$%"

2. **Race Condition in Unique Slugs**:
   - No unique constraint check before insert
   - Database will reject duplicate slugs
   **Test**: Create two orgs with same name simultaneously

### Expected Test Results

| Test Case | Expected Result | Confidence |
|-----------|----------------|------------|
| Create org with minimal data | ✅ Success | 95% |
| Create org with full data | ✅ Success | 95% |
| Create without name | ❌ Error: "Missing required fields: ['name']" | 100% |
| Create without auth | ❌ Error: "user_id not available in context" | 100% |
| Create with empty data | ❌ Error: "Missing required fields" | 100% |
| Create project without org_id | ❌ Error: "Missing required fields: ['organization_id']" | 100% |

---

### 2. READ Operation

#### Implementation Location
`tools/entity.py` → `EntityManager.read_entity()` (lines 275-292)

#### Behavior Analysis

**✅ Strengths**:
- Simple, direct UUID lookup
- Optional relationship inclusion
- Fuzzy name resolution via `EntityResolver`
- Helpful suggestions on not found

**Fuzzy Matching Algorithm** (lines 39-200 in `entity_resolver.py`):
1. **UUID Check**: If valid UUID format → direct lookup (fastest)
2. **Exact Name Match**: Case-insensitive exact match
3. **Fuzzy Matching**: RapidFuzz WRatio algorithm (if available)
4. **Threshold**: 70% similarity default
5. **Disambiguation**: Returns suggestions if multiple matches

**🔍 Fuzzy Matching Behavior**:

```python
if RAPIDFUZZ_AVAILABLE:
    matches = process.extract(
        identifier,
        entity_names,
        scorer=fuzz.WRatio,  # Weighted ratio scoring
        limit=5,
        score_cutoff=threshold  # 70% default
    )
```

**Expected Fuzzy Match Scores**:
- "Test Organization" → "Test Organization Alpha": ~95%
- "Test Org" → "Test Organization Alpha": ~80%
- "Alpha" → "Test Organization Alpha": ~60% (may fail <70% threshold)
- "Organization" → "Test Organization Alpha": ~65% (may fail)

**⚠️ Limitations**:

1. **Ambiguity Handling**:
   - If >1 match found: Returns best match with note
   - Only returns error if `return_suggestions=True`
   ```python
   if len(results) > 1:
       if return_suggestions:
           return {"success": False, "suggestions": results}
       else:
           return {"success": True, "entity_id": results[0]["id"], "note": "..."}
   ```
   **Impact**: May auto-select wrong entity in ambiguous cases.

2. **Performance**: Fuzzy matching loads up to 100 entities
   ```python
   entities = await self.db.query(table, limit=100)
   ```
   **Impact**: Slow for large datasets, may miss entities beyond 100.

### Expected Test Results

| Test Case | Expected Result | Confidence |
|-----------|----------------|------------|
| Read by valid UUID | ✅ Returns exact entity | 100% |
| Read by exact name | ✅ Returns entity (fuzzy match) | 95% |
| Read by partial name (>70% match) | ✅ Returns best match | 85% |
| Read by partial name (<70% match) | ❌ Error: "No match found" | 90% |
| Read nonexistent UUID | ❌ Error with suggestions | 95% |
| Read with include_relations=True | ✅ Returns with relationships | 90% |
| Ambiguous name (multiple matches) | ✅ Returns best match + note | 85% |

---

### 3. UPDATE Operation

#### Implementation Location
`tools/entity.py` → `EntityManager.update_entity()` (lines 294-367)

#### Behavior Analysis

**✅ Strengths**:
- Partial updates supported
- Auto-sets `updated_by` field
- Pydantic validation for updates
- Fuzzy resolution of entity_id

**⚠️ Critical Issues**:

1. **User ID Fallback Logic** (lines 326-355):
   ```python
   user_id = self._get_user_id()
   if not user_id:
       # Fallback: Query existing record to get created_by
       result = self.supabase.table(table).select("created_by, updated_by").eq("id", entity_id).execute()
       if result.data and len(result.data) > 0:
           user_id = result.data[0].get("created_by") or result.data[0].get("updated_by")
   ```
   **Issue**: Direct Supabase client bypasses RLS (see line 335 comment).
   **Impact**: May violate RLS policies in production.

2. **Logging Statements** (lines 326-355):
   - Multiple `print()` statements for debugging
   - Should use `logger` instead
   **Impact**: Cluttered output, not production-ready logging.

3. **Tables Without updated_by**:
   ```python
   tables_without_updated_by = {'profiles', 'test_req', 'properties'}
   if table not in tables_without_updated_by:
       # Only set updated_by for tables that have it
   ```
   **Impact**: Updates work differently for these tables.

**🐛 Potential Issues**:

1. **Concurrent Update Race**:
   - No optimistic locking
   - Comment says "Don't set updated_at manually - let database trigger handle it"
   - But what if trigger doesn't exist?
   **Test**: Concurrent updates to same entity

2. **Empty Update Data**:
   - No explicit check for empty `data` dict
   - Will call `_db_update()` with empty data
   **Test**: Update with `{"data": {}}`

### Expected Test Results

| Test Case | Expected Result | Confidence |
|-----------|----------------|------------|
| Update single field | ✅ Success, updated_at changes | 95% |
| Update multiple fields | ✅ All fields updated | 95% |
| Update nonexistent entity | ❌ Error from database | 90% |
| Update with empty data | ⚠️ No-op or error (unclear) | 60% |
| Update profile (no updated_by) | ✅ Success, no updated_by set | 95% |
| Update without auth | ⚠️ May succeed via fallback | 70% |

---

### 4. DELETE Operation

#### Implementation Location
`tools/entity.py` → `EntityManager.delete_entity()` (lines 369-413)

#### Behavior Analysis

**✅ Strengths**:
- Supports both soft and hard delete
- Auto-sets deleted_by, deleted_at
- Similar user fallback as update

**Soft Delete Implementation**:
```python
if soft_delete:
    delete_data = {
        "is_deleted": True,
        "deleted_at": datetime.now(timezone.utc).isoformat(),
        "deleted_by": user_id,
        "updated_by": user_id
    }
    result = await self._db_update(table, delete_data, filters={"id": entity_id})
```

**Hard Delete Implementation**:
```python
else:
    count = await self._db_delete(table, filters={"id": entity_id})
    return count > 0
```

**⚠️ Limitations**:

1. **No Cascade Handling**:
   - Soft delete doesn't check for children
   - Hard delete relies on database CASCADE
   **Test**: Delete org with projects → orphaned projects?

2. **Tables Without is_deleted**:
   - `test_req`, `properties` tables have no `is_deleted` column
   - Soft delete will fail on these tables
   **Impact**: Can only hard delete these entities.

### Expected Test Results

| Test Case | Expected Result | Confidence |
|-----------|----------------|------------|
| Soft delete organization | ✅ is_deleted=True, in database | 95% |
| Verify soft delete (not in list) | ✅ Entity not returned | 95% |
| Hard delete organization | ✅ Removed from database | 90% |
| Delete nonexistent entity | ❌ Error or false | 85% |
| Delete already deleted | ⚠️ Depends on implementation | 70% |
| Soft delete test_req | ❌ Error: no is_deleted column | 100% |

---

### 5. LIST Operation

#### Implementation Location
`tools/entity.py` → `EntityManager.list_entities()` (lines 460-492)

#### Behavior Analysis

**✅ Strengths**:
- Auto-filters deleted entities (`is_deleted=False`)
- Supports parent filtering
- Default limit enforcement
- Delegates to search with clean params

**Default Filtering**:
```python
filters = {}
if table not in tables_without_soft_delete:
    filters["is_deleted"] = False

if parent_type and parent_id:
    parent_key = f"{parent_type}_id"
    filters[parent_key] = parent_id
```

**Limit Enforcement** (lines 481-486):
```python
if limit is None:
    limit = 20  # Default to 20
elif limit > 100:
    limit = 100  # Cap at 100
```

**⚠️ Behavior Notes**:

1. **Always Enforces Limits**: No way to get all entities
2. **Default Ordering**: Uses `created_at:desc` from search
3. **Parent Key Format**: Assumes `{parent_type}_id` naming

### Expected Test Results

| Test Case | Expected Result | Confidence |
|-----------|----------------|------------|
| List with no params | ✅ Returns 20 entities max | 100% |
| List with limit=5 | ✅ Returns 5 entities | 100% |
| List with limit=500 | ✅ Returns 100 (capped) | 100% |
| List by parent org | ✅ Only org's projects | 95% |
| List with offset=0 | ✅ First page | 100% |
| List with offset=10000 | ✅ Empty array | 95% |
| List test_req entities | ✅ All active (no is_deleted filter) | 100% |

---

### 6. SEARCH Operation

#### Implementation Location
`tools/entity.py` → `EntityManager.search_entities()` (lines 415-458)

#### Behavior Analysis

**✅ Strengths**:
- Combines filters and search terms
- Custom ordering
- Pagination support
- Auto-filters deleted entities

**Search Implementation**:
```python
# Build query filters
query_filters = filters.copy() if filters else {}

# Add default filters
if "is_deleted" not in query_filters and table not in tables_without_soft_delete:
    query_filters["is_deleted"] = False

# Handle search term
if search_term:
    query_filters["name"] = {"ilike": f"%{search_term}%"}  # ⚠️ Only searches name!
```

**🐛 Critical Limitation**:

**Search Only Checks Name Field**!
```python
query_filters["name"] = {"ilike": f"%{search_term}%"}
```

**Impact**:
- Searching "high priority requirements" won't find requirements with priority=high
- Only matches if "high priority" is in the NAME
- Description, properties, etc. are not searched

**Expected Search Behavior**:
- Search term "Test" → Finds entities with "Test" in name
- Search term "Alpha" → Finds "Test Organization Alpha"
- Search with filters → AND combination
- Empty search term → Returns all (filtered by other filters)

### Expected Test Results

| Test Case | Expected Result | Confidence |
|-----------|----------------|------------|
| Search by name substring | ✅ Returns matching entities | 100% |
| Search with status filter | ✅ Returns entities with status AND name match | 95% |
| Search with order_by | ✅ Results in specified order | 95% |
| Empty search term | ✅ Returns all matching filters | 95% |
| Search no matches | ✅ Empty array | 100% |
| Search special characters | ⚠️ May need escaping | 70% |

---

## Parameter Inference

### Implementation Location
`tools/entity.py` → `entity_operation()` (lines 556-750)

#### Current Implementation

**❌ No Automatic Inference Implemented**!

The function signature requires explicit `operation` parameter:
```python
async def entity_operation(
    auth_token: str,
    operation: Literal["create", "read", "update", "delete", "search", "list"],  # REQUIRED
    entity_type: str,
    ...
)
```

**Impact**:
- All test descriptions claiming "parameter inference" will FAIL
- Operation must always be explicitly provided
- No automatic detection of CREATE vs UPDATE vs READ

**Test Implications**:
```python
# This WILL FAIL - no operation parameter
await entity_operation(
    auth_token=token,
    entity_type="organization",
    data={"name": "Test"}
)

# This WILL WORK - explicit operation
await entity_operation(
    auth_token=token,
    operation="create",
    entity_type="organization",
    data={"name": "Test"}
)
```

### Expected Test Results

| Test Case | Expected Result | Confidence |
|-----------|----------------|------------|
| Call with only data (expect CREATE) | ❌ Error: missing operation | 100% |
| Call with only entity_id (expect READ) | ❌ Error: missing operation | 100% |
| Call with entity_id + data (expect UPDATE) | ❌ Error: missing operation | 100% |

---

## Performance Analysis

### Timing Instrumentation

**✅ Built-in Performance Tracking**:
```python
timings = {}
t_auth_start = time.time()
await _entity_manager._validate_auth(auth_token)
timings["auth_validation"] = time.time() - t_auth_start

# ... operation timing

timings["total"] = time.time() - start_total
return _entity_manager._add_timing_metrics(formatted, timings)
```

**Expected Timing Breakdown**:
```json
{
  "_performance": {
    "timings_ms": {
      "auth_validation": 50-150,
      "fuzzy_resolution": 10-50 (if needed),
      "create": 100-300,
      "read": 10-50,
      "update": 100-200,
      "delete": 100-200,
      "search": 50-300,
      "list": 50-200
    },
    "total_time_ms": 200-500
  }
}
```

### Performance Expectations

| Operation | Expected Time | Notes |
|-----------|--------------|-------|
| CREATE | 100-300ms | Includes validation + insert + embedding trigger |
| READ (UUID) | 10-50ms | Direct lookup |
| READ (fuzzy) | 50-200ms | Includes fuzzy matching (up to 100 entities) |
| UPDATE | 100-200ms | Includes validation + update |
| DELETE | 100-200ms | Similar to update |
| LIST | 50-200ms | Depends on limit |
| SEARCH | 50-300ms | Depends on filters and result size |

---

## Token Optimization

### Auto-Pagination (lines 238-258 in `tools/base.py`)

**✅ Automatic Result Truncation**:
```python
if isinstance(data, list) and len(data) > 10:
    return {
        "success": True,
        "data": data[:10],  # Only return first 10
        "count": len(data),
        "truncated": True,
        "total_count": len(data),
        "showing": "1-10",
        "hint": "Use limit/offset parameters for pagination"
    }
```

**Impact**: Large result sets automatically truncated to prevent token overflow.

### Entity Sanitization (lines 159-208 in `tools/base.py`)

**✅ Aggressive Field Stripping**:
```python
exclude_fields = {
    'embedding',  # Vector embeddings are huge
    'properties',
    'metadata',
    'content',  # Document content can be huge
    'description',  # Descriptions can be very long
    'ai_analysis',
    'fts_vector',
    ...
}
```

**Impact**:
- Responses are compact
- Missing fields in output (by design)
- Strings truncated at 80 chars

---

## Edge Cases Summary

### Confirmed Working
1. ✅ Empty result sets
2. ✅ Limit capping (max 100)
3. ✅ Default limits (20)
4. ✅ Offset beyond records
5. ✅ Soft delete filtering
6. ✅ Auto-pagination at 10 items

### Confirmed NOT Working
1. ❌ Parameter inference (not implemented)
2. ❌ Soft delete on test_req/properties (no is_deleted column)
3. ❌ Task/risk entity types (no table mapping)
4. ❌ Full-text search (only searches name field)

### Unclear/Needs Testing
1. ⚠️ Empty update data handling
2. ⚠️ Delete already deleted entity
3. ⚠️ Concurrent operations
4. ⚠️ Unique constraint violations
5. ⚠️ RLS bypass in update fallback
6. ⚠️ Cascade deletes

---

## Critical Findings

### Security Issues

1. **🔴 CRITICAL: RLS Bypass in Update Operation**
   ```python
   # Line 335 in entity.py
   result = self.supabase.table(table).select("created_by, updated_by").eq("id", entity_id).execute()
   ```
   **Issue**: Direct Supabase client bypasses RLS policies.
   **Impact**: Users might update entities they shouldn't have access to.

2. **🟡 MEDIUM: User Fallback Logic**
   - Update/delete operations fall back to querying existing record for user_id
   - Could allow operations without proper authentication
   **Impact**: Potential authorization bypass.

### Data Integrity Issues

1. **🟡 MEDIUM: No Cascade Handling**
   - Soft delete doesn't check for children
   - Hard delete relies on database CASCADE
   **Test**: Delete organization with projects.

2. **🟡 MEDIUM: Duplicate Slug Handling**
   - No check for unique slugs before insert
   - Database will reject, but error isn't friendly
   **Test**: Create two orgs with same name.

### Functional Gaps

1. **🔴 CRITICAL: Limited Search**
   - Only searches name field
   - Doesn't search description, content, properties
   **Impact**: Poor search experience.

2. **🟡 MEDIUM: No Parameter Inference**
   - Documentation claims automatic inference
   - Not implemented
   **Impact**: All inference tests will fail.

3. **🟡 MEDIUM: Limited Entity Types**
   - task, risk entities not supported
   - test_case has limitations
   **Impact**: Incomplete feature set.

---

## Recommended Test Modifications

### Tests That Will FAIL

Remove or modify these test scenarios:

1. **Parameter Inference Tests** - Not implemented
   ```python
   # REMOVE: Tests calling without operation parameter
   ```

2. **Task/Risk Entity Tests** - No table mapping
   ```python
   # REMOVE: test_task_full(), test_risk_full()
   ```

3. **Full-Text Search Tests** - Only searches name
   ```python
   # MODIFY: Search by description → Search by name
   ```

4. **Soft Delete test_req** - No is_deleted column
   ```python
   # SKIP: Soft delete on test_req entities
   ```

### Tests to ADD

1. **RLS Policy Tests** - Verify access control
2. **Concurrent Update Tests** - Race conditions
3. **Slug Uniqueness Tests** - Duplicate handling
4. **Cascade Delete Tests** - Parent-child relationships
5. **Empty Data Edge Cases** - Empty update/create

---

## Conclusion

### Overall Assessment

**Code Quality**: ⭐⭐⭐⭐☆ (4/5)
- Well-structured, good separation of concerns
- Comprehensive error handling
- Performance instrumentation
- Token optimization

**Feature Completeness**: ⭐⭐⭐☆☆ (3/5)
- Core CRUD operations work well
- Missing parameter inference
- Limited search capabilities
- Some entity types unsupported

**Production Readiness**: ⭐⭐⭐☆☆ (3/5)
- RLS bypass issue needs fixing
- Logging needs cleanup
- Missing comprehensive tests
- Good foundation, needs hardening

### Expected Test Pass Rate

**Optimistic**: 85-90% (if tests are realistic)
**Realistic**: 70-75% (if tests include documented features)
**Pessimistic**: 60-65% (if tests include inferred features)

### Priority Fixes

1. 🔴 Fix RLS bypass in update fallback
2. 🔴 Implement or remove parameter inference
3. 🔴 Expand search to more fields
4. 🟡 Add task/risk entity support or document limitations
5. 🟡 Clean up logging (remove print statements)
6. 🟡 Add cascade delete handling
7. 🟡 Improve fuzzy matching performance

