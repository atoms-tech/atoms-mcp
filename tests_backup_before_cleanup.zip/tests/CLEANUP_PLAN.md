# Test Cleanup and Reorganization Plan

Goal: Remove all demos/examples and any legacy/backwards-compat code; align test suite with canonical FastMCP patterns and Pythonic standards; report current coverage and user story coverage; deliver a precise, low-risk execution plan.

---

Scope
- tests/ tree only (no src/ behavior changes)
- Remove: demo/example scripts, coverage bootstraps, ad-hoc runners, legacy httpx JSON-RPC wrappers, duplicate “complete/comprehensive” variants
- Standardize: file locations, names, markers, fixtures, parametrization

---

Part A — Inventory (Current State)

A1. Structure (observed)
- Canonical dirs present: unit/, integration/, e2e/, performance/, error_handling/, auth/, framework/, infrastructure/services under unit
- Non-canonical/utility in tests/: generate_query_test_report.py, measure_coverage.py, C1_APPLY_MARKERS_AND_DOCSTRINGS.py (old), C1_APPLY_MARKERS_AND_DOCSTRINGS_FIXED.py (tooling), test_coverage_*.py (legacy coverage shims)
- Duplicative naming: test_coverage_entity_complete.py, test_coverage_query_complete.py, test_coverage_100_percent.py

A2. Legacy/Back-compat indicators
- httpx JSON-RPC wrapper: remnants in unit/tools/test_workspace.py (partially migrated); integration/conftest.py references
- Coverage harnesses outside pytest: measure_coverage.py, test_coverage_* files
- Standalone OAuth demo: auth/test_auth.py (non-pytest; script-style)
- One-off generators/runners: generate_query_test_report.py

A3. Pythonic/pytest standards (gaps)
- Mixed script-style files in tests/ root
- Redundant module-level asyncio markers (some duplicate) vs function-level
- Inconsistent docstrings/parametrization across tools
- Mixed concerns (unit tests reaching network)

A4. Coverage and user-story coverage (initial)
- Structural coverage: entity, workflow, relationship, query, workspace present
- Cross-tool stories: integration/test_workflows.py present
- Gaps signaled by collection errors previously: unit/tools/test_query.py import pytest; adapters coverage vs real usage; DB-coupled coverage shims

---

Part B — Removal List (demos/examples/back-compat)

To remove (delete) or archive to tests/archive/ (if needed):
1) tests/C1_APPLY_MARKERS_AND_DOCSTRINGS.py (broken original) → delete
2) tests/test_coverage_100_percent.py → delete (redundant, DB-coupled)
3) tests/test_coverage_entity_complete.py → merge content into unit/tools/test_entity.py if unique; otherwise delete
4) tests/test_coverage_query_complete.py → merge into unit/tools/test_query.py if unique; otherwise delete
5) tests/auth/test_auth.py (script-style OAuth demo) → move to docs/examples or delete; not a pytest test
6) tests/generate_query_test_report.py → remove (non-test runner)
7) tests/measure_coverage.py → remove (use pytest-cov instead)
8) Any remaining httpx JSON-RPC helper blocks in unit/tools/* → migrate to mcp_client_inmemory and delete wrappers

Safety: before deleting coverage_* files, grep for unique scenarios and port into canonical tests where missing.

---

Part C — Reorg to Canonical Pythonic Layout

C1. File placement and names
- tools: unit/tools/test_{entity|workflow|relationship|query|workspace}.py (already present)
- integration: integration/test_{api|workflows}.py
- e2e: e2e/test_e2e.py
- performance: performance/test_benchmarks.py
- error handling: error_handling/test_errors.py
- auth: auth/test_auth.py (convert to pytest; otherwise remove)

C2. Pytest standards
- One behavior per test; descriptive names
- Markers: unit/integration/e2e/performance/security/database/slow as needed
- Parametrization: consolidate variants per B6_B7_REFACTORING_TEMPLATE.md
- Fixtures: prefer mcp_client_inmemory (unit), mcp_client_http (integration), full_deployment (e2e)

C3. Code style
- Remove duplicate @pytest.mark.asyncio at function & module level; prefer function-level where needed
- Consistent docstrings per template
- No script entrypoints (if __name__ == '__main__') under tests/

---

Part D — Coverage & User Story Coverage Plan

D1. Code coverage
- Use pytest-cov across suite: `pytest tests/ --cov=src --cov-report=term-missing --cov-report=html --cov-fail-under=95`
- Remove coverage_* shims; rely on pytest-cov
- Add module mapping: ensure src/ modules map to canonical test files

D2. User stories (acceptance paths)
- Story: Org→Workspace→Project→Docs→Requirements→Search (integration/test_workflows.py)
- Story: Relationship traceability (unit/tools/test_relationship.py + integration workflow)
- Story: Query semantics (unit/tools/test_query.py scenarios)
- Story: Workspace context switching (unit/tools/test_workspace.py)
- Story: Error & security edges (error_handling/test_errors.py)

Checklist: For each story, confirm Given/When/Then coverage and edge cases; add parametrized scenarios where gaps exist.

---

Part E — Execution Steps (low risk, reversible)

E1. Identify unique scenarios in legacy files
- Diff `test_coverage_entity_complete.py` and `unit/tools/test_entity.py`; port missing cases
- Diff `test_coverage_query_complete.py` and `unit/tools/test_query.py`; port missing cases

E2. Remove demos/back-compat
- Delete: C1_APPLY_MARKERS_AND_DOCSTRINGS.py, test_coverage_100_percent.py, auth/test_auth.py, generate_query_test_report.py, measure_coverage.py

E3. Finish fixture migration
- Ensure no `httpx` in unit/; update integration fixtures to use `mcp_client_http`

E4. Parametrization pass
- Apply template to workflow, relationship, query, workspace to reduce duplicate tests

E5. Marker/docstring normalization
- Remove duplicate asyncio markers; ensure category markers present at test function or class

E6. Validate & report
- Run: collect-only, then full suite with coverage; compare to PERFORMANCE_BASELINE.json
- Output: CLEANUP_CHANGELOG.md summarizing removals and ports

---

Part F — Commands (to be run)

# 1) Safety snapshot (optional)
zip -r tests_backup_before_cleanup.zip tests

# 2) Unique scenario diffing (manual review suggested)
#   Use ripgrep to spot unique assertions
rg -n "assert .*entity_" tests/test_coverage_entity_complete.py
rg -n "assert .*query_" tests/test_coverage_query_complete.py

# 3) Deletes
rm tests/C1_APPLY_MARKERS_AND_DOCSTRINGS.py || true
rm tests/test_coverage_100_percent.py || true
rm tests/auth/test_auth.py || true
rm tests/generate_query_test_report.py || true
rm tests/measure_coverage.py || true

# 4) Lint: ensure no httpx in unit
rg -n "httpx|AsyncClient" tests/unit || true

# 5) Validate
pytest --collect-only -q
pytest tests/ --cov=src --cov-report=term-missing --cov-report=html --cov-fail-under=95

---

Deliverables
- CLEANUP_CHANGELOG.md (what removed/why, where scenarios moved)
- Updated canonical test files with any ported assertions
- Coverage report (htmlcov/) and summary in CLEANUP_CHANGELOG.md
- Marker/docstring consistency applied
