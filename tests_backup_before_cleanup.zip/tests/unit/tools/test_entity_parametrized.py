"""Parametrized Entity Tests Example.

This module demonstrates the parametrization patterns from B6_B7_REFACTORING_TEMPLATE.md,
consolidating duplicate tests using @pytest.mark.parametrize.
"""

import uuid
import time
import pytest

pytestmark = [pytest.mark.unit]


class TestEntityCreateParametrized:
    """Parametrized CREATE operations across all entity types."""
    
    @pytest.mark.parametrize("entity_type,entity_data", [
        ("organization", {
            "name": "Test Org",
            "type": "team",
        }),
        ("project", {
            "name": "Test Project",
            "organization_id": "auto",  # Will use workspace context
        }),
        ("document", {
            "name": "Test Doc",
            "content": "Test content",
        }),
        ("requirement", {
            "name": "REQ-001",
            "priority": "high",
        }),
        ("test_entity", {
            "title": "Test Case",
            "description": "Test description",
        }),
        ("property", {
            "key": "prop1",
            "value": "val1",
        }),
    ])
    @pytest.mark.asyncio
    async def test_entity_create_variants(self, mcp_client_inmemory, entity_type: str, entity_data: dict):
        """Test entity creation across all entity types.
        
        Validates that each entity type can be created with appropriate data
        and returns success response. Tests cover organization, project, document,
        requirement, test entity, and property types.
        
        Args:
            mcp_client_inmemory: In-memory MCP client fixture
            entity_type: Type of entity to create (from parametrize)
            entity_data: Entity-specific creation data (from parametrize)
        """
        result = await mcp_client_inmemory.call_tool("entity_tool", {
            "operation": "create",
            "entity_type": entity_type,
            "data": entity_data,
        })
        
        assert result.success, f"Failed to create {entity_type}: {result.error if hasattr(result, 'error') else result}"
        assert result.data.get("id"), f"No ID returned for {entity_type}"
        assert result.data.get("created_at"), f"No created_at for {entity_type}"   


class TestEntityReadParametrized:
    """Parametrized READ operations across all entity types."""
    
    @pytest.mark.parametrize("entity_type", [
        "organization",
        "project",
        "document",
        "requirement",
        "test_entity",
        "property",
    ])
    @pytest.mark.asyncio
    async def test_entity_read_variants(self, mcp_client_inmemory, entity_type: str):
        """Test entity read operations across all entity types.
        
        Validates that entities can be retrieved by ID and contain expected
        fields. Tests all entity types to ensure consistent behavior.
        
        Args:
            mcp_client_inmemory: In-memory MCP client fixture
            entity_type: Type of entity to test (from parametrize)
        """
        # First create an entity
        create_result = await mcp_client_inmemory.call_tool("entity_tool", {
            "operation": "create",
            "entity_type": entity_type,
            "data": {"name": f"Test {entity_type}_{uuid.uuid4().hex[:8]}"},
        })
        assert create_result.success
        entity_id = create_result.data["id"]
        
        # Then read it back
        read_result = await mcp_client_inmemory.call_tool("entity_tool", {
            "operation": "read",
            "entity_type": entity_type,
            "entity_id": entity_id,
        })
        
        assert read_result.success, f"Failed to read {entity_type}: {read_result.error if hasattr(read_result, 'error') else read_result}"
        assert read_result.data["id"] == entity_id
        assert read_result.data.get("created_at")
        

class TestEntitySearchParametrized:
    """Parametrized SEARCH operations with different query patterns."""
    
    @pytest.mark.parametrize("entity_type,term,expected_count", [
        ("organization", "org", 1),
        ("project", "project", 1),
        ("document", "doc", 1),
        ("requirement", "req", 1),
        ("test_entity", "test", 1),
        ("property", "prop", 1),
    ])
    @pytest.mark.asyncio
    async def test_entity_search_variants(self, mcp_client_inmemory, entity_type: str, term: str, expected_count: int):
        """Test entity search across different entity types.
        
        Validates that search functionality works correctly for each entity type
        with appropriate search terms and returns expected number of results.
        
        Args:
            mcp_client_inmemory: In-memory MCP client fixture
            entity_type: Type of entity to search (from parametrize)
            term: Search term (from parametrize)
            expected_count: Expected minimum matches (from parametrize)
        """
        # Create entities with searchable content
        for i in range(3):
            await mcp_client_inmemory.call_tool("entity_tool", {
                "operation": "create",
                "entity_type": entity_type,
                "data": {
                    "name": f"{term.capitalize()} Test {i}",
                    "description": f"Searchable {entity_type} for testing",
                },
            })
        
        # Search for entities
        search_result = await mcp_client_inmemory.call_tool("entity_tool", {
            "operation": "search",
            "entity_type": entity_type,
            "query": term,
        })
        
        assert search_result.success, f"Search failed for {entity_type}"
        assert len(search_result.data.get("items", [])) >= expected_count
        
        # Verify results match search term
        for item in search_result.data.get("items", [])[:expected_count]:
            assert term.lower() in item["name"].lower() or term.lower() in item.get("description", "").lower()
        

class TestEntityDeleteParametrized:
    """Parametrized DELETE operations (soft and hard)."""
    
    @pytest.mark.parametrize("entity_type,soft_delete", [
        ("organization", True),
        ("project", True),
        ("document", False),
        ("requirement", True),
        ("test_entity", False),
        ("property", True),
    ])
    @pytest.mark.asyncio
    async def test_entity_delete_variants(self, mcp_client_inmemory, entity_type: str, soft_delete: bool):
        """Test entity deletion (soft and hard) across entity types.
        
        Validates that entities can be deleted both with soft delete (marks as deleted)
        and hard delete (actually removes record) depending on entity type.
        
        Args:
            mcp_client_inmemory: In-memory MCP client fixture
            entity_type: Type of entity to delete (from parametrize)
            soft_delete: Whether to use soft delete (from parametrize)
        """
        # Create an entity first
        create_result = await mcp_client_inmemory.call_tool("entity_tool", {
            "operation": "create",
            "entity_type": entity_type,
            "data": {"name": f"Delete Test {entity_type}_{uuid.uuid4().hex[:8]}"},
        })
        assert create_result.success
        entity_id = create_result.data["id"]
        
        # Delete the entity
        delete_result = await mcp_client_inmemory.call_tool("entity_tool", {
            "operation": "delete",
            "entity_type": entity_type,
            "entity_id": entity_id,
            "soft_delete": soft_delete,
        })
        
        assert delete_result.success, f"Failed to delete {entity_type}"
        
        # Verify entity is gone (deleted or not visible)
        read_result = await mcp_client_inmemory.call_tool("entity_tool", {
            "operation": "read",
            "entity_type": entity_type,
            "entity_id": entity_id,
        })
        
        if soft_delete:
            # Soft delete should still exist but be marked deleted
            assert read_result.success
            assert read_result.data.get("deleted_at") or read_result.data.get("deleted")
        else:
            # Hard delete should not exist
            assert not read_result.success or not read_result.data