"""Fixtures for unit tool tests using in-memory FastMCP Client.

This conftest provides:
- mcp_server: Session-scoped FastMCP server with registered tools
- mcp_client_inmemory: In-memory async client for fast deterministic tests
- Parametrization helpers for entity types, operations, scenarios
"""

import pytest
from unittest.mock import AsyncMock, MagicMock
from typing import List, Dict, Any


# Note: mcp_server moved to fast_mcp_server above

@pytest.fixture
async def mcp_client_inmemory(fast_mcp_server):
    """Provide in-memory MCP client for fast unit tests.
    
    Usage:
        @pytest.mark.unit
        async def test_entity_creation(mcp_client_inmemory):
            result = await mcp_client_inmemory.call_tool(
                "entity_tool",
                {"operation": "create", "entity_type": "organization", ...}
            )
            assert result.success
    
    Benefits:
        - Deterministic (no network)
        - Fast (<1ms per call)
        - Full debugger support
        - No external service dependencies
    """
    from fastmcp import Client
    
    async with Client(fast_mcp_server) as client:
        yield client


@pytest.fixture
async def mcp_client_inmemory(mcp_server):
    """Provide in-memory MCP client for fast unit tests.
    
    Usage:
        @pytest.mark.unit
        async def test_entity_creation(mcp_client_inmemory):
            result = await mcp_client_inmemory.call_tool(
                "entity_tool",
                {"operation": "create", "entity_type": "organization", ...}
            )
            assert result.success
    
    Benefits:
        - Deterministic (no network)
        - Fast (<1ms per call)
        - Full debugger support
        - No external service dependencies
    """
    from fastmcp import Client
    
    async with Client(mcp_server) as client:
        yield client


@pytest.fixture
def mcp_server_mock():
    """Mock MCP server for testing error conditions."""
    mock_server = AsyncMock()
    mock_server.call_tool = AsyncMock()
    mock_server.list_tools = MagicMock()
    return mock_server


# Test Data Factories

@pytest.fixture
def entity_factory():
    """Factory for generating test entities with context."""
    from tests.framework.test_data_generators import TestDataGenerator
    return TestDataGenerator()

@pytest.fixture
def test_data_fixtures(entity_factory):
    """Provides a collection of entity data for testing."""
    return {
        "organizations": [
            entity_factory.create_entity_data("organization", {"name": "basic"}),
            entity_factory.create_entity_data("organization", {"name": "with_type_team"}),
        ],
        "projects": [
            entity_factory.create_entity_data("project", {"name": "with_auto_context"}),
            entity_factory.create_entity_data("project", {"name": "with_explicit_id"}),
        ],
        "documents": [
            entity_factory.create_entity_data("document", {"name": "basic"}),
            entity_factory.create_entity_data("document", {"name": "with_auto_context"}),
        ],
        "requirements": [
            entity_factory.create_entity_data("requirement", {"name": "basic"}),
            entity_factory.create_entity_data("requirement", {"name": "with_high_priority"}),
        ],
    }

# Test Helper Fixtures
@pytest.fixture
def fast_mcp_server():
    """Configure FastMCP server for optimal test performance."""
    from fastmcp import FastMCP
    
    server = FastMCP("atoms-test-server")
    
    # Configure for testing
    # This would normally register tools via decorators
    try:
        from tools import register_all_tools
        if register_all_tools:
            register_all_tools(server)
    except (ImportError, AttributeError):
        # Tools are automatically registered via decorators
        pass
    
    return server

# Parametrization Fixtures - for use with @pytest.mark.parametrize

@pytest.fixture
def entity_types() -> List[str]:
    """Entity type variations for parametrization.
    
    Usage:
        @pytest.mark.unit
        @pytest.mark.parametrize("entity_type", ["organization", "project", "document"])
        async def test_entity_operation(mcp_client_inmemory, entity_type):
            result = await mcp_client_inmemory.call_tool(...)
            assert result.success
    """
    return [
        "organization",
        "project",
        "document",
        "requirement",
        "test_entity",
        "property",
    ]


@pytest.fixture
def operations() -> List[str]:
    """Operation variations (CRUD + search/list/batch)."""
    return [
        "create",
        "read",
        "update",
        "delete",
        "list",
        "search",
        "batch",
    ]


@pytest.fixture
def scenarios() -> List[Dict[str, Any]]:
    """Scenario variations (success, error, edge cases)."""
    return [
        {"name": "success", "expect_success": True},
        {"name": "invalid_input", "expect_success": False},
        {"name": "missing_required", "expect_success": False},
        {"name": "edge_case_empty", "expect_success": False},
    ]


@pytest.fixture
def create_scenarios() -> List[Dict[str, Any]]:
    """CREATE operation scenarios."""
    return [
        {"name": "basic", "expect_success": True, "auto_context": False},
        {"name": "with_auto_context", "expect_success": True, "auto_context": True},
        {"name": "with_explicit_id", "expect_success": True, "explicit_id": True},
        {"name": "missing_required", "expect_success": False, "data": {}},
    ]


@pytest.fixture
def read_scenarios() -> List[Dict[str, Any]]:
    """READ operation scenarios."""
    return [
        {"name": "basic", "expect_success": True, "include_relations": False},
        {"name": "with_relations", "expect_success": True, "include_relations": True},
        {"name": "not_found", "expect_success": False, "entity_id": "invalid-id"},
    ]


@pytest.fixture
def update_scenarios() -> List[Dict[str, Any]]:
    """UPDATE operation scenarios."""
    return [
        {"name": "basic", "expect_success": True},
        {"name": "invalid_id", "expect_success": False},
        {"name": "missing_entity_id", "expect_success": False},
    ]


@pytest.fixture
def delete_scenarios() -> List[Dict[str, Any]]:
    """DELETE operation scenarios."""
    return [
        {"name": "soft_delete", "expect_success": True, "soft_delete": True},
        {"name": "hard_delete", "expect_success": True, "soft_delete": False},
        {"name": "not_found", "expect_success": False},
    ]


@pytest.fixture
def search_scenarios() -> List[Dict[str, Any]]:
    """SEARCH operation scenarios."""
    return [
        {"name": "by_term", "expect_success": True, "search_term": "test"},
        {"name": "with_filters", "expect_success": True, "filters": {}},
        {"name": "with_ordering", "expect_success": True, "order_by": "created_at"},
    ]


@pytest.fixture
def list_scenarios() -> List[Dict[str, Any]]:
    """LIST operation scenarios."""
    return [
        {"name": "basic", "expect_success": True},
        {"name": "with_pagination", "expect_success": True, "limit": 10, "offset": 0},
        {"name": "by_parent", "expect_success": True, "parent_id": "test-parent"},
    ]


@pytest.fixture
def batch_scenarios() -> List[Dict[str, Any]]:
    """BATCH operation scenarios."""
    return [
        {"name": "create_multiple", "expect_success": True, "count": 3},
        {"name": "create_organizations", "expect_success": True, "entity_type": "organization", "count": 5},
    ]


@pytest.fixture
def workflow_types() -> List[str]:
    """Workflow type variations."""
    return [
        "standard_workflow",
        "branching_workflow",
        "parallel_workflow",
        "error_recovery_workflow",
        "transaction_workflow",
    ]


@pytest.fixture
def relationship_types() -> List[str]:
    """Relationship type variations."""
    return [
        "traces_to",
        "relates_to",
        "depends_on",
        "parent_of",
        "references",
    ]


@pytest.fixture
def query_types() -> List[str]:
    """Query type variations."""
    return [
        "semantic_search",
        "filter_query",
        "full_text_search",
        "field_search",
        "aggregation",
    ]
