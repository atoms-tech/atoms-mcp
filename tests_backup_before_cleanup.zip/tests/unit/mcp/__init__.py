"""MCP server unit tests."""
