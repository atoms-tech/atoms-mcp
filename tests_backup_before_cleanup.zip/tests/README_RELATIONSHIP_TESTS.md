# Relationship Tool Test Suite - Quick Reference

## Overview

This directory contains comprehensive tests for the `relationship_tool`, covering all relationship types and operations.

## Test Files

- **test_relationship_tool_comprehensive.py** - Main comprehensive test suite (60+ tests)
- **test_relationship_tool.py** - Original test suite (legacy)

## Quick Start

### 1. Prerequisites

Ensure you have the required environment variables set:

```bash
export NEXT_PUBLIC_SUPABASE_URL="https://your-project.supabase.co"
export NEXT_PUBLIC_SUPABASE_ANON_KEY="your-anon-key"
export ATOMS_TEST_EMAIL="test@example.com"
export ATOMS_TEST_PASSWORD="your-test-password"
export ATOMS_FASTMCP_BASE_URL="http://127.0.0.1:8000"
export ATOMS_FASTMCP_HTTP_PATH="/api/mcp"
```

### 2. Start MCP Server

```bash
# In one terminal
python server.py
```

### 3. Run Tests

```bash
# Run all relationship tests
PYTHONPATH=. python -m pytest tests/test_relationship_tool_comprehensive.py -o addopts="" -v -s

# Run tests for a specific relationship type
PYTHONPATH=. python -m pytest tests/test_relationship_tool_comprehensive.py::TestMemberRelationship -o addopts="" -v -s

# Run a specific test
PYTHONPATH=. python -m pytest tests/test_relationship_tool_comprehensive.py::TestMemberRelationship::test_link_organization_member_success -o addopts="" -v -s
```

## Test Structure

### Test Classes

1. **TestMemberRelationship** - Organization/project membership tests
2. **TestAssignmentRelationship** - User assignment tests
3. **TestTraceLinkRelationship** - Requirement traceability tests
4. **TestRequirementTestRelationship** - Test coverage tests
5. **TestInvitationRelationship** - Organization invitation tests
6. **TestErrorCasesAndEdgeCases** - Error handling and edge case tests
7. **TestComprehensiveSummary** - Summary test across all types

### Operations Tested

Each relationship type is tested with all operations:
- `link` - Create relationships
- `unlink` - Remove relationships
- `list` - Query with filters and pagination
- `check` - Verify existence
- `update` - Modify metadata

## Example Test Runs

### Test Member Operations

```bash
# Test organization member creation
PYTHONPATH=. python -m pytest tests/test_relationship_tool_comprehensive.py::TestMemberRelationship::test_link_organization_member_success -o addopts="" -v -s

# Test project member with context
PYTHONPATH=. python -m pytest tests/test_relationship_tool_comprehensive.py::TestMemberRelationship::test_link_project_member_with_org_context -o addopts="" -v -s

# Test member role updates
PYTHONPATH=. python -m pytest tests/test_relationship_tool_comprehensive.py::TestMemberRelationship::test_update_member_role -o addopts="" -v -s
```

### Test Assignment Operations

```bash
# Test assignment creation
PYTHONPATH=. python -m pytest tests/test_relationship_tool_comprehensive.py::TestAssignmentRelationship::test_link_assignment_success -o addopts="" -v -s

# Test assignment filtering
PYTHONPATH=. python -m pytest tests/test_relationship_tool_comprehensive.py::TestAssignmentRelationship::test_list_assignments_with_status_filter -o addopts="" -v -s
```

### Test Trace Link Operations

```bash
# Test trace link creation
PYTHONPATH=. python -m pytest tests/test_relationship_tool_comprehensive.py::TestTraceLinkRelationship::test_link_trace_link_success -o addopts="" -v -s

# Test bidirectional links
PYTHONPATH=. python -m pytest tests/test_relationship_tool_comprehensive.py::TestTraceLinkRelationship::test_bidirectional_trace_links -o addopts="" -v -s
```

### Test Error Cases

```bash
# Run all error case tests
PYTHONPATH=. python -m pytest tests/test_relationship_tool_comprehensive.py::TestErrorCasesAndEdgeCases -o addopts="" -v -s
```

### Generate Summary

```bash
# Run summary test to see operation success rates
PYTHONPATH=. python -m pytest tests/test_relationship_tool_comprehensive.py::TestComprehensiveSummary -o addopts="" -v -s
```

## Test Coverage

### By Relationship Type

| Type              | Tests | Coverage |
|-------------------|-------|----------|
| member            | 10    | All ops  |
| assignment        | 10    | All ops  |
| trace_link        | 10    | All ops  |
| requirement_test  | 9     | All ops  |
| invitation        | 11    | All ops  |
| Error cases       | 10+   | Edge cases |
| **Total**         | 60+   | 100%     |

### By Operation

| Operation | Tests per Type | Total |
|-----------|---------------|-------|
| link      | 2-3           | 12+   |
| unlink    | 1-2           | 7+    |
| list      | 2-4           | 15+   |
| check     | 1-2           | 7+    |
| update    | 1-2           | 7+    |

## Additional Resources

- **Full Test Report**: `/RELATIONSHIP_TOOL_TEST_REPORT.md`
- **Implementation Code**: `/tools/relationship.py`
- **Base Classes**: `/tools/base.py`
