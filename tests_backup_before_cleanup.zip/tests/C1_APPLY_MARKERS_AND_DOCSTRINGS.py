#!/usr/bin/env python3
\"\"\"
C.1 Automation Script: Apply Markers & Docstrings to All Tests

This script adds @pytest.mark decorators and comprehensive docstrings to all test functions
following the patterns in B6_B7_REFACTORING_TEMPLATE.md

Usage:
    source .venv/bin/activate
    python tests/C1_APPLY_MARKERS_AND_DOCSTRINGS.py [--dry-run]

Options:
    --dry-run: Print changes without writing to files
\"\"\"

import os
import re
import sys
from pathlib import Path
from typing import Dict, List, Tuple

# Marker configurations by directory pattern
MARKER_CONFIG = {
    'tests/unit/tools': ['unit'],
    'tests/unit/infrastructure': ['unit', 'database'],
    'tests/integration': ['integration'],
    'tests/e2e': ['e2e'],
    'tests/performance': ['performance'],
    'tests/security': ['security'],
}

SECONDARY_MARKERS = {
    # Tests that should have @pytest.mark.slow (>5 seconds)
    'test_complete_user_workflow': ['slow'],
    'test_api_concurrent_requests': ['slow'],
    'test_throughput_concurrent': ['slow'],
    'test_concurrent': ['slow'],
    'benchmark': ['slow'],
    # Database-specific
    'test_supabase': ['database'],
    'test_auth': ['database'],
    'test_config': ['database'],
    # Requires live services
    'test_e2e': ['requires_db'],
    'test_integration_workflows': ['requires_db'],
}

DOCSTRING_TEMPLATE = '''\"\"\"Brief one-line description of what's being tested.
    
This test validates:
- Aspect 1
- Aspect 2
- Aspect 3

Markers applied:
- @pytest.mark.{markers}: Test category

Fixtures used:
- fixture_name: Description

Expected behavior:
- Success: Description

Args:
    Fixture parameters listed here
\"\"\"'''


def determine_markers(file_path: str, test_name: str) -> List[str]:
    \"\"\"Determine which markers should be applied to a test function.\"\"\"
    markers = []
    
    # Primary marker based on directory
    for pattern, mark_list in MARKER_CONFIG.items():
        if pattern in file_path:
            markers.extend(mark_list)
            break
    
    # Secondary markers based on test name
    for pattern, mark_list in SECONDARY_MARKERS.items():
        if pattern.lower() in test_name.lower():
            markers.extend(mark_list)
    
    # Remove duplicates while preserving order
    seen = set()
    unique_markers = []
    for marker in markers:
        if marker not in seen:
            seen.add(marker)
            unique_markers.append(marker)
    
    return unique_markers


def has_pytest_mark(test_func_text: str) -> bool:
    \"\"\"Check if test function already has @pytest.mark decorators.\"\"\"
    lines = test_func_text.split('\\n')
    for line in lines[:10]:  # Check first 10 lines
        if '@pytest.mark' in line:
            return True
    return False


def has_docstring(test_func_text: str) -> bool:
    \"\"\"Check if test function already has a docstring.\"\"\"
    lines = test_func_text.split('\\n')
    for i, line in enumerate(lines[:5]):  # Check first 5 lines
        if '\"\"\"' in line or \"'''\" in line:
            return True
    return False


def extract_test_functions(file_path: str) -> List[Tuple[int, str, str]]:
    \"\"\"Extract test functions from file.
    
    Returns:
        List of (line_number, test_name, full_function_text)
    \"\"\"
    with open(file_path, 'r') as f:
        content = f.read()
    
    test_functions = []
    lines = content.split('\\n')
    
    i = 0
    while i < len(lines):
        line = lines[i]
        
        # Look for test function definition
        if line.strip().startswith('def test_') or line.strip().startswith('async def test_'):
            # Extract function name
            match = re.search(r'def (test_\\w+)', line)
            if match:
                test_name = match.group(1)
                line_number = i + 1
                
                # Collect function body until next def or class
                func_lines = [line]
                i += 1
                indent_level = len(line) - len(line.lstrip())
                
                while i < len(lines):
                    next_line = lines[i]
                    if next_line.strip() and not next_line.startswith(' ' * (indent_level + 1)) and (next_line.strip().startswith('def ') or next_line.strip().startswith('class ') or next_line.strip().startswith('@')):
                        break
                    func_lines.append(next_line)
                    i += 1
                
                func_text = '\\n'.join(func_lines)
                test_functions.append((line_number, test_name, func_text))
                continue
        
        i += 1
    
    return test_functions


def add_markers_and_docstring(func_text: str, markers: List[str]) -> str:
    \"\"\"Add markers and docstring to test function.\"\"\"
    lines = func_text.split('\\n')
    
    # Find the function definition line
    func_def_idx = None
    for idx, line in enumerate(lines):
        if 'def test_' in line:
            func_def_idx = idx
            break
    
    if func_def_idx is None:
        return func_text
    
    # Build decorator lines
    decorator_lines = []
    if '@pytest.mark.asyncio' not in func_text:
        decorator_lines.append('@pytest.mark.asyncio')
    
    for marker in markers:
        decorator_lines.append(f'@pytest.mark.{marker}')
    
    # Find insertion point (before @pytest.mark decorators if they exist, otherwise before def)
    insert_idx = func_def_idx
    for i in range(func_def_idx - 1, -1, -1):
        if lines[i].strip().startswith('@'):
            insert_idx = i
        else:
            break
    
    # Check if it already has the markers
    existing_markers = [line.strip() for line in lines[insert_idx:func_def_idx] if line.strip().startswith('@')]
    new_markers = set(decorator_lines) - set(existing_markers)
    
    if not new_markers:
        return func_text  # Already has markers
    
    # Add decorators
    for marker_line in sorted(new_markers):
        lines.insert(insert_idx, marker_line)
        func_def_idx += 1
    
    # Add docstring after function definition
    docstring_idx = func_def_idx + 1
    
    # Check if docstring already exists
    if docstring_idx < len(lines) and ('\"\"\"' in lines[docstring_idx] or \"'''\" in lines[docstring_idx]):
        return '\\n'.join(lines)  # Already has docstring
    
    # Find the correct indentation for docstring
    func_line = lines[func_def_idx]
    indent = len(func_line) - len(func_line.lstrip())
    docstring_indent = ' ' * (indent + 4)
    
    # Build docstring
    doc_lines = [
        docstring_indent + '\"\"\"Test function for FastMCP tool.',
        docstring_indent + '',
        docstring_indent + 'Validates expected behavior with appropriate assertions.',
        docstring_indent + '',
        docstring_indent + 'Markers:',
    ]
    
    for marker in sorted(markers):
        doc_lines.append(docstring_indent + f'- @pytest.mark.{marker}')
    
    doc_lines.extend([
        docstring_indent + '\"\"\"',
    ])
    
    # Insert docstring
    for i, doc_line in enumerate(doc_lines):
        lines.insert(docstring_idx + i, doc_line)
    
    return '\\n'.join(lines)


def process_file(file_path: str, dry_run: bool = False) -> Dict[str, int]:
    \"\"\"Process a single test file.\"\"\"
    stats = {'modified': 0, 'added_markers': 0, 'added_docstrings': 0, 'skipped': 0}
    
    test_functions = extract_test_functions(file_path)
    if not test_functions:
        return stats
    
    with open(file_path, 'r') as f:
        original_content = f.read()
    
    new_content = original_content
    
    for line_num, test_name, func_text in test_functions:
        markers = determine_markers(file_path, test_name)
        
        if not markers:
            stats['skipped'] += 1
            continue
        
        # Check if modification needed
        already_has_marks = any(f'@pytest.mark.{m}' in func_text for m in markers)
        already_has_docstring = has_docstring(func_text)
        
        if already_has_marks and already_has_docstring:
            stats['skipped'] += 1
            continue
        
        # Apply changes
        modified_func = add_markers_and_docstring(func_text, markers)
        
        if modified_func != func_text:
            new_content = new_content.replace(func_text, modified_func, 1)
            stats['modified'] += 1
            if not already_has_marks:
                stats['added_markers'] += 1
            if not already_has_docstring:
                stats['added_docstrings'] += 1
    
    if not dry_run and new_content != original_content:
        with open(file_path, 'w') as f:
            f.write(new_content)
    
    return stats


def main():
    \"\"\"Main entry point.\"\"\"
    dry_run = '--dry-run' in sys.argv
    
    test_dir = Path('/Users/kooshapari/temp-PRODVERCEL/485/kush/atoms-mcp-prod/tests')
    test_files = list(test_dir.rglob('test_*.py'))
    
    print(f'Found {len(test_files)} test files')
    print(f'Dry run: {dry_run}\\n')
    
    total_stats = {'modified': 0, 'added_markers': 0, 'added_docstrings': 0, 'skipped': 0}
    
    for test_file in sorted(test_files):
        file_path = str(test_file)
        if 'archive' in file_path or '__pycache__' in file_path:
            continue
        
        stats = process_file(file_path, dry_run)
        
        if stats['modified'] > 0:
            print(f'{file_path}:')
            print(f'  Modified: {stats[\"modified\"]}')
            print(f'  Added markers: {stats[\"added_markers\"]}')
            print(f'  Added docstrings: {stats[\"added_docstrings\"]}')
        
        for key in total_stats:
            total_stats[key] += stats[key]
    
    print(f'\\nSummary:')
    print(f'  Total modified: {total_stats[\"modified\"]}')
    print(f'  Total markers added: {total_stats[\"added_markers\"]}')
    print(f'  Total docstrings added: {total_stats[\"added_docstrings\"]}')
    print(f'  Total skipped: {total_stats[\"skipped\"]}')
    
    if dry_run:
        print('\\n(Dry run - no files were modified)')


if __name__ == '__main__':
    main()
