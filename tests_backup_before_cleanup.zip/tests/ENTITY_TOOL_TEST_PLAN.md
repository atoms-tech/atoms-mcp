# Comprehensive Entity Tool Test Plan

## Overview

This document describes the comprehensive test plan for the Atoms MCP `entity_tool`, covering all entity types, operations, and edge cases.

## Test Suite Information

**Test File**: `/Users/kooshapari/temp-PRODVERCEL/485/kush/atoms-mcp-prod/tests/test_entity_tool_complete.py`

**Execution**:
```bash
python tests/test_entity_tool_complete.py
```

**Requirements**:
- Active Supabase instance
- Valid authentication credentials
- Environment variables configured (see `.env`)

## Entity Types Tested

1. **organization** - Top-level organizational units
2. **project** - Projects within organizations
3. **document** - Documents within projects
4. **requirement** - Requirements within documents
5. **task** - Tasks (if schema exists)
6. **test_case** - Test cases (via `test` entity type)
7. **risk** - Risk items (if schema exists)

## Operations Tested

### 1. CREATE Operation

#### Test Cases:
- **Minimal Data**: Create entity with only required fields
  - Input: `{"name": "...", "parent_id": "..."}`
  - Expected: Success with auto-generated fields (id, created_at, created_by, etc.)
  - Validates: Required field enforcement, default value application

- **Full Data**: Create entity with all available fields
  - Input: All optional fields provided
  - Expected: Success with all fields preserved
  - Validates: Schema compliance, field validation

- **Missing Required Fields**: Attempt to create without required fields
  - Input: `{"description": "..."}` (missing name)
  - Expected: Error with specific field names
  - Validates: Required field validation

- **Invalid Data Types**: Wrong data type for fields
  - Input: `{"name": 123}` (should be string)
  - Expected: Validation error
  - Edge Case: Type validation

- **Empty Data Object**: Create with `{}`
  - Input: `{"data": {}}`
  - Expected: Error listing missing required fields
  - Edge Case: Empty data handling

### 2. READ Operation

#### Test Cases:
- **By UUID**: Read using exact entity ID
  - Input: `{"entity_id": "550e8400-e29b-41d4-a716-446655440000"}`
  - Expected: Exact entity returned
  - Validates: Direct lookup performance

- **By Exact Name (Fuzzy Matching)**: Read using exact entity name
  - Input: `{"entity_id": "Test Organization Alpha"}`
  - Expected: Entity with matching name
  - Validates: Fuzzy matching - exact match priority

- **By Partial Name (Fuzzy Matching)**: Read using partial name
  - Input: `{"entity_id": "Alpha"}` (partial of "Test Organization Alpha")
  - Expected: Best matching entity if >70% similarity
  - Validates: Fuzzy matching algorithm, threshold handling

- **With Relations**: Include related entities
  - Input: `{"entity_id": "...", "include_relations": True}`
  - Expected: Entity with populated relationship fields
  - Validates: Relationship loading, performance

- **Nonexistent ID**: Read entity that doesn't exist
  - Input: `{"entity_id": "00000000-0000-0000-0000-000000000000"}`
  - Expected: Error with suggestions for similar entities
  - Edge Case: Not found handling, helpful suggestions

- **Ambiguous Name**: Name matches multiple entities
  - Input: `{"entity_id": "Test"}` (matches many)
  - Expected: Best match or suggestions list
  - Edge Case: Ambiguity resolution

### 3. UPDATE Operation

#### Test Cases:
- **Single Field Update**: Update one field
  - Input: `{"entity_id": "...", "data": {"description": "Updated"}}`
  - Expected: Only specified field changed, updated_at/updated_by set
  - Validates: Partial updates, metadata updates

- **Multiple Field Update**: Update several fields
  - Input: `{"entity_id": "...", "data": {"description": "...", "status": "active"}}`
  - Expected: All specified fields changed
  - Validates: Multi-field updates

- **Status Change**: Update status field
  - Input: `{"entity_id": "...", "data": {"status": "archived"}}`
  - Expected: Status changed, audit trail maintained
  - Validates: Status transitions

- **Update Nonexistent Entity**: Update entity that doesn't exist
  - Input: `{"entity_id": "00000000-...", "data": {...}}`
  - Expected: Error indicating entity not found
  - Edge Case: Update validation

- **Invalid Field Values**: Provide invalid values
  - Input: `{"entity_id": "...", "data": {"priority": "invalid"}}`
  - Expected: Validation error
  - Edge Case: Value validation

- **Empty Update Data**: Update with no data
  - Input: `{"entity_id": "...", "data": {}}`
  - Expected: No-op or error
  - Edge Case: Empty update handling

### 4. DELETE Operation

#### Test Cases:
- **Soft Delete**: Mark entity as deleted
  - Input: `{"entity_id": "...", "soft_delete": True}`
  - Expected: is_deleted=True, deleted_at set, entity hidden from lists
  - Validates: Soft delete mechanism

- **Verify Soft Delete**: Confirm soft-deleted entity not in list
  - Operation: List entities after soft delete
  - Expected: Deleted entity not returned
  - Validates: Soft delete filtering

- **Hard Delete**: Permanently remove entity
  - Input: `{"entity_id": "...", "soft_delete": False}`
  - Expected: Entity removed from database
  - Validates: Hard delete, cascading deletes (if configured)

- **Delete Already Deleted**: Delete soft-deleted entity again
  - Input: Soft delete same entity twice
  - Expected: Graceful handling (already deleted)
  - Edge Case: Duplicate delete

- **Delete Nonexistent**: Delete entity that doesn't exist
  - Input: `{"entity_id": "00000000-..."}`
  - Expected: Error or false success
  - Edge Case: Delete validation

### 5. LIST Operation

#### Test Cases:
- **List All (No Filters)**: Get all entities
  - Input: `{"limit": 20}`
  - Expected: Up to 20 active entities
  - Validates: Default filtering (is_deleted=False)

- **List by Parent**: Filter by parent entity
  - Input: `{"parent_type": "organization", "parent_id": "...", "limit": 20}`
  - Expected: Only entities belonging to parent
  - Validates: Parent-child relationships

- **List with Pagination**: Use limit and offset
  - Input: `{"limit": 10, "offset": 0}` then `{"limit": 10, "offset": 10}`
  - Expected: Different entities in each page
  - Validates: Pagination logic

- **Large Limit**: Request more than max allowed
  - Input: `{"limit": 500}`
  - Expected: Capped at 100 (max limit)
  - Edge Case: Limit enforcement

- **Offset Beyond Records**: Offset larger than total
  - Input: `{"limit": 10, "offset": 10000}`
  - Expected: Empty result set
  - Edge Case: Offset handling

- **Default Limit**: No limit specified
  - Input: `{}`
  - Expected: 20 entities (default)
  - Validates: Default parameter values

### 6. SEARCH Operation

#### Test Cases:
- **Search by Term**: Find entities matching text
  - Input: `{"search_term": "Alpha", "limit": 10}`
  - Expected: Entities with "Alpha" in name
  - Validates: Text search, case-insensitivity

- **Search with Filters**: Combine term and filters
  - Input: `{"search_term": "Test", "filters": {"status": "active"}, "limit": 10}`
  - Expected: Entities matching both term and filters
  - Validates: Filter combination

- **Search with Ordering**: Custom sort order
  - Input: `{"filters": {...}, "order_by": "created_at:desc", "limit": 10}`
  - Expected: Results sorted by created_at descending
  - Validates: Ordering logic

- **Search with Multiple Filters**: Complex filter combinations
  - Input: `{"filters": {"status": "active", "priority": "high", "type": "team"}}`
  - Expected: Entities matching all filters
  - Validates: AND filter logic

- **Empty Search Term**: Search with ""
  - Input: `{"search_term": "", "limit": 10}`
  - Expected: All entities (like list)
  - Edge Case: Empty string handling

- **No Matches**: Search that returns nothing
  - Input: `{"search_term": "NONEXISTENT_ENTITY_12345"}`
  - Expected: Empty result set
  - Edge Case: Zero results

- **Special Characters**: Search with special chars
  - Input: `{"search_term": "Test & Organization"}`
  - Expected: Proper escaping, matches found
  - Edge Case: Special character handling

## Entity-Specific Tests

### Organization Entity

**Required Fields**: `name`, `slug`
**Optional Fields**: `description`, `type`
**Relationships**: `members`, `projects`, `invitations`

**Test Scenarios**:
1. Create with auto-generated slug
2. Create with explicit slug
3. Read with relations (member_count, recent_projects)
4. Update type (personal → team)
5. List all organizations
6. Search by type filter

### Project Entity

**Required Fields**: `name`, `organization_id`
**Optional Fields**: `description`, `slug`
**Relationships**: `organization`, `members`, `documents`
**Parent**: `organization`

**Test Scenarios**:
1. Create with organization_id (requires parent)
2. Auto-generated slug from name
3. Read with relations (document_count, members)
4. Update description
5. List by parent organization
6. Delete (cascade to documents)

### Document Entity

**Required Fields**: `name`, `project_id`
**Optional Fields**: `description`, `slug`, `content`
**Relationships**: `project`, `requirements`, `blocks`
**Parent**: `project`

**Test Scenarios**:
1. Create with project_id
2. Read with relations (requirement_count, blocks)
3. Update content
4. List by parent project
5. Search documents by content
6. Delete (cascade to requirements)

### Requirement Entity

**Required Fields**: `name`, `document_id`
**Optional Fields**: `description`, `status`, `priority`, `type`, `properties`
**Relationships**: `document`, `tests`, `trace_links`
**Parent**: `document`

**Default Values**:
- `status`: "active"
- `priority`: "low"
- `type`: "component"
- `properties`: {}

**Test Scenarios**:
1. Create with minimal fields (defaults applied)
2. Create with full fields
3. Auto-generated external_id
4. Update status and priority
5. List by parent document
6. Search with status filter
7. Properties field handling (JSON)

## Parameter Inference Tests

**Automatic Operation Detection**:
- Only `data` provided → CREATE
- Only `entity_id` provided → READ
- Both `entity_id` and `data` → UPDATE
- `soft_delete=True` without explicit operation → DELETE
- `search_term` provided → SEARCH
- `parent_type`/`parent_id` provided → LIST

**Test Cases**:
1. Call without operation, only data → Infers CREATE
2. Call without operation, only entity_id → Infers READ
3. Call without operation, entity_id + data → Infers UPDATE
4. Call with ambiguous params → Error or explicit operation required

## Fuzzy Matching Tests

**Matching Strategies**:
1. **UUID format** → Direct lookup (fastest)
2. **Exact name match** → Single result
3. **Fuzzy match (>70% similarity)** → Best match
4. **Multiple matches** → Suggestions list
5. **No matches** → Error with suggestions

**Test Scenarios**:
- Exact match: "Test Organization" → exact entity
- Partial match: "Test Org" → fuzzy match to "Test Organization Alpha"
- Ambiguous: "Test" → suggestions list with scores
- Typo tolerance: "Tets Organization" → should match "Test Organization"
- Case insensitivity: "test organization" → "Test Organization"
- Score display: Show match scores in ambiguous results

## Edge Cases and Error Handling

### Input Validation
1. Empty data object
2. Missing required fields
3. Invalid data types
4. Invalid entity type
5. Invalid operation name
6. NULL values in required fields

### State Edge Cases
1. Read deleted entity
2. Update deleted entity
3. Delete already deleted entity
4. Create duplicate (unique constraints)
5. Circular references (if applicable)

### Pagination Edge Cases
1. Offset > total records
2. Limit = 0
3. Negative offset/limit
4. Limit > max allowed (should cap at 100)

### Search Edge Cases
1. Empty search term
2. Special characters in search
3. Very long search terms
4. No results found
5. All results match

### Performance Edge Cases
1. Large result sets (auto-pagination)
2. Deep relationship loading
3. Complex filter combinations
4. Concurrent operations

## Expected Outputs

### Success Response Format
```json
{
  "success": true,
  "data": { /* entity or array */ },
  "count": 1,
  "user_id": "...",
  "timestamp": "2025-11-08T00:00:00Z",
  "_performance": {
    "timings_ms": {
      "auth_validation": 45.2,
      "operation": 123.5,
      "total": 168.7
    },
    "total_time_ms": 168.7
  }
}
```

### Error Response Format
```json
{
  "success": false,
  "error": "Specific error message",
  "operation": "create",
  "entity_type": "organization",
  "suggestions": [ /* optional */ ],
  "hint": "Optional helpful hint"
}
```

### Fuzzy Match Response (Ambiguous)
```json
{
  "success": false,
  "error": "Multiple matches found - please be more specific",
  "suggestions": [
    {
      "name": "Test Organization Alpha",
      "id": "uuid-1",
      "score": 92.5,
      "created_at": "..."
    },
    {
      "name": "Test Organization Beta",
      "id": "uuid-2",
      "score": 88.3,
      "created_at": "..."
    }
  ],
  "hint": "Use the exact ID or name from suggestions"
}
```

## Test Execution Plan

### Phase 1: Basic CRUD (Organizations)
1. Create minimal organization
2. Create full organization
3. Read by UUID
4. Read by name (fuzzy)
5. Update organization
6. List organizations
7. Search organizations
8. Soft delete
9. Verify delete

### Phase 2: Hierarchical Entities (Projects)
1. Create parent organization
2. Create project with parent
3. Read project
4. Update project
5. List by parent
6. Delete cascade test

### Phase 3: Complex Entities (Documents, Requirements)
1. Create full hierarchy (org → project → document → requirement)
2. Test all operations at each level
3. Test relationships
4. Test cascading deletes

### Phase 4: Edge Cases and Error Handling
1. Invalid inputs
2. Missing data
3. Nonexistent entities
4. State violations
5. Limit/offset edge cases

### Phase 5: Performance and Fuzzy Matching
1. Fuzzy match accuracy
2. Suggestion quality
3. Performance timing
4. Large dataset handling

## Expected Test Results

### Success Metrics
- **Pass Rate**: >95% for valid operations
- **Performance**: <200ms for simple operations, <1s for complex queries
- **Fuzzy Matching Accuracy**: >90% for partial names (>70% similarity)
- **Error Handling**: 100% of invalid inputs return clear errors

### Known Limitations
1. Tables without `is_deleted` column: `test_req`, `properties`
2. Tables without `updated_by` column: `profiles`, `test_req`, `properties`
3. Fuzzy matching requires RapidFuzz library (falls back to basic if unavailable)
4. Embedding generation happens asynchronously (doesn't block response)

## Troubleshooting

### Authentication Failures
- Verify `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- Check test user credentials in environment
- Ensure Supabase service is online

### Database Errors
- Verify RLS policies allow user access
- Check JWT is properly set on database adapter
- Ensure user is member of organization/project

### Fuzzy Matching Issues
- Install RapidFuzz: `pip install rapidfuzz`
- Check similarity threshold (default 70%)
- Verify entity names are unique enough

### Performance Issues
- Check result set sizes (should auto-paginate at 10 items)
- Verify limit is capped at 100
- Review relationship loading (can be expensive)

## Running Specific Test Scenarios

To test specific entity types or operations, modify the test file:

```python
# Test only organizations
await tester.test_organization_full()

# Test only edge cases
await tester.test_edge_cases()

# Test specific operation
result = await tester.run_test(
    "organization", "create",
    "My custom test",
    {"data": {"name": "Test", "slug": "test"}}
)
```

## Report Output

The test suite generates two report formats:

1. **Markdown Report**: Human-readable with formatted results
   - Location: `tests/results/entity_tool_comprehensive_test_report_TIMESTAMP.md`
   - Includes: Summary, detailed results, errors, timing metrics

2. **JSON Report**: Machine-readable structured data
   - Location: `tests/results/entity_tool_comprehensive_test_report_TIMESTAMP.json`
   - Includes: All test data, programmatic analysis

## Continuous Integration

For CI/CD pipelines:

```bash
# Run tests and check exit code
python tests/test_entity_tool_complete.py
EXIT_CODE=$?

# Parse JSON report for failures
if [ $EXIT_CODE -ne 0 ]; then
  echo "Tests failed"
  exit 1
fi
```

## Future Enhancements

1. Add batch operation tests
2. Test concurrent operations
3. Add load testing scenarios
4. Test RLS policy enforcement
5. Add embedding generation verification
6. Test audit log creation
7. Add performance benchmarks
