"""Pytest configuration and shared fixtures."""

import os
import sys
import time
import pytest
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

# Load .env files
from dotenv import load_dotenv
load_dotenv()
load_dotenv(".env.local", override=True)


def pytest_configure(config):
    """Register custom markers."""
    # Core test categories
    config.addinivalue_line(
        "markers", "unit: marks tests that use in-memory client (fast, deterministic)"
    )
    config.addinivalue_line(
        "markers", "integration: marks tests that call MCP via HTTP"
    )
    
    # Feature categories
    config.addinivalue_line(
        "markers", "entity: tests related to entity operations"
    )
    config.addinivalue_line(
        "markers", "workflow: tests related to workflow execution"
    )
    config.addinivalue_line(
        "markers", "relationship: tests related to relationship operations"
    )
    
    # Execution modes
    config.addinivalue_line(
        "markers", "slow: tests that take > 1 second to run"
    )
    config.addinivalue_line(
        "markers", "mock_only: tests that use mocks instead of real services"
    )
    
    # Service requirements
    config.addinivalue_line(
        "markers", "requires_db: tests that need database connection"
    )
    config.addinivalue_line(
        "markers", "requires_auth: tests that need authentication"
    )
    
    # Specialized tests
    config.addinivalue_line(
        "markers", "performance: performance and load tests"
    )
    config.addinivalue_line(
        "markers", "security: security-focused tests"
    )
    config.addinivalue_line(
        "markers", "error_handling: error condition and edge case tests"
    )


@pytest.fixture(scope="session")
def check_server_running():
    """Check if MCP server is running on localhost:8000.
    
    Used by tests marked with @pytest.mark.requires_server.
    """
    import httpx

    try:
        response = httpx.get("http://127.0.0.1:8000/health", timeout=2.0)
        if response.status_code == 200:
            return True
    except Exception:
        pass

    pytest.skip("MCP server not running on http://127.0.0.1:8000")


@pytest.fixture(scope="function")
def timing_tracker():
    """Track execution time for test reporting.
    
    Returns: TimingTracker instance for measuring test execution times.
    """
    class TimingTracker:
        def __init__(self):
            self.start_time = 0.0
            self.timings = {}
            
        def start(self, name: str):
            """Start timing an operation."""
            self.start_time = time.perf_counter()
            self.current_name = name
            
        def stop(self) -> float:
            """Stop timing and return elapsed time in ms."""
            elapsed = time.perf_counter() - self.start_time
            if self.current_name in self.timings:
                self.timings[self.current_name].append(elapsed * 1000)
            else:
                self.timings[self.current_name] = [elapsed * 1000]
            return elapsed * 1000
            
        def report(self):
            """Return timing report."""
            return {
                name: {
                    "count": len(times),
                    "avg_ms": sum(times) / len(times),
                    "min_ms": min(times),
                    "max_ms": max(times)
                }
                for name, times in self.timings.items()
            }
    
    return TimingTracker()


@pytest.fixture(scope="session")
def shared_supabase_jwt():
    """Get Supabase JWT once and reuse to avoid rate limits."""
    from supabase import create_client

    url = os.getenv("NEXT_PUBLIC_SUPABASE_URL")
    key = os.getenv("NEXT_PUBLIC_SUPABASE_ANON_KEY")

    if not url or not key:
        pytest.skip("Supabase not configured")

    client = create_client(url, key)

    # Try to reuse existing session first
    try:
        auth_response = client.auth.sign_in_with_password({
            "email": "kooshapari@kooshapari.com",
            "password": "118118"
        })

        if auth_response.session:
            return auth_response.session.access_token
    except Exception as e:
        pytest.skip(f"Could not authenticate: {e}")

    pytest.skip("No session obtained")
