# B.5-B.9 Implementation Guide

## Status
- ✅ **B.1-B.4 COMPLETE**: Foundation, analysis, and fixture infrastructure ready
- ⏳ **B.5-B.9 READY FOR EXECUTION**: Awaiting Track A test consolidation + implementation

## Dependencies

### B.5: Convert httpx → FastMCP Client Pattern
**Depends on**: 
- ✅ B.4 (fixtures created)
- ⏳ Track A.4-A.6 (test files consolidated)

**Files to convert** (from HTTP_CONVERSION_PLAN.md):
- Priority 1 (Unit tool tests → in-memory):
  - `tests/unit/tools/test_entity.py` (use `mcp_client_inmemory` fixture)
  - `tests/unit/tools/test_workflow.py`
  - `tests/unit/tools/test_relationship.py`
  - `tests/unit/tools/test_query.py`
  - `tests/unit/tools/test_workspace.py`

- Priority 2 (Integration tests → HTTP):
  - `tests/integration/test_api.py` (use `mcp_client_http` fixture)
  - Other integration files

- Priority 3 (E2E and performance):
  - `tests/e2e/test_e2e.py` (use `full_deployment` fixture)
  - `tests/performance/test_benchmarks.py` (use `timing_tracker` fixture)

**Conversion template**: See HTTP_CONVERSION_PLAN.md "Conversion Template" section

### B.6: Apply Parametrization Patterns
**Depends on**: 
- ✅ B.5 (client conversions done)
- B.4 (fixtures with parametrization helpers created)

**Parametrization strategy** (from PARAMETRIZATION_ANALYSIS.md):
- Entity tool: Consolidate 80 tests → ~30 parametrized (63% reduction)
- Workflow tool: Consolidate 45 tests → ~20 parametrized (56% reduction)  
- Relationship tool: Consolidate 40 tests → ~15 parametrized (63% reduction)
- Query tool: Consolidate 15 tests → ~6 parametrized (60% reduction)
- Workspace tool: Consolidate 20 tests → ~8 parametrized (70% reduction)
- **Total**: 200 tests → ~79 parametrized (~60% reduction)

**Implementation pattern**:
```python
# Before: Multiple test functions
async def test_create_organization(...): pass
async def test_create_project(...): pass
async def test_create_document(...): pass

# After: One parametrized test
@pytest.mark.parametrize("entity_type,data", [
    ("organization", {...}),
    ("project", {...}),
    ("document", {...}),
])
async def test_entity_create_variants(mcp_client_inmemory, entity_type, data):
    result = await mcp_client_inmemory.call_tool(
        "entity_tool",
        {"operation": "create", "entity_type": entity_type, "data": data}
    )
    assert result.success
```

### B.7: Add Test Docstrings and Markers
**Depends on**: 
- ✅ B.6 (parametrization done)

**Tasks**:
1. Add docstrings to ALL test functions:
   - Indicate what behavior is being tested
   - Add example assertions
   - Document parametrization if used

2. Verify/apply markers:
   - `@pytest.mark.unit` on all unit/tools/ tests
   - `@pytest.mark.unit` on all unit/infrastructure/ tests
   - `@pytest.mark.security` on all unit/security/ tests
   - `@pytest.mark.integration` on all integration/ tests
   - `@pytest.mark.e2e` on all e2e/ tests
   - `@pytest.mark.performance` on all performance/ tests
   - `@pytest.mark.mock_only` where no live services used
   - `@pytest.mark.requires_db` where Supabase needed
   - `@pytest.mark.slow` for tests >5 seconds

### B.8: Create tests/README.md Documentation
**Depends on**: 
- ✅ B.7 (tests fully documented)

**Content should cover**:
1. Test directory structure explanation
2. What each directory tests
3. How to run different test categories:
   ```bash
   pytest -m unit                    # Fast unit tests only
   pytest -m integration             # Integration tests
   pytest -m "unit and not slow"     # Unit tests excluding slow tests
   pytest tests/unit/tools/          # All tool tests
   pytest tests/unit/tools/test_entity.py::test_entity_create  # Specific test
   ```

4. Marker usage examples
5. FastMCP Client fixture patterns with examples
6. Adding new tests guide
7. Parametrization examples
8. Common fixture usage patterns
9. Mocking patterns (database_mock, auth_mock, etc.)

**Template structure**:
- Overview & quick start
- Test organization diagram  
- Directory breakdown
- Running tests (with examples)
- Writing new tests (guide)
- Fixtures reference
- Markers reference
- Parametrization patterns
- Performance baseline expectations
- Troubleshooting

### B.9: Measure and Document Performance Baseline
**Depends on**: 
- ✅ B.7-B.8 (tests documented and runnable)

**Execution plan**:
```bash
# Run unit tests and measure time
pytest -m unit --tb=short -v
# Expected: <60 seconds total

# Run integration tests and measure
pytest -m integration --tb=short -v

# Run security tests
pytest -m security --tb=short -v

# Run performance tests with baseline comparison
pytest tests/performance/ -v

# Generate full report
pytest tests/ --cov=. --cov-report=html --tb=short
```

**Output**:
1. `tests/PERFORMANCE_BASELINE.json`:
   ```json
   {
     "unit_tests": {"time_ms": 45000, "count": 850},
     "integration_tests": {"time_ms": 120000, "count": 150},
     "security_tests": {"time_ms": 30000, "count": 50},
     "e2e_tests": {"time_ms": 200000, "count": 30},
     "performance_tests": {"time_ms": 180000, "count": 20}
   }
   ```

2. Document in `tests/README.md`

## Implementation Order

1. **First** (parallel with Track A): Verify all conftest files in place
2. **Then B.5**: Run conversion (entity, workflow, etc.) one tool at a time
3. **Then B.6**: Apply parametrization after conversion
4. **Then B.7**: Add docstrings and markers
5. **Then B.8**: Write comprehensive README
6. **Finally B.9**: Measure and document baselines

## Validation Checklist Before Proceeding

- [ ] All conftest.py files created (7 files):
  - [ ] tests/unit/tools/conftest.py
  - [ ] tests/unit/infrastructure/conftest.py
  - [ ] tests/unit/security/conftest.py
  - [ ] tests/integration/conftest.py
  - [ ] tests/e2e/conftest.py
  - [ ] tests/performance/conftest.py
  - [ ] tests/error_handling/conftest.py (if needed)

- [ ] All consolidated test files in place:
  - [ ] tests/unit/tools/test_*.py (5 files)
  - [ ] tests/integration/test_*.py
  - [ ] tests/e2e/test_*.py
  - [ ] tests/performance/test_*.py
  - [ ] tests/error_handling/test_*.py

- [ ] Pytest collection works without errors:
  ```bash
  pytest tests/ --collect-only
  # Should show ~1097 tests, 0 errors
  ```

- [ ] Basic test runs (at least one from each category):
  ```bash
  pytest tests/unit/tools/test_entity.py::test_... -v
  # Should pass
  ```

## Quick Reference: Fixture Usage

### Unit Tests (In-Memory)
```python
@pytest.mark.unit
@pytest.mark.parametrize("entity_type", ["organization", "project"])
async def test_create(mcp_client_inmemory, entity_type):
    result = await mcp_client_inmemory.call_tool("entity_tool", {
        "operation": "create",
        "entity_type": entity_type,
        "data": {"name": "Test"}
    })
    assert result.success
```

### Integration Tests (HTTP)
```python
@pytest.mark.integration
async def test_http_api(mcp_client_http):
    result = await mcp_client_http.call_tool("entity_tool", {...})
    assert result.success
```

### Infrastructure Tests (Mocks)
```python
@pytest.mark.unit
def test_database_transaction(database_mock, rls_context_mock):
    database_mock.execute.return_value = {"success": True}
    assert database_mock.execute.called
```

### Security Tests (Payloads)
```python
@pytest.mark.security
@pytest.mark.parametrize("payload", injection_payloads()["sql_injection"])
async def test_injection_prevention(mcp_client_inmemory, payload):
    result = await mcp_client_inmemory.call_tool("query_tool", {
        "operation": "search",
        "query": payload
    })
    assert not result.success  # Should reject injection
```

### Performance Tests (Timing)
```python
@pytest.mark.performance
async def test_throughput(timing_tracker, load_generator):
    async def request():
        return await client.call_tool(...)
    
    with timing_tracker.measure("throughput"):
        results = await load_generator(100, request)
    
    stats = timing_tracker.get_stats("throughput")
    assert stats["avg"] < 50  # 50ms average
```

## Progress Tracking

Use this to track completion:

```bash
# After B.5: Check conversions
grep -r "mcp_client_inmemory\|mcp_client_http" tests/unit/tools tests/integration | wc -l
# Expected: 100+ matches

# After B.6: Check parametrization
grep -r "@pytest.mark.parametrize" tests/ | wc -l
# Expected: 30+ parametrized tests

# After B.7: Check markers and docstrings
grep -r "@pytest.mark.unit\|@pytest.mark.integration" tests/ | wc -l
# Expected: 1000+

# After B.8: Check README exists
[ -f tests/README.md ] && echo "README found" || echo "README missing"

# After B.9: Check baseline
[ -f tests/PERFORMANCE_BASELINE.json ] && echo "Baseline found" || echo "Baseline missing"
```

## Notes

- All work items B.5-B.9 are **independent** except for ordering dependencies
- B.5 and B.6 can be parallelized if needed (different tools)
- B.7, B.8, B.9 are sequential (each depends on previous)
- Track A (structural) and Track B (quality) remain parallel where possible

## Related Documents

- `FIXTURE_TEMPLATES.md` - Reference for all fixture patterns
- `HTTP_CONVERSION_PLAN.md` - Detailed conversion strategy
- `PARAMETRIZATION_ANALYSIS.md` - Consolidation strategy and estimates
