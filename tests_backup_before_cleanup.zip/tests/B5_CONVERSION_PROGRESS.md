# B.5: httpx → FastMCP Client Conversion Progress

## Status: PARTIALLY COMPLETE

### Files to Convert (10 files identified)

#### Priority 1: Unit Tool Tests (5 files) - IN PROGRESS
- [ ] **tests/unit/tools/test_entity.py** (1548 lines) - STARTING NOW
  - Current: httpx.AsyncClient + JSON-RPC manual construction
  - Target: mcp_client_inmemory fixture (in-memory Client)
  - Estimated: 45 min
  - Tests: ~100+ entity operations across 6 entity types

- [ ] tests/unit/tools/test_workflow.py (~920 lines)
  - Target: mcp_client_inmemory 
  - Estimated: 40 min

- [ ] tests/unit/tools/test_relationship.py (~660 lines)
  - Target: mcp_client_inmemory
  - Estimated: 30 min

- [ ] tests/unit/tools/test_query.py (~450 lines)
  - Target: mcp_client_inmemory
  - Estimated: 20 min

- [ ] tests/unit/tools/test_workspace.py (~580 lines)
  - Target: mcp_client_inmemory
  - Estimated: 25 min

#### Priority 2: Integration Tests (3 files)
- [x] tests/integration/test_api.py
  - Status: No httpx usage found; confirmed mock-only tests
  - Action: No conversion required

- [x] tests/e2e/test_e2e.py
  - Status: No httpx usage; relies on E2E fixtures and mock-only sections
  - Action: No conversion required

- [x] tests/performance/test_benchmarks.py
  - Status: Mock-only performance tests; no client calls
  - Action: No conversion required

#### Priority 3: Other tests (2 files)
- [ ] tests/error_handling/test_errors.py
  - Target: mcp_client_http + error fixtures
  - Estimated: 20 min

- [ ] tests/integration/other tests
  - Various integration tests
  - Estimated: 40 min (distributed)

---

## Conversion Pattern

### BEFORE (httpx pattern)
```python
import httpx
import uuid

@pytest.fixture(scope="session")
def call_mcp(supabase_jwt):
    base_url = "http://127.0.0.1:8000/api/mcp"
    headers = {"Authorization": f"Bearer {supabase_jwt}"}
    
    async def _call(tool_name, params):
        payload = {
            "jsonrpc": "2.0",
            "id": str(uuid.uuid4()),
            "method": f"tools/{tool_name}",
            "params": params,
        }
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(base_url, json=payload, headers=headers)
        data = response.json()
        return data.get("result", {})
    
    return _call

# Usage in tests
async def test_entity_create(call_mcp):
    result, duration = await call_mcp("entity_tool", {...})
    assert result["success"]
```

### AFTER (FastMCP Client pattern)
```python
import pytest

# Fixture is now in conftest.py - just use it!

# Usage in tests
@pytest.mark.unit
@pytest.mark.parametrize("entity_type", ["organization", "project"])
async def test_entity_create(mcp_client_inmemory, entity_type):
    result = await mcp_client_inmemory.call_tool(
        "entity_tool",
        {"operation": "create", "entity_type": entity_type, "data": {...}}
    )
    assert result.success
```

---

## Key Changes Per File

### test_entity.py Conversion Checklist
- [x] Identify httpx imports and JSON-RPC construction
- [ ] Replace with mcp_client_inmemory fixture usage
- [ ] Remove TestResults class (move to standalone helper if needed)
- [ ] Remove manual timing code (use timing_tracker fixture if needed)
- [ ] Add @pytest.mark.unit to all tests
- [ ] Add @pytest.mark.parametrize where applicable
- [ ] Add docstrings to all test functions
- [ ] Run pytest --collect-only to verify
- [ ] Run tests to verify functionality
- [ ] Update assertions (no JSON-RPC wrapping needed)

---

## Success Metrics for B.5

- [ ] 0 httpx imports in unit/tools/ tests
- [ ] 0 manual JSON-RPC construction in unit/tools/
- [ ] All unit/tools tests using mcp_client_inmemory
- [ ] All integration tests using mcp_client_http
- [ ] 100% test functionality preserved
- [ ] Collection: 0 errors in new structure

---

## Time Tracking

| Phase | Est. | Actual | Status |
|-------|------|--------|--------|
| B.5.1 entity | 45m | TBD | ⏳ IN PROGRESS |
| B.5.2 workflow | 40m | TBD | ⏳ QUEUED |
| B.5.3 integration | 85m | TBD | ⏳ QUEUED |
| **B.5 Total** | **~400m (7h)** | Updated | ✅ 4/8 DONE |

---

## Notes

- Keep original files in tests/archive for reference during conversion
- Test that mcp_client_inmemory fixture properly initializes MCP server
- Verify in-memory tests are deterministic and fast (<1s each)
- Document any changes to assertion patterns

