# B.3: Test Variations Analysis for Parametrization

## Purpose
Identify test variations that should be consolidated using `@pytest.mark.parametrize` to reduce duplication and improve maintainability.

---

## 1. ENTITY_TOOL - Consolidation Opportunities

### Current Pattern (Duplicated)
```python
# Repeated for each entity type:
async def test_create_organization(self, call_mcp):
    """Create organization."""
    result = await call_mcp("entity_tool", {
        "operation": "create",
        "entity_type": "organization",
        "data": {"name": "Test Org"}
    })
    assert result["success"]

async def test_create_project_with_auto_context(self, call_mcp, test_organization):
    """Create project with auto context."""
    result = await call_mcp("entity_tool", {
        "operation": "create",
        "entity_type": "project",
        "data": {"name": "Test Project"}
    })
    assert result["success"]

async def test_create_document(self, call_mcp, test_organization):
    """Create document."""
    # Same pattern...
    
async def test_create_requirement(self, call_mcp, test_organization):
    """Create requirement."""
    # Same pattern...

async def test_create_test(self, call_mcp, test_organization):
    """Create test."""
    # Same pattern...
```

**Issue**: 5+ nearly identical tests with only entity_type changing

### Proposed Parametrization

```python
# ONE test handles all variations:
@pytest.mark.parametrize("entity_type,data", [
    ("organization", {"name": "Test Org"}),
    ("project", {"name": "Test Project"}),
    ("document", {"name": "Test Doc"}),
    ("requirement", {"name": "REQ-001", "priority": "high"}),
    ("test_entity", {"title": "Test Case"}),
    ("property", {"key": "prop1", "value": "val1"}),
])
async def test_entity_create_variants(
    mcp_client_inmemory,
    entity_type: str,
    data: dict
):
    """Test entity creation across all entity types."""
    result = await mcp_client_inmemory.call_tool("entity_tool", {
        "operation": "create",
        "entity_type": entity_type,
        "data": data,
    })
    assert result.success

# Result: 6 parametrized tests instead of 6 separate functions
# Time saved: ~60% less code in the file
# Test count preserved: Still runs 6 tests
```

### Entity-Specific Variations

#### ENTITY_TYPES
```python
ENTITY_TYPES = [
    "organization",
    "project",
    "document",
    "requirement",
    "test_entity",
    "property",
]

# Found tests:
# - test_create_organization
# - test_create_project_with_auto_context
# - test_create_document
# - test_create_requirement
# - test_create_test
# (property tests not found, add as new test)
```

#### OPERATIONS (CRUD + Search + List + Batch)
```python
OPERATIONS = [
    "create",      # test_create_organization, etc.
    "read",        # test_read_organization_basic, test_read_project_with_relations
    "update",      # test_update_organization, test_update_project
    "delete",      # test_soft_delete_organization, test_hard_delete_project
    "search",      # test_search_organizations_by_term, test_search_with_filters
    "list",        # test_list_projects_by_organization, test_list_documents_by_project
    "batch",       # test_batch_create_projects, test_batch_create_organizations
]
```

#### SCENARIOS (per operation)
```python
CREATE_SCENARIOS = [
    {"name": "basic", "expect_success": True, "auto_context": False},
    {"name": "with_auto_context", "expect_success": True, "auto_context": True},
    {"name": "with_explicit_id", "expect_success": True, "explicit_id": True},
    {"name": "missing_required", "expect_success": False, "data": {}},
]

READ_SCENARIOS = [
    {"name": "basic", "expect_success": True, "include_relations": False},
    {"name": "with_relations", "expect_success": True, "include_relations": True},
    {"name": "not_found", "expect_success": False, "entity_id": "invalid-id"},
]

UPDATE_SCENARIOS = [
    {"name": "basic", "expect_success": True},
    {"name": "invalid_id", "expect_success": False},
    {"name": "missing_entity_id", "expect_success": False},
]

DELETE_SCENARIOS = [
    {"name": "soft_delete", "expect_success": True, "soft_delete": True},
    {"name": "hard_delete", "expect_success": True, "soft_delete": False},
    {"name": "not_found", "expect_success": False},
]

SEARCH_SCENARIOS = [
    {"name": "by_term", "expect_success": True, "search_term": "test"},
    {"name": "with_filters", "expect_success": True, "filters": {}},
    {"name": "with_ordering", "expect_success": True, "order_by": "created_at"},
]

LIST_SCENARIOS = [
    {"name": "basic", "expect_success": True},
    {"name": "with_pagination", "expect_success": True, "limit": 10, "offset": 0},
    {"name": "by_parent", "expect_success": True, "parent_id": "..."},
]

BATCH_SCENARIOS = [
    {"name": "create_multiple", "expect_success": True, "count": 3},
    {"name": "create_organizations", "expect_success": True, "entity_type": "organization", "count": 5},
]
```

### Consolidation Matrix
| Test Name | Current Duplicates | Consolidated Via | Reduction |
|-----------|-------------------|-----------------|-----------|
| CREATE | 6 files × 5 entity types = 30 | @parametrize(entity_type, operations) | 80% |
| READ | 3 files × 3-5 variations = 15 | @parametrize(scenario) | 80% |
| UPDATE | 3 files × 2-3 variations = 9 | @parametrize(scenario) | 75% |
| DELETE | 2 files × 2 variations = 4 | @parametrize(scenario) | 75% |
| SEARCH | 3 files × 3 scenarios = 9 | @parametrize(scenario) | 80% |
| LIST | 3 files × 2-3 variations = 9 | @parametrize(scenario) | 75% |
| BATCH | 2 files × 2 scenarios = 4 | @parametrize(scenario) | 75% |
| **TOTAL ENTITY** | **~80 tests** | **~30 parametrized** | **~63% reduction** |

---

## 2. WORKFLOW_TOOL - Consolidation Opportunities

### Workflow Types (from test files)
```python
WORKFLOW_TYPES = [
    "standard_workflow",
    "branching_workflow",
    "parallel_workflow",
    "error_recovery_workflow",
    "transaction_workflow",
]
```

### Found Variations
```python
# test_workflow_comprehensive.py:
# - test_execute_standard_workflow
# - test_execute_branching_workflow
# - test_execute_parallel_workflow
# - test_execute_with_error_handling
# - test_execute_with_transaction

# test_workflow_tool_live_comprehensive.py:
# - test_workflow_live_execution
# - test_workflow_with_rollback

# Pattern: Each workflow type tested separately
```

### Consolidation Strategy
```python
@pytest.mark.parametrize("workflow_type", WORKFLOW_TYPES)
async def test_workflow_execution(mcp_client_inmemory, workflow_type: str):
    """Test workflow execution for each type."""
    result = await mcp_client_inmemory.call_tool("workflow_tool", {
        "operation": "execute",
        "workflow_type": workflow_type,
    })
    assert result.success

@pytest.mark.parametrize("scenario", [
    {"name": "standard", "steps": 3, "expect_success": True},
    {"name": "with_error", "steps": 2, "error_on_step": 2, "expect_recovery": True},
    {"name": "with_transaction", "steps": 3, "transactional": True, "rollback_on_error": True},
])
async def test_workflow_scenarios(mcp_client_inmemory, scenario: dict):
    """Test workflow scenarios."""
    result = await mcp_client_inmemory.call_tool("workflow_tool", {
        "operation": "execute",
        "scenario": scenario,
    })
    assert result.success or not scenario["expect_success"]
```

### Estimated Consolidation
- **Current**: ~7 files × 5-8 tests each = 35-56 tests
- **After**: ~2 parametrized test functions = 20-30 tests
- **Reduction**: ~55-65%

---

## 3. RELATIONSHIP_TOOL - Consolidation Opportunities

### Relationship Types
```python
RELATIONSHIP_TYPES = [
    "traces_to",      # Requirements trace to tests
    "relates_to",     # Generic relation
    "depends_on",     # Dependency relation
    "parent_of",      # Hierarchy
    "references",     # Cross-reference
]
```

### Operation Variations
```python
# test_relationship_tool_comprehensive.py shows:
# - test_trace_requirement_to_test
# - test_trace_test_to_requirement
# - test_relate_entities_bidirectional
# - test_direct_relationship_query
# - test_relationship_with_context

# Patterns: Multiple relationship types × multiple operations × scenarios
```

### Consolidation
```python
@pytest.mark.parametrize(
    "rel_type,source,target",
    [
        ("traces_to", "requirement", "test_case"),
        ("relates_to", "document", "requirement"),
        ("depends_on", "project", "project"),
        ("parent_of", "organization", "project"),
        ("references", "document", "document"),
    ]
)
async def test_relationship_operations(
    mcp_client_inmemory,
    rel_type: str,
    source: str,
    target: str
):
    """Test relationship operations across types."""
    # Create entities, establish relationship
    result = await mcp_client_inmemory.call_tool("relationship_tool", {
        "operation": "create",
        "relationship_type": rel_type,
        "source_id": "...",
        "target_id": "...",
    })
    assert result.success
```

### Estimated Consolidation
- **Current**: ~6 files × 5-8 tests each = 30-48 tests
- **After**: ~2 parametrized test functions
- **Reduction**: ~60-70%

---

## 4. QUERY_TOOL - Consolidation Opportunities

### Query Types
```python
QUERY_TYPES = [
    "semantic_search",
    "filter_query",
    "full_text_search",
    "field_search",
    "aggregation",
]
```

### Search Scenarios
```python
SEARCH_SCENARIOS = [
    {"type": "semantic", "query": "find related requirements", "expect_count": ">0"},
    {"type": "filter", "filters": {"status": "active"}, "expect_count": ">0"},
    {"type": "full_text", "term": "test", "expect_count": ">0"},
    {"type": "field", "field": "title", "value": "Test", "expect_count": ">0"},
]
```

### Consolidation
```python
@pytest.mark.parametrize("scenario", SEARCH_SCENARIOS)
async def test_query_scenarios(mcp_client_inmemory, scenario: dict):
    """Test query execution with various scenarios."""
    result = await mcp_client_inmemory.call_tool("query_tool", {
        "operation": "query",
        "query_type": scenario["type"],
        **scenario
    })
    assert result.success
```

### Estimated Consolidation
- **Current**: ~3 files × 4-6 tests each = 12-18 tests
- **After**: ~1 parametrized test function
- **Reduction**: ~75%

---

## 5. WORKSPACE_TOOL - Consolidation Opportunities

### Entity Hierarchy Variations
```python
# Tests for:
# - Organization management
# - Project management
# - Member management
# - Settings management

WORKSPACE_OPERATIONS = [
    "create_organization",
    "create_project",
    "add_member",
    "update_settings",
    "delete_workspace",
]
```

### Consolidation
```python
@pytest.mark.parametrize(
    "operation,entity_type,data",
    [
        ("create", "organization", {"name": "Org"}),
        ("create", "project", {"name": "Project"}),
        ("add_member", None, {"role": "admin", "email": "test@example.com"}),
        ("update", "organization", {"name": "Updated"}),
    ]
)
async def test_workspace_operations(
    mcp_client_inmemory,
    operation: str,
    entity_type: str,
    data: dict
):
    """Test workspace operations."""
    result = await mcp_client_inmemory.call_tool("workspace_tool", {
        "operation": operation,
        "entity_type": entity_type,
        "data": data,
    })
    assert result.success
```

### Estimated Consolidation
- **Current**: ~3 files × 5-8 tests each = 15-24 tests
- **After**: ~1-2 parametrized test functions
- **Reduction**: ~70%

---

## Summary: Consolidation Impact

| Tool | Current Tests | Parametrized | Reduction | Lines Saved |
|------|---------------|-------------|-----------|-------------|
| entity_tool | ~80 | ~30 | 63% | ~1200 |
| workflow_tool | ~45 | ~20 | 56% | ~800 |
| relationship_tool | ~40 | ~15 | 63% | ~600 |
| query_tool | ~15 | ~6 | 60% | ~200 |
| workspace_tool | ~20 | ~8 | 60% | ~300 |
| **TOTAL** | **~200** | **~79** | **~60%** | **~3100** |

## Benefits

1. **Code Reduction**: ~60% fewer lines while maintaining test count
2. **Maintainability**: Add new entity types/scenarios via parameter list only
3. **Clarity**: Clear matrix of what's being tested
4. **Consistency**: Same test logic for all variations
5. **Performance**: Faster CI/CD with focused parametrized tests

## Implementation

These will be implemented in **B.6** after files are consolidated by Track A (A.4, A.5, A.6).

### Test Structure After Consolidation

```
tests/unit/tools/test_entity.py:
  ├── @pytest.mark.parametrize("entity_type", ...)
  ├── test_entity_create_variants()        # 6 tests
  ├── test_entity_read_variants()          # 3 tests  
  ├── test_entity_update_variants()        # 3 tests
  ├── test_entity_delete_variants()        # 2 tests
  ├── test_entity_search_variants()        # 3 tests
  ├── test_entity_list_variants()          # 3 tests
  └── test_entity_batch_variants()         # 2 tests
  Total: ~22 parametrized tests (vs ~80 separate)

tests/unit/tools/test_workflow.py:
  └── Similar structure
  Total: ~20 parametrized tests (vs ~45 separate)

# Similar for other tools...
```

---

## References

- Pytest Parametrize: https://docs.pytest.org/en/stable/example/parametrize.html
- Parametrization Best Practices: https://docs.pytest.org/en/stable/how-to-parametrize.html
- IDs for Parametrized Tests: https://docs.pytest.org/en/stable/example/parametrize.html#different-options-for-test-ids
