"""Fixtures for end-to-end tests.

Provides:
- full_deployment: Complete MCP server + HTTP + DB setup
- end_to_end_client: Pre-configured client
- workflow_scenarios: Predefined E2E scenarios
"""

import pytest
from typing import AsyncGenerator, Tuple, Any


@pytest.fixture
async def full_deployment() -> AsyncGenerator[Tuple[Any, Any], None]:
    """Full MCP deployment for E2E testing.
    
    Sets up: Server + HTTP transport + Live Supabase
    
    Usage:
        @pytest.mark.e2e
        async def test_complete_workflow(full_deployment):
            server, http_client, db_client = full_deployment
            result = await http_client.call_tool(...)
            assert result.success
    """
    try:
        from fastmcp import FastMCP, Client
        from fastmcp.client.transports import StreamableHttpTransport
        import os
        
        # Create server
        server = FastMCP("atoms-e2e-server")
        
        # Create HTTP client
        base_url = os.getenv("ATOMS_FASTMCP_BASE_URL", "http://127.0.0.1:8000")
        mcp_path = os.getenv("ATOMS_FASTMCP_HTTP_PATH", "/api/mcp")
        transport = StreamableHttpTransport(f"{base_url}{mcp_path}")
        
        async with Client(transport=transport) as http_client:
            # Create DB client
            from supabase import create_client
            
            db_url = os.getenv("NEXT_PUBLIC_SUPABASE_URL")
            db_key = os.getenv("NEXT_PUBLIC_SUPABASE_ANON_KEY")
            
            if db_url and db_key:
                db_client = create_client(db_url, db_key)
            else:
                db_client = None
            
            yield (server, http_client, db_client)
    
    except ImportError as e:
        pytest.skip(f"Could not import required modules: {e}")


@pytest.fixture
async def end_to_end_client(full_deployment):
    """Client configured for E2E scenarios.
    
    Pre-configured with auth, database, all services.
    """
    server, http_client, db_client = full_deployment
    return http_client


@pytest.fixture
def workflow_scenarios():
    """Pre-defined E2E workflow scenarios."""
    return [
        {
            "name": "create_org_and_project",
            "steps": [
                {"tool": "workspace_tool", "operation": "create_organization", "data": {"name": "E2E Org"}},
                {"tool": "workspace_tool", "operation": "create_project", "data": {"name": "E2E Project"}},
            ],
        },
        {
            "name": "entity_lifecycle",
            "steps": [
                {"tool": "entity_tool", "operation": "create", "entity_type": "organization", "data": {"name": "Test"}},
                {"tool": "entity_tool", "operation": "read", "entity_type": "organization"},
                {"tool": "entity_tool", "operation": "update", "entity_type": "organization", "data": {"name": "Updated"}},
                {"tool": "entity_tool", "operation": "delete", "entity_type": "organization"},
            ],
        },
        {
            "name": "workflow_execution",
            "steps": [
                {"tool": "workflow_tool", "operation": "execute", "workflow_type": "standard"},
                {"tool": "workflow_tool", "operation": "get_status"},
            ],
        },
        {
            "name": "search_and_query",
            "steps": [
                {"tool": "data_query", "operation": "search", "query": "test"},
                {"tool": "data_query", "operation": "query", "filters": {}},
            ],
        },
    ]


@pytest.fixture
def deployment_targets():
    """Different deployment targets to test."""
    return [
        {"name": "localhost", "url": "http://127.0.0.1:8000", "requires_auth": False},
        {"name": "production", "url": os.getenv("PRODUCTION_MCP_URL"), "requires_auth": True},
    ]
