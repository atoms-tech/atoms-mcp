"""End-to-end tests for Atoms MCP."""
