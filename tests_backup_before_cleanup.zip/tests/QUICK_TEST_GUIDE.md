# Quick Test Guide: Entity Tool Comprehensive Testing

## Prerequisites

### 1. Environment Setup
```bash
# Ensure environment variables are set
export NEXT_PUBLIC_SUPABASE_URL="your-supabase-url"
export NEXT_PUBLIC_SUPABASE_ANON_KEY="your-anon-key"
export ATOMS_TEST_EMAIL="your-test-email"
export ATOMS_TEST_PASSWORD="your-test-password"
```

### 2. Install Dependencies
```bash
pip install supabase-py rapidfuzz
```

### 3. Verify Supabase is Online
```bash
curl -I https://your-supabase-url.supabase.co/rest/v1/
# Should return 200 OK
```

## Running the Tests

### Full Comprehensive Test Suite
```bash
cd /Users/kooshapari/temp-PRODVERCEL/485/kush/atoms-mcp-prod
python tests/test_entity_tool_complete.py
```

**Expected Duration**: 3-5 minutes
**Total Tests**: ~60-80 test cases
**Coverage**: All entity types, all operations, edge cases

## Resources

- **Test Plan**: tests/ENTITY_TOOL_TEST_PLAN.md
- **Analysis**: tests/ENTITY_TOOL_ANALYSIS.md
- **Test Code**: tests/test_entity_tool_complete.py
