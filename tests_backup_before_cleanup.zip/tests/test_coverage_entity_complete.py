"""
Comprehensive tests for tools/entity.py to achieve 100% coverage.
"""

import pytest
import asyncio
from unittest.mock import AsyncMock, MagicMock, patch, Mock
from typing import Dict, Any, Optional
from datetime import datetime
import uuid

# ============================================================================
# TOOLS/ENTITY.PY - 100% Coverage
# ============================================================================

class TestEntityManagerComplete:
    """Complete coverage tests for tools/entity.py."""

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_is_uuid_format_valid(self):
        """Test _is_uuid_format with valid UUID."""
        from tools.entity import EntityManager
        
        manager = EntityManager()
        
        valid_uuid = "123e4567-e89b-12d3-a456-426614174000"
        assert manager._is_uuid_format(valid_uuid) is True
        
        # Test case insensitive
        assert manager._is_uuid_format(valid_uuid.upper()) is True

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_is_uuid_format_invalid(self):
        """Test _is_uuid_format with invalid UUID."""
        from tools.entity import EntityManager
        
        manager = EntityManager()
        
        invalid_cases = [
            "not-a-uuid",
            "123",
            "123e4567-e89b-12d3-a456",
            "123e4567e89b12d3a456426614174000",
        ]
        
        for invalid in invalid_cases:
            assert manager._is_uuid_format(invalid) is False

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_get_entity_schema_with_pydantic(self):
        """Test _get_entity_schema with Pydantic available."""
        from tools.entity import EntityManager
        
        manager = EntityManager()
        
        with patch('tools.entity._HAS_SCHEMAS', True):
            with patch('tools.entity.get_model_fields', return_value={"name": "str"}):
                with patch('tools.entity.get_required_fields', return_value=["name"]):
                    schema = manager._get_entity_schema("organization")
                    
                    assert "required_fields" in schema
                    assert "pydantic_available" in schema
                    assert schema["pydantic_available"] is True

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_get_entity_schema_pydantic_exception(self):
        """Test _get_entity_schema with Pydantic exception."""
        from tools.entity import EntityManager
        
        manager = EntityManager()
        
        with patch('tools.entity._HAS_SCHEMAS', True):
            with patch('tools.entity.get_model_fields', side_effect=Exception("Error")):
                # Should fall back to manual schemas
                schema = manager._get_entity_schema("organization")
                
                assert "required_fields" in schema
                assert schema["required_fields"] == ["name", "slug"]

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_get_entity_schema_manual(self):
        """Test _get_entity_schema with manual schemas."""
        from tools.entity import EntityManager
        
        manager = EntityManager()
        
        with patch('tools.entity._HAS_SCHEMAS', False):
            # Test all entity types
            test_cases = [
                ("organization", ["name", "slug"]),
                ("project", ["name", "organization_id"]),
                ("document", ["name", "project_id"]),
                ("requirement", ["name", "document_id"]),
                ("test", ["title", "project_id"]),
                ("user", ["id"]),
                ("profile", ["id"]),
            ]
            
            for entity_type, expected_required in test_cases:
                schema = manager._get_entity_schema(entity_type)
                assert "required_fields" in schema
                assert schema["required_fields"] == expected_required

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_get_entity_schema_unknown(self):
        """Test _get_entity_schema with unknown entity type."""
        from tools.entity import EntityManager
        
        manager = EntityManager()
        
        with patch('tools.entity._HAS_SCHEMAS', False):
            schema = manager._get_entity_schema("unknown_type")
            assert schema == {}

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_apply_defaults_basic(self):
        """Test _apply_defaults with basic entity."""
        from tools.entity import EntityManager
        
        manager = EntityManager()
        manager._user_context = {"user_id": "user-123"}
        
        data = {"name": "Test Org"}
        result = manager._apply_defaults("organization", data)
        
        assert result["created_by"] == "user-123"
        assert result["updated_by"] == "user-123"
        assert "slug" in result

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_apply_defaults_no_user_id(self):
        """Test _apply_defaults without user_id."""
        from tools.entity import EntityManager
        
        manager = EntityManager()
        manager._user_context = {}
        
        data = {"name": "Test Org"}
        
        with pytest.raises(ValueError, match="user_id not available"):
            manager._apply_defaults("organization", data)

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_apply_defaults_project_owned_by(self):
        """Test _apply_defaults for project with owned_by."""
        from tools.entity import EntityManager
        
        manager = EntityManager()
        manager._user_context = {"user_id": "user-123"}
        
        data = {"name": "Test Project", "organization_id": "org-123"}
        result = manager._apply_defaults("project", data)
        
        assert result["owned_by"] == "user-123"

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_apply_defaults_requirement_external_id(self):
        """Test _apply_defaults for requirement with external_id."""
        from tools.entity import EntityManager
        
        manager = EntityManager()
        manager._user_context = {"user_id": "user-123"}
        
        data = {"name": "Test Requirement", "document_id": "doc-123"}
        result = manager._apply_defaults("requirement", data)
        
        assert "external_id" in result
        assert result["external_id"].startswith("REQ-")

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_apply_defaults_auto_slug(self):
        """Test _apply_defaults with auto_slug."""
        from tools.entity import EntityManager
        
        manager = EntityManager()
        manager._user_context = {"user_id": "user-123"}
        
        data = {"name": "Test Project Name"}
        result = manager._apply_defaults("project", data)
        
        assert "slug" in result
        assert result["slug"] == "test-project-name"

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_apply_defaults_existing_slug(self):
        """Test _apply_defaults with existing slug."""
        from tools.entity import EntityManager
        
        manager = EntityManager()
        manager._user_context = {"user_id": "user-123"}
        
        data = {"name": "Test", "slug": "custom-slug"}
        result = manager._apply_defaults("organization", data)
        
        assert result["slug"] == "custom-slug"

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_validate_required_fields_success(self):
        """Test _validate_required_fields with all required fields."""
        from tools.entity import EntityManager
        
        manager = EntityManager()
        
        data = {"name": "Test", "slug": "test"}
        # Should not raise
        manager._validate_required_fields("organization", data)

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_validate_required_fields_missing(self):
        """Test _validate_required_fields with missing fields."""
        from tools.entity import EntityManager
        
        manager = EntityManager()
        
        data = {"name": "Test"}  # Missing slug
        
        with pytest.raises(ValueError, match="Missing required fields"):
            manager._validate_required_fields("organization", data)

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_resolve_smart_defaults_auto_org(self):
        """Test _resolve_smart_defaults with auto organization_id."""
        from tools.entity import EntityManager
        
        manager = EntityManager()
        manager._user_context = {"user_id": "user-123"}
        
        mock_workspace = AsyncMock()
        mock_workspace.get_smart_defaults = AsyncMock(return_value={
            "organization_id": "org-123",
            "project_id": None,
            "document_id": None
        })
        
        data = {"name": "Test", "organization_id": "auto"}
        
        with patch('tools.entity._workspace_manager', mock_workspace):
            result = await manager._resolve_smart_defaults("project", data)
            
            assert result["organization_id"] == "org-123"

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_resolve_smart_defaults_auto_org_not_found(self):
        """Test _resolve_smart_defaults with auto org not found."""
        from tools.entity import EntityManager
        
        manager = EntityManager()
        manager._user_context = {"user_id": "user-123"}
        
        mock_workspace = AsyncMock()
        mock_workspace.get_smart_defaults = AsyncMock(return_value={
            "organization_id": None,
            "project_id": None,
            "document_id": None
        })
        
        data = {"name": "Test", "organization_id": "auto"}
        
        with patch('tools.entity._workspace_manager', mock_workspace):
            with pytest.raises(ValueError, match="No active organization"):
                await manager._resolve_smart_defaults("project", data)

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_resolve_smart_defaults_auto_project(self):
        """Test _resolve_smart_defaults with auto project_id."""
        from tools.entity import EntityManager
        
        manager = EntityManager()
        manager._user_context = {"user_id": "user-123"}
        
        mock_workspace = AsyncMock()
        mock_workspace.get_smart_defaults = AsyncMock(return_value={
            "organization_id": "org-123",
            "project_id": "proj-123",
            "document_id": None
        })
        
        data = {"name": "Test", "project_id": "auto"}
        
        with patch('tools.entity._workspace_manager', mock_workspace):
            result = await manager._resolve_smart_defaults("document", data)
            
            assert result["project_id"] == "proj-123"

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_resolve_smart_defaults_auto_document(self):
        """Test _resolve_smart_defaults with auto document_id."""
        from tools.entity import EntityManager
        
        manager = EntityManager()
        manager._user_context = {"user_id": "user-123"}
        
        mock_workspace = AsyncMock()
        mock_workspace.get_smart_defaults = AsyncMock(return_value={
            "organization_id": "org-123",
            "project_id": "proj-123",
            "document_id": "doc-123"
        })
        
        data = {"name": "Test", "document_id": "auto"}
        
        with patch('tools.entity._workspace_manager', mock_workspace):
            result = await manager._resolve_smart_defaults("requirement", data)
            
            assert result["document_id"] == "doc-123"

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_create_entity_success(self):
        """Test create_entity success."""
        from tools.entity import EntityManager
        
        manager = EntityManager()
        manager._user_context = {"user_id": "user-123"}
        
        mock_workspace = AsyncMock()
        mock_workspace.get_smart_defaults = AsyncMock(return_value={
            "organization_id": None,
            "project_id": None,
            "document_id": None
        })
        
        mock_db = AsyncMock()
        mock_db.insert = AsyncMock(return_value={"id": "org-123", "name": "Test Org"})
        
        data = {"name": "Test Org", "slug": "test-org"}
        
        with patch('tools.entity._workspace_manager', mock_workspace):
            with patch.object(manager, '_db_insert', mock_db.insert):
                result = await manager.create_entity("organization", data)
                
                assert result["id"] == "org-123"

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_create_entity_pydantic_validation(self):
        """Test create_entity with Pydantic validation."""
        from tools.entity import EntityManager
        
        manager = EntityManager()
        manager._user_context = {"user_id": "user-123"}
        
        mock_workspace = AsyncMock()
        mock_workspace.get_smart_defaults = AsyncMock(return_value={
            "organization_id": None,
            "project_id": None,
            "document_id": None
        })
        
        mock_db = AsyncMock()
        mock_db.insert = AsyncMock(return_value={"id": "org-123", "name": "Test Org"})
        
        data = {"name": "Test Org", "slug": "test-org"}
        
        with patch('tools.entity._HAS_SCHEMAS', True):
            with patch('tools.entity.partial_validate', return_value=data):
                with patch('tools.entity._workspace_manager', mock_workspace):
                    with patch.object(manager, '_db_insert', mock_db.insert):
                        result = await manager.create_entity("organization", data)
                        
                        assert result["id"] == "org-123"

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_create_entity_pydantic_exception(self):
        """Test create_entity with Pydantic validation exception."""
        from tools.entity import EntityManager
        
        manager = EntityManager()
        manager._user_context = {"user_id": "user-123"}
        
        mock_workspace = AsyncMock()
        mock_workspace.get_smart_defaults = AsyncMock(return_value={
            "organization_id": None,
            "project_id": None,
            "document_id": None
        })
        
        mock_db = AsyncMock()
        mock_db.insert = AsyncMock(return_value={"id": "org-123", "name": "Test Org"})
        
        data = {"name": "Test Org", "slug": "test-org"}
        
        with patch('tools.entity._HAS_SCHEMAS', True):
            with patch('tools.entity.partial_validate', side_effect=Exception("Validation error")):
                with patch('builtins.print'):  # Suppress print output
                    with patch('tools.entity._workspace_manager', mock_workspace):
                        with patch.object(manager, '_db_insert', mock_db.insert):
                            # Should continue with manual validation
                            result = await manager.create_entity("organization", data)
                            
                            assert result["id"] == "org-123"

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_read_entity_success(self):
        """Test read_entity success."""
        from tools.entity import EntityManager
        
        manager = EntityManager()
        
        mock_db = AsyncMock()
        mock_db.get_single = AsyncMock(return_value={"id": "org-123", "name": "Test Org"})
        
        with patch.object(manager, '_db_get_single', mock_db.get_single):
            result = await manager.read_entity("organization", "org-123")
            
            assert result["id"] == "org-123"
            assert result["name"] == "Test Org"

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_read_entity_not_found(self):
        """Test read_entity with not found."""
        from tools.entity import EntityManager
        
        manager = EntityManager()
        
        mock_db = AsyncMock()
        mock_db.get_single = AsyncMock(return_value=None)
        
        with patch.object(manager, '_db_get_single', mock_db.get_single):
            result = await manager.read_entity("organization", "org-123")
            
            assert result is None

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_update_entity_success(self):
        """Test update_entity success."""
        from tools.entity import EntityManager
        
        manager = EntityManager()
        manager._user_context = {"user_id": "user-123"}
        
        mock_db = AsyncMock()
        mock_db.update = AsyncMock(return_value={"id": "org-123", "name": "Updated Name"})
        
        data = {"name": "Updated Name"}
        
        with patch.object(manager, '_db_update', mock_db.update):
            result = await manager.update_entity("organization", "org-123", data)
            
            assert result["name"] == "Updated Name"

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_update_entity_with_updated_by(self):
        """Test update_entity sets updated_by."""
        from tools.entity import EntityManager
        
        manager = EntityManager()
        manager._user_context = {"user_id": "user-123"}
        
        mock_db = AsyncMock()
        mock_db.update = AsyncMock(return_value={"id": "org-123", "name": "Updated"})
        
        data = {"name": "Updated"}
        
        with patch.object(manager, '_db_update', mock_db.update) as mock_update:
            await manager.update_entity("organization", "org-123", data)
            
            # Check that updated_by was added
            call_args = mock_update.call_args
            assert call_args[0][2]["updated_by"] == "user-123"

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_delete_entity_success(self):
        """Test delete_entity success."""
        from tools.entity import EntityManager
        
        manager = EntityManager()
        
        mock_db = AsyncMock()
        mock_db.update = AsyncMock(return_value=1)
        
        with patch.object(manager, '_db_update', mock_db.update):
            result = await manager.delete_entity("organization", "org-123")
            
            assert result == 1

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_delete_entity_hard_delete(self):
        """Test delete_entity with hard delete."""
        from tools.entity import EntityManager
        
        manager = EntityManager()
        
        mock_db = AsyncMock()
        mock_db.delete = AsyncMock(return_value=1)
        
        with patch.object(manager, '_db_delete', mock_db.delete):
            result = await manager.delete_entity("organization", "org-123", hard=True)
            
            assert result == 1

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_list_entities_success(self):
        """Test list_entities success."""
        from tools.entity import EntityManager
        
        manager = EntityManager()
        
        mock_db = AsyncMock()
        mock_db.query = AsyncMock(return_value=[
            {"id": "org-1", "name": "Org 1"},
            {"id": "org-2", "name": "Org 2"}
        ])
        
        with patch.object(manager, '_db_query', mock_db.query):
            result = await manager.list_entities("organization", limit=10)
            
            assert len(result) == 2

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_list_entities_with_filters(self):
        """Test list_entities with filters."""
        from tools.entity import EntityManager
        
        manager = EntityManager()
        
        mock_db = AsyncMock()
        mock_db.query = AsyncMock(return_value=[{"id": "org-1", "name": "Org 1"}])
        
        filters = {"type": "team"}
        
        with patch.object(manager, '_db_query', mock_db.query):
            result = await manager.list_entities("organization", filters=filters)
            
            assert len(result) == 1

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_search_entities_success(self):
        """Test search_entities success."""
        from tools.entity import EntityManager
        
        manager = EntityManager()
        
        mock_db = AsyncMock()
        mock_db.query = AsyncMock(return_value=[
            {"id": "org-1", "name": "Test Organization"}
        ])
        
        with patch.object(manager, '_db_query', mock_db.query):
            result = await manager.search_entities("organization", "Test")
            
            assert len(result) == 1

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_search_entities_fuzzy_match(self):
        """Test search_entities with fuzzy match."""
        from tools.entity import EntityManager
        
        manager = EntityManager()
        
        mock_db = AsyncMock()
        mock_db.query = AsyncMock(return_value=[
            {"id": "org-1", "name": "Test Organization"}
        ])
        
        with patch.object(manager, '_db_query', mock_db.query):
            result = await manager.search_entities("organization", "Tst", fuzzy=True)
            
            assert len(result) >= 0  # Fuzzy may or may not match

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_batch_create_entities(self):
        """Test batch_create_entities."""
        from tools.entity import EntityManager
        
        manager = EntityManager()
        manager._user_context = {"user_id": "user-123"}
        
        mock_workspace = AsyncMock()
        mock_workspace.get_smart_defaults = AsyncMock(return_value={
            "organization_id": None,
            "project_id": None,
            "document_id": None
        })
        
        mock_db = AsyncMock()
        mock_db.insert = AsyncMock(return_value=[
            {"id": "org-1", "name": "Org 1"},
            {"id": "org-2", "name": "Org 2"}
        ])
        
        data_list = [
            {"name": "Org 1", "slug": "org-1"},
            {"name": "Org 2", "slug": "org-2"}
        ]
        
        with patch('tools.entity._workspace_manager', mock_workspace):
            with patch.object(manager, '_db_insert', mock_db.insert):
                result = await manager.batch_create_entities("organization", data_list)
                
                assert len(result) == 2

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_batch_update_entities(self):
        """Test batch_update_entities."""
        from tools.entity import EntityManager
        
        manager = EntityManager()
        manager._user_context = {"user_id": "user-123"}
        
        mock_db = AsyncMock()
        mock_db.update = AsyncMock(return_value=2)
        
        updates = [
            {"id": "org-1", "name": "Updated 1"},
            {"id": "org-2", "name": "Updated 2"}
        ]
        
        with patch.object(manager, '_db_update', mock_db.update):
            result = await manager.batch_update_entities("organization", updates)
            
            assert result == 2

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_batch_delete_entities(self):
        """Test batch_delete_entities."""
        from tools.entity import EntityManager
        
        manager = EntityManager()
        
        mock_db = AsyncMock()
        mock_db.update = AsyncMock(return_value=2)
        
        entity_ids = ["org-1", "org-2"]
        
        with patch.object(manager, '_db_update', mock_db.update):
            result = await manager.batch_delete_entities("organization", entity_ids)
            
            assert result == 2

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_entity_operation_create(self):
        """Test entity_operation with create."""
        from tools.entity import entity_operation
        
        mock_manager = AsyncMock()
        mock_manager.create_entity = AsyncMock(return_value={"id": "org-123", "name": "Test"})
        
        with patch('tools.entity._entity_manager', mock_manager):
            with patch('tools.entity.ToolBase._validate_auth', new_callable=AsyncMock) as mock_auth:
                mock_auth.return_value = {"user_id": "user-123"}
                
                result = await entity_operation(
                    "token",
                    "create",
                    "organization",
                    {"name": "Test", "slug": "test"}
                )
                
                assert result["id"] == "org-123"

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_entity_operation_read(self):
        """Test entity_operation with read."""
        from tools.entity import entity_operation
        
        mock_manager = AsyncMock()
        mock_manager.read_entity = AsyncMock(return_value={"id": "org-123", "name": "Test"})
        
        with patch('tools.entity._entity_manager', mock_manager):
            with patch('tools.entity.ToolBase._validate_auth', new_callable=AsyncMock) as mock_auth:
                mock_auth.return_value = {"user_id": "user-123"}
                
                result = await entity_operation(
                    "token",
                    "read",
                    "organization",
                    None,
                    entity_id="org-123"
                )
                
                assert result["id"] == "org-123"

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_entity_operation_update(self):
        """Test entity_operation with update."""
        from tools.entity import entity_operation
        
        mock_manager = AsyncMock()
        mock_manager.update_entity = AsyncMock(return_value={"id": "org-123", "name": "Updated"})
        
        with patch('tools.entity._entity_manager', mock_manager):
            with patch('tools.entity.ToolBase._validate_auth', new_callable=AsyncMock) as mock_auth:
                mock_auth.return_value = {"user_id": "user-123"}
                
                result = await entity_operation(
                    "token",
                    "update",
                    "organization",
                    {"name": "Updated"},
                    entity_id="org-123"
                )
                
                assert result["name"] == "Updated"

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_entity_operation_delete(self):
        """Test entity_operation with delete."""
        from tools.entity import entity_operation
        
        mock_manager = AsyncMock()
        mock_manager.delete_entity = AsyncMock(return_value=1)
        
        with patch('tools.entity._entity_manager', mock_manager):
            with patch('tools.entity.ToolBase._validate_auth', new_callable=AsyncMock) as mock_auth:
                mock_auth.return_value = {"user_id": "user-123"}
                
                result = await entity_operation(
                    "token",
                    "delete",
                    "organization",
                    None,
                    entity_id="org-123"
                )
                
                assert result == 1

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_entity_operation_list(self):
        """Test entity_operation with list."""
        from tools.entity import entity_operation
        
        mock_manager = AsyncMock()
        mock_manager.list_entities = AsyncMock(return_value=[
            {"id": "org-1", "name": "Org 1"}
        ])
        
        with patch('tools.entity._entity_manager', mock_manager):
            with patch('tools.entity.ToolBase._validate_auth', new_callable=AsyncMock) as mock_auth:
                mock_auth.return_value = {"user_id": "user-123"}
                
                result = await entity_operation(
                    "token",
                    "list",
                    "organization"
                )
                
                assert len(result) == 1

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_entity_operation_search(self):
        """Test entity_operation with search."""
        from tools.entity import entity_operation
        
        mock_manager = AsyncMock()
        mock_manager.search_entities = AsyncMock(return_value=[
            {"id": "org-1", "name": "Test Org"}
        ])
        
        with patch('tools.entity._entity_manager', mock_manager):
            with patch('tools.entity.ToolBase._validate_auth', new_callable=AsyncMock) as mock_auth:
                mock_auth.return_value = {"user_id": "user-123"}
                
                result = await entity_operation(
                    "token",
                    "search",
                    "organization",
                    {"query": "Test"}
                )
                
                assert len(result) == 1

    @pytest.mark.asyncio
    @pytest.mark.mock_only
    async def test_entity_operation_invalid(self):
        """Test entity_operation with invalid operation."""
        from tools.entity import entity_operation
        
        with patch('tools.entity.ToolBase._validate_auth', new_callable=AsyncMock) as mock_auth:
            mock_auth.return_value = {"user_id": "user-123"}
            
            with pytest.raises(ValueError, match="Invalid operation"):
                await entity_operation(
                    "token",
                    "invalid",
                    "organization"
                )
