#!/usr/bin/env python3
"""Stream local MCP logs using observability-kit primitives."""

import asyncio
import os
from pathlib import Path

from observability.logging import StructuredLogger, stream_log_file
from pydevkit.correlation_id import generate_correlation_id


async def main() -> None:
    log_path = Path(os.getenv("ATOMS_LOG_PATH", "/tmp/atoms_mcp.log"))
    logger = StructuredLogger(
        "atoms-dev-monitor",
        service_name="atoms-mcp",
        environment=os.getenv("ENV", "dev"),
    )
    logger.set_correlation_id(generate_correlation_id())
    logger.info("monitor_start", path=str(log_path))

    try:
        async for entry in stream_log_file(log_path):
            logger.info("log_line", **entry)
    except KeyboardInterrupt:
        logger.info("monitor_stopped")


if __name__ == "__main__":
    asyncio.run(main())
