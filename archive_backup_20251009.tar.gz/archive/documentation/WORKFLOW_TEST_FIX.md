# Workflow Test Fix - Proper UUID Usage

## Issue
Test was using hardcoded UUID `"proj-test-123"` which caused:
```
invalid input syntax for type uuid: "proj-test-123"
```

## Solution
Updated `test_workflow.py::test_setup_test_matrix` to use proper **create→operate→delete** flow:

### Flow
1. **Create** - Get organization, create test project with real UUID
2. **Operate** - Run `setup_test_matrix` workflow with real project ID
3. **Delete** - Cleanup test project in finally block

### Changes
```python
async def test_setup_test_matrix(client):
    # Get organization
    org_result = await client.call_tool("entity_tool", {"entity_type": "organization", "operation": "list"})
    org_id = org_result["response"]["organizations"][0]["id"]
    
    # CREATE: Make test project
    project_data = DataGenerator.project_data(name=f"Test Matrix Project {timestamp}", organization_id=org_id)
    create_result = await client.call_tool("entity_tool", {"entity_type": "project", "operation": "create", "data": project_data})
    project_id = create_result["response"]["project"]["id"]
    
    try:
        # OPERATE: Test workflow with real UUID
        result = await client.call_tool("workflow_tool", {"workflow": "setup_test_matrix", "parameters": {"project_id": project_id}})
        assert result["success"]
        
    finally:
        # DELETE: Cleanup
        await client.call_tool("entity_tool", {"entity_type": "project", "operation": "delete", "id": project_id})
```

## Benefits
✅ Uses real UUIDs from database  
✅ Proper cleanup with finally block  
✅ No hardcoded test data  
✅ Tests actual workflow behavior  
✅ Follows best practice pattern

## Result
Test now properly:
1. Creates project with valid UUID
2. Tests workflow with that UUID
3. Cleans up automatically

---

**Fixed:** `tests/test_workflow.py::test_setup_test_matrix`  
**Pattern:** Create → Operate → Delete  
**Status:** ✅ Ready to test
