# Pytest ImportError Fix - atoms_mcp-old

## Issue

When running pytest, got import error:
```
ModuleNotFoundError: No module named 'event_kit'
```

## Root Cause

`tests/conftest.py` was importing `event_kit` and `workflow_kit` as required imports:
```python
from event_kit import EventBus, Event
from workflow_kit import WorkflowEngine, Workflow, WorkflowStep
```

These are custom pheno-sdk packages that aren't always installed.

## Solution

Made these imports optional with try/except blocks:

```python
# Import pheno-sdk kits for testing (optional)
try:
    from event_kit import EventBus, Event
    HAS_EVENT_KIT = True
except ImportError:
    HAS_EVENT_KIT = False
    EventBus = None
    Event = None

try:
    from workflow_kit import WorkflowEngine, Workflow, WorkflowStep
    HAS_WORKFLOW_KIT = True
except ImportError:
    HAS_WORKFLOW_KIT = False
    WorkflowEngine = None
    Workflow = None
    WorkflowStep = None
```

Then updated fixtures to skip if packages not available:

```python
@pytest.fixture(scope="session")
def event_bus():
    """Provide event-kit event bus for test events."""
    if not HAS_EVENT_KIT:
        pytest.skip("event_kit not installed")
    return EventBus()
```

## Result

✅ Pytest now works without event_kit/workflow_kit installed
✅ Tests that need these packages will be skipped
✅ 85 tests collected successfully

## Verification

```bash
cd /Users/kooshapari/temp-PRODVERCEL/485/kush/atoms_mcp-old
source .venv/bin/activate

# Verify pytest can collect tests
pytest tests/ --collect-only

# Run tests
pytest tests/ -v

# Run in parallel
pytest tests/ -v -n auto
```

## File Modified

- `tests/conftest.py` - Made event_kit and workflow_kit imports optional
