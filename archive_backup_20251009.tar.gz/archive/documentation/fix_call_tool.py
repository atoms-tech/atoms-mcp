#!/usr/bin/env python3
"""
Fix all test files to use client_adapter.call_tool() instead of client_adapter.client.call_tool()
"""

import re
from pathlib import Path

# Files to fix
TEST_FILES = [
    "tests/test_workspace.py",
    "tests/test_entity.py",
    "tests/test_query.py",
    "tests/test_relationship.py",
    "tests/test_workflow.py",
    "tests/test_workspace_comprehensive.py",
    "tests/test_entity_comprehensive.py",
    "tests/test_query_comprehensive.py",
]

def fix_file(filepath: Path) -> int:
    """Fix a single file. Returns number of replacements."""
    if not filepath.exists():
        print(f"⚠️  File not found: {filepath}")
        return 0
    
    content = filepath.read_text()
    
    # Pattern 1: await client_adapter.client.call_tool(
    pattern1 = r'await client_adapter\.client\.call_tool\('
    replacement1 = r'await client_adapter.call_tool('
    
    new_content, count1 = re.subn(pattern1, replacement1, content)
    
    # Pattern 2: client_adapter.client.call_tool( (without await)
    pattern2 = r'(?<!await )client_adapter\.client\.call_tool\('
    replacement2 = r'client_adapter.call_tool('
    
    new_content, count2 = re.subn(pattern2, replacement2, new_content)
    
    total_count = count1 + count2
    
    if total_count > 0:
        filepath.write_text(new_content)
        print(f"✅ Fixed {filepath.name}: {total_count} replacements")
    else:
        print(f"ℹ️  No changes needed: {filepath.name}")
    
    return total_count

def main():
    base_dir = Path(__file__).parent
    total_fixed = 0
    
    print("🔧 Fixing test files to use client_adapter.call_tool()...\n")
    
    for test_file in TEST_FILES:
        filepath = base_dir / test_file
        fixed = fix_file(filepath)
        total_fixed += fixed
    
    print(f"\n✅ Total replacements: {total_fixed}")

if __name__ == "__main__":
    main()
