#!/usr/bin/env python3
"""
Atoms MCP Log Monitor - Real-time log viewer with filtering

Similar to zen-mcp-server's monitor but focused on log viewing and OAuth flow monitoring.
"""

import asyncio
import os
import sys
from pathlib import Path
from collections import deque
from datetime import datetime

# Add project root for imports
PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT))

try:
    from rich.console import Console
    from rich.live import Live
    from rich.panel import Panel
    from rich.table import Table
    from rich.layout import Layout
    from rich import box
    from rich.text import Text
except ImportError:
    print("❌ Missing rich. Install with: pip install rich")
    sys.exit(1)

# Import logging setup
from utils.logging_setup import setup_logging, get_logger

# Setup logging
setup_logging(level="INFO", use_color=True, use_timestamps=True)
logger = get_logger(__name__)

class AtomsLogMonitor:
    """Real-time log monitor for atoms_mcp-old with OAuth flow tracking."""
    
    def __init__(self):
        self.console = Console()
        self.log_buffer = deque(maxlen=100)  # Keep last 100 log entries
        self.log_file_positions = {}
        self.oauth_status = {"state": "idle", "last_update": None}
        
        # Common log files to monitor
        self.log_files = [
            PROJECT_ROOT / "logs" / "atoms_mcp.log",
            Path.home() / ".atoms_mcp" / "oauth.log",
            Path.home() / ".atoms_mcp" / "test.log",
        ]
        
        # Ensure log directories exist
        for log_file in self.log_files:
            log_file.parent.mkdir(parents=True, exist_ok=True)
    
    def _make_layout(self) -> Layout:
        """Create the layout."""
        layout = Layout()
        layout.split_column(
            Layout(name="header", size=8),
            Layout(name="oauth_status", size=6),
            Layout(name="logs"),  # Takes remaining space
        )
        return layout
    
    def _make_header(self) -> Panel:
        """Create header panel."""
        banner = """
╔════════════════════════════════════════════════════╗
║   🔬 Atoms MCP Log Monitor                         ║
║   Real-time OAuth & Test Log Monitoring            ║
║                                                    ║
║   Press Ctrl+C to exit                             ║
╚════════════════════════════════════════════════════╝
"""
        return Panel(banner, style="cyan", box=box.DOUBLE)
    
    def _make_oauth_status(self) -> Panel:
        """Create OAuth status panel."""
        state = self.oauth_status["state"]
        last_update = self.oauth_status.get("last_update")
        
        if state == "idle":
            status_text = "🟢 Ready - No active OAuth flows"
            status_color = "green"
        elif state == "authenticating":
            status_text = "🟡 OAuth flow in progress..."
            status_color = "yellow"
        elif state == "success":
            status_text = "✅ OAuth completed successfully"
            status_color = "green"
        elif state == "error":
            status_text = "❌ OAuth failed - check logs"
            status_color = "red"
        else:
            status_text = f"🔄 {state}"
            status_color = "blue"
        
        content = f"[{status_color}]{status_text}[/{status_color}]"
        if last_update:
            content += f"\n[dim]Last update: {last_update}[/dim]"
        
        return Panel(
            content,
            title="[bold cyan]OAuth Status[/bold cyan]",
            box=box.ROUNDED
        )
    
    def _make_logs_panel(self) -> Panel:
        """Create live logs panel."""
        if not self.log_buffer:
            content = "[dim]Waiting for log output...[/dim]"
        else:
            # Join the last log lines
            log_lines = list(self.log_buffer)
            content = "\n".join(log_lines[-30:])  # Show last 30 lines
        
        return Panel(
            content,
            title="[bold cyan]Live Logs[/bold cyan]",
            box=box.ROUNDED,
            expand=True
        )
    
    async def _tail_log_files(self):
        """Tail log files for real-time output."""
        for log_file in self.log_files:
            if log_file.exists():
                try:
                    file_path_str = str(log_file)
                    
                    # Get current file size
                    current_size = log_file.stat().st_size
                    
                    # Skip if file hasn't grown since last check
                    if file_path_str in self.log_file_positions:
                        if current_size <= self.log_file_positions[file_path_str]:
                            continue
                    else:
                        # First time - start from end to avoid old logs
                        self.log_file_positions[file_path_str] = current_size
                        continue
                    
                    # Read only new content
                    with open(log_file, 'r', encoding='utf-8', errors='ignore') as f:
                        f.seek(self.log_file_positions[file_path_str])
                        new_lines = f.readlines()
                        
                        # Update position
                        self.log_file_positions[file_path_str] = f.tell()
                        
                        # Process new lines
                        for line in new_lines:
                            line = line.strip()
                            if line:
                                await self._process_log_line(line, log_file.stem)
                                
                except Exception as e:
                    logger.debug(f"Error tailing {log_file}: {e}")
    
    async def _process_log_line(self, line: str, source: str):
        """Process a log line and update OAuth status if relevant."""
        timestamp = datetime.now().strftime("%H:%M:%S")
        
        # Update OAuth status based on log content
        if "oauth" in line.lower() or "authentication" in line.lower():
            if "progress" in line.lower() or "waiting" in line.lower():
                self.oauth_status["state"] = "authenticating"
                self.oauth_status["last_update"] = timestamp
            elif "success" in line.lower() or "authenticated" in line.lower():
                self.oauth_status["state"] = "success"
                self.oauth_status["last_update"] = timestamp
            elif "error" in line.lower() or "failed" in line.lower():
                self.oauth_status["state"] = "error"
                self.oauth_status["last_update"] = timestamp
        
        # Format and add to buffer
        formatted_line = f"[dim]{timestamp}[/dim] [{source}] {line}"
        
        # Color code based on log level
        if "ERROR" in line or "❌" in line:
            formatted_line = f"[red]{formatted_line}[/red]"
        elif "WARN" in line or "⚠️" in line:
            formatted_line = f"[yellow]{formatted_line}[/yellow]"
        elif "INFO" in line or "✅" in line:
            formatted_line = f"[blue]{formatted_line}[/blue]"
        elif "DEBUG" in line:
            formatted_line = f"[dim]{formatted_line}[/dim]"
        
        self.log_buffer.append(formatted_line)
    
    async def _capture_logs(self):
        """Main log capture loop."""
        while True:
            try:
                await self._tail_log_files()
                
                # Add system status every 30 seconds
                if len(self.log_buffer) == 0 or len(self.log_buffer) % 60 == 0:
                    timestamp = datetime.now().strftime("%H:%M:%S")
                    status_entry = f"[dim]{timestamp}[/dim] [system] Monitor active - watching {len(self.log_files)} log files"
                    self.log_buffer.append(status_entry)
                
            except Exception as e:
                timestamp = datetime.now().strftime("%H:%M:%S")
                error_entry = f"[dim]{timestamp}[/dim] [red][monitor] Log capture error: {e}[/red]"
                self.log_buffer.append(error_entry)
            
            await asyncio.sleep(1)  # Check every second
    
    def _render_screen(self, layout: Layout):
        """Update the layout."""
        layout["header"].update(self._make_header())
        layout["oauth_status"].update(self._make_oauth_status())
        layout["logs"].update(self._make_logs_panel())
    
    async def run(self):
        """Run the log monitor."""
        self.console.print("[bold cyan]🔬 Atoms MCP Log Monitor - Starting...[/bold cyan]")
        self.console.print()
        self.console.print("📂 Monitoring log files:")
        for log_file in self.log_files:
            status = "✅ exists" if log_file.exists() else "⚪ will be created"
            self.console.print(f"   {log_file} - {status}")
        self.console.print()
        self.console.print("[dim]Press Ctrl+C to stop[/dim]")
        self.console.print()
        
        # Create layout
        layout = self._make_layout()
        
        # Start log capture task
        log_capture_task = asyncio.create_task(self._capture_logs())
        
        try:
            # Live display
            with Live(layout, console=self.console, refresh_per_second=2, screen=False):
                while True:
                    self._render_screen(layout)
                    await asyncio.sleep(0.5)
        except KeyboardInterrupt:
            pass
        finally:
            # Cancel log capture
            log_capture_task.cancel()
            try:
                await log_capture_task
            except asyncio.CancelledError:
                pass
            
            self.console.print("\n🛑 Log monitor stopped", style="yellow")


def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="Atoms MCP Log Monitor")
    parser.add_argument("--log-files", nargs="+", help="Additional log files to monitor")
    
    args = parser.parse_args()
    
    monitor = AtomsLogMonitor()
    
    # Add additional log files if specified
    if args.log_files:
        for log_file_path in args.log_files:
            log_file = Path(log_file_path)
            if log_file not in monitor.log_files:
                monitor.log_files.append(log_file)
    
    try:
        asyncio.run(monitor.run())
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()