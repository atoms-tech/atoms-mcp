#!/usr/bin/env python3
"""
Replace pytest.skip() calls with returning a skip result dict.
This makes tests work in both pytest and standalone modes.
"""

import re
from pathlib import Path

def fix_file(filepath: Path) -> int:
    """Fix a single file. Returns number of replacements."""
    if not filepath.exists():
        print(f"⚠️  File not found: {filepath}")
        return 0
    
    content = filepath.read_text()
    
    # Pattern: pytest.skip("reason")
    # Replace with: return {"success": True, "skipped": True, "skip_reason": "reason"}
    pattern = r'pytest\.skip\("([^"]+)"\)'
    replacement = r'return {"success": True, "skipped": True, "skip_reason": "\1"}'
    
    new_content, count = re.subn(pattern, replacement, content)
    
    if count > 0:
        filepath.write_text(new_content)
        print(f"✅ Fixed {filepath.name}: {count} replacements")
    else:
        print(f"ℹ️  No changes needed: {filepath.name}")
    
    return count

def main():
    base_dir = Path(__file__).parent / "tests"
    
    # Find all test files
    test_files = list(base_dir.glob("test_*.py"))
    
    print(f"🔧 Fixing pytest.skip() calls in {len(test_files)} test files...\n")
    
    total_fixed = 0
    for test_file in sorted(test_files):
        fixed = fix_file(test_file)
        total_fixed += fixed
    
    print(f"\n✅ Total replacements: {total_fixed}")

if __name__ == "__main__":
    main()
