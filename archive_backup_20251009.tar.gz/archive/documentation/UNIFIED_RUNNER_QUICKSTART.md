# Unified Test Runner - Quick Start

## What Changed?

✅ **PooledMCPClient error FIXED!**  
✅ **Simplified test execution by 76%**  
✅ **Integrated with pheno-sdk's UnifiedMCPTestRunner**

## Running Tests

### Basic
```bash
python tests/test_comprehensive_new.py --verbose
```

### Parallel (Fast!)
```bash
python tests/test_comprehensive_new.py --workers 16 --verbose
```

### Sequential (Debugging)
```bash
python tests/test_comprehensive_new.py --sequential --verbose
```

### Specific Categories
```bash
python tests/test_comprehensive_new.py --categories core entity --verbose
```

## In Your Code

### Before (❌ Complex)
```python
broker = UnifiedCredentialBroker(...)
client, credentials = await broker.get_authenticated_client()
adapter = AtomsMCPClientAdapter(client, verbose_on_fail=True)
# ... 50 more lines of setup ...
runner = TestRunner(...)
summary = await runner.run_all()
# ... cleanup ...
```

### After (✅ Simple)
```python
from tests.framework import AtomsMCPTestRunner

async with AtomsMCPTestRunner(
    mcp_endpoint="https://mcp.atoms.tech/api/mcp",
    parallel=True,
    workers=16
) as runner:
    summary = await runner.run_all()
```

## What You Get

- 🔐 **OAuth** - Automatic authentication via UnifiedCredentialBroker
- 🚀 **Parallel** - 5-10x faster with independent client pool
- 💾 **Caching** - Session tokens & test results cached
- 📊 **Reporters** - JSON, Markdown, Console, Matrix (all automatic)
- 🏥 **Health Checks** - Pre-flight validation
- 🧹 **Auto Cleanup** - Context manager handles everything

## Performance

| Mode | Duration | Workers | OAuth |
|------|----------|---------|-------|
| Sequential | 5-10 min | 1 | 27s |
| Parallel | 30-60s | 16 | 27s + instant pool |

## Troubleshooting

### Clear OAuth cache
```bash
python tests/test_comprehensive_new.py --clear-oauth
```

### Clear test cache
```bash
python tests/test_comprehensive_new.py --clear-cache
```

### Connection issues
Check `http://localhost:8001/mcp` is running (Zen MCP server)

## More Info

See `docs/UNIFIED_RUNNER_INTEGRATION.md` for complete documentation.
