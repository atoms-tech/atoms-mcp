"""
OAuth Authentication Helper

Provides automated OAuth login using Playwright for Atoms MCP testing.
"""

import asyncio
from typing import Optional


try:
    from tests.framework.oauth_automation import FlowResult, create_default_automator
    _OAUTH_AUTOMATOR = create_default_automator()
    _OAUTH_AUTOMATOR_ERROR: Optional[Exception] = None
except Exception as exc:  # noqa: BLE001 - propagate at call time
    _OAUTH_AUTOMATOR = None
    _OAUTH_AUTOMATOR_ERROR = exc


_LAST_FLOW_RESULT: Optional[FlowResult] = None


def _ensure_automator() -> None:
    if _OAUTH_AUTOMATOR is None:
        raise RuntimeError(
            "Playwright OAuth automator is unavailable. Install Playwright dependencies "
            "and ensure playwright browsers are installed."
        ) from _OAUTH_AUTOMATOR_ERROR


async def automate_oauth_login_with_retry(
    oauth_url: str,
    vercel_log_file: Optional[str] = None,
    max_retries: int = 3,
    provider: str = "authkit",
    credential_overrides: Optional[dict] = None,
) -> bool:
    """Automate OAuth with retry logic (silent mode)."""
    for attempt in range(1, max_retries + 1):
        try:
            success = await automate_oauth_login(
                oauth_url,
                vercel_log_file=vercel_log_file,
                provider=provider,
                credential_overrides=credential_overrides,
            )
            if success:
                return True

            if attempt < max_retries:
                await asyncio.sleep(2 ** attempt)
        except Exception as e:
            error_msg = str(e)
            if "502" in error_msg or "503" in error_msg or "530" in error_msg:
                if attempt < max_retries:
                    await asyncio.sleep(2 ** attempt)
                else:
                    return False
            else:
                raise

    return False


async def automate_oauth_login(
    oauth_url: str,
    vercel_log_file: Optional[str] = None,
    provider: str = "authkit",
    credential_overrides: Optional[dict] = None,
) -> bool:
    """Automate OAuth login via the shared automation layer."""

    _ensure_automator()
    global _LAST_FLOW_RESULT

    try:
        from tests.framework.oauth_progress import OAuthProgressFlow
    except Exception:
        OAuthProgressFlow = None  # type: ignore[misc]

    progress = OAuthProgressFlow() if OAuthProgressFlow else None

    if progress:
        with progress:
            progress.step("Launching OAuth automation")
            try:
                flow_result = await _OAUTH_AUTOMATOR.authenticate(
                    oauth_url,
                    provider=provider,
                    credential_overrides=credential_overrides,
                )
                progress.complete("OAuth automation complete")
                _LAST_FLOW_RESULT = flow_result
                return flow_result.success
            except Exception as exc:  # noqa: BLE001 - propagate for callers to handle
                progress.error(f"OAuth failed: {exc}")
                raise

    flow_result = await _OAUTH_AUTOMATOR.authenticate(
        oauth_url,
        provider=provider,
        credential_overrides=credential_overrides,
    )

    _LAST_FLOW_RESULT = flow_result

    return flow_result.success


def get_last_flow_result() -> Optional[FlowResult]:
    """Return the most recent FlowResult captured during OAuth automation."""

    return _LAST_FLOW_RESULT
