# Database Fixes for Atoms MCP Test Suite

## Overview

This document explains the database fixes needed to achieve 100% pass rate on the comprehensive test suite.

## Issues Fixed

### 1. ✅ Organization Create/Update Trigger
**Issue**: `updated_by` NOT NULL constraint fails on INSERT/UPDATE
**Impact**: Organization create operations fail
**Solution**: Trigger auto-sets `updated_by` from `auth.uid()` or `created_by` as fallback

### 2. ✅ test_req Table RLS Policies
**Issue**: TABLE_ACCESS_RESTRICTED when accessing test entities
**Impact**: All test entity operations fail with permission error
**Solution**: Proper RLS policies matching requirements table pattern

### 3. ✅ RAG Semantic Search
**Issue**: NoneType error when embeddings are NULL
**Impact**: RAG semantic search fails
**Solution**: Already fixed in code - empty embedding check added

## How to Apply

### Option 1: Apply All Fixes at Once (Recommended)

```bash
# In Supabase Dashboard:
# 1. Go to SQL Editor
# 2. Open APPLY_ALL_FIXES.sql
# 3. Click "Run"
```

The file is located at: `/migrations/APPLY_ALL_FIXES.sql`

### Option 2: Apply Individual Fixes

If you prefer to apply fixes one at a time:

1. **Organization Trigger**: Run `migrations/fix_organization_create.sql`
2. **test_req RLS**: Run `migrations/add_test_req_rls.sql`
3. **RAG Semantic**: No SQL needed (code fix already deployed)

## Verification

After applying the SQL fixes, verify they worked:

```sql
-- 1. Check organization trigger exists
SELECT tgname FROM pg_trigger
WHERE tgrelid = 'public.organizations'::regclass
AND tgname = 'tr_organization_audit';

-- 2. Check test_req policies
SELECT policyname FROM pg_policies WHERE tablename = 'test_req';

-- 3. Check no NULL updated_by
SELECT COUNT(*) FROM organizations WHERE updated_by IS NULL;
-- Should return 0
```

## Test Suite Impact

After applying these fixes, run the comprehensive test suite:

```bash
python tests/test_comprehensive_new.py --coverage-level comprehensive --parallel --workers 10
```

**Expected Improvements:**
- ✅ Organization create operations: PASS
- ✅ Test entity operations: PASS
- ✅ RAG semantic search: PASS
- ✅ Overall pass rate: 90%+

## Code Fixes (Already Applied)

The following code fixes are already deployed:
- UUID-based slug generation
- Auto parent ID resolution in create_test_entity
- Parameter name corrections (context_type, entity_id, search_term, format_type)
- workspace_tool limit/offset exposure
- CREATE→OPERATE→DELETE pattern in all tests

## Files

- `APPLY_ALL_FIXES.sql` - Single script to apply all DB fixes
- `migrations/fix_organization_create.sql` - Organization trigger fix
- `migrations/add_test_req_rls.sql` - test_req RLS policies
- `migrations/fix_rag_semantic_search.sql` - Documentation (code fix already applied)
