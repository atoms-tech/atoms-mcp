#!/usr/bin/env python3
"""
Convert all @mcp_test decorated tests to pytest-compatible format.
Keeps custom framework features while enabling pytest-xdist parallelization.
"""

import re
from pathlib import Path

def convert_test_file(file_path: Path) -> bool:
    """Convert a single test file to pytest format."""
    content = file_path.read_text()
    
    # Skip if already converted
    if "@pytest.mark.asyncio" in content:
        print(f"✓ {file_path.name} - already converted")
        return False
    
    # Skip if doesn't have @mcp_test
    if "@mcp_test" not in content:
        print(f"⊘ {file_path.name} - no @mcp_test decorators")
        return False
    
    original_content = content
    
    # 1. Add pytest import after framework import
    if "import pytest" not in content:
        content = content.replace(
            "from .framework import mcp_test",
            "import pytest\nfrom .framework import mcp_test"
        )
    
    # 2. Update function signatures: client -> client_adapter
    content = re.sub(
        r"async def (test_\w+)\(client\):",
        r"async def \1(client_adapter):",
        content
    )
    
    # 3. Update client.call_tool -> client_adapter.client.call_tool
    content = re.sub(
        r"await client\.call_tool\(",
        r"await client_adapter.client.call_tool(",
        content
    )
    
    # 4. Add pytest decorators before @mcp_test
    def add_pytest_decorators(match):
        indent = match.group(1)
        mcp_test_line = match.group(2)
        return f"{indent}@pytest.mark.asyncio\n{indent}@pytest.mark.parallel\n{indent}{mcp_test_line}"
    
    content = re.sub(
        r"(\n)(@mcp_test\()",
        add_pytest_decorators,
        content
    )
    
    # 5. Replace return {"success": False, "skipped": True, ...} with pytest.skip()
    def replace_skip_returns(match):
        indent = match.group(1)
        skip_reason = match.group(2)
        return f'{indent}pytest.skip({skip_reason})'
    
    content = re.sub(
        r'(\s+)return \{"success": False, "skipped": True, "skip_reason": ([^\}]+)\}',
        replace_skip_returns,
        content
    )
    
    # 6. Remove success return statements at end of tests
    content = re.sub(
        r'\n\s+return \{"success": True, "error": None\}\n',
        '\n',
        content
    )
    
    # 7. Update docstring if needed
    if "pytest-xdist" not in content and "decorator-based framework" in content:
        content = content.replace(
            "using decorator-based framework.",
            "using decorator-based framework.\nNow compatible with pytest-xdist for parallel execution."
        )
    
    # Write back if changed
    if content != original_content:
        file_path.write_text(content)
        print(f"✓ {file_path.name} - converted")
        return True
    else:
        print(f"⊘ {file_path.name} - no changes needed")
        return False


def main():
    tests_dir = Path(__file__).parent / "tests"
    
    # Find all test_*.py files (exclude test_comprehensive_new.py as it's a runner)
    test_files = [
        f for f in tests_dir.glob("test_*.py")
        if f.name != "test_comprehensive_new.py"
    ]
    
    print(f"Found {len(test_files)} test files to convert\n")
    
    converted_count = 0
    for test_file in sorted(test_files):
        if convert_test_file(test_file):
            converted_count += 1
    
    print(f"\n✅ Converted {converted_count}/{len(test_files)} files to pytest format")
    print("\nYou can now run tests with:")
    print("  pytest -n auto tests/            # Parallel execution")
    print("  pytest -n 8 tests/               # 8 workers")
    print("  pytest tests/test_workspace.py   # Single file")


if __name__ == "__main__":
    main()
