#!/usr/bin/env python3
"""
TDD Test Runner with Interactive TUI Dashboard and Session-Scoped OAuth

This provides the same rich TUI experience as before, but with:
- Session-scoped OAuth (authenticate once, use for all tests)
- Direct HTTP tool calls (better parallelization)
- Individual tool testing capabilities
- Real-time test progress with OAuth status

Usage:
    python tests/tdd_runner.py                    # Full TUI dashboard
    python tests/tdd_runner.py --tool workspace   # Test specific tool
    python tests/tdd_runner.py --unit            # Run unit tests only
    python tests/tdd_runner.py --no-tui          # CLI mode with progress
"""

import asyncio
import os
import sys
import time
import argparse
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

# Import TUI and OAuth components
from framework.auth_session import get_auth_broker, AuthSessionBroker
from framework.oauth_progress import OAuthProgressFlow
from fixtures import authenticated_client

try:
    from framework.tui import (
        AtomsTUIApp, 
        OAuthStatusWidget,
        ServerStatusWidget,
        HAS_TEXTUAL
    )
    from rich.console import Console
    from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn
    from rich.panel import Panel
    from rich.table import Table
    from rich.live import Live
    from rich.layout import Layout
    HAS_RICH = True
except ImportError:
    HAS_RICH = False
    HAS_TEXTUAL = False


class TDDTestRunner:
    """Test runner with session-scoped OAuth and TUI integration."""
    
    def __init__(self, use_tui: bool = True):
        self.use_tui = use_tui and HAS_TEXTUAL
        self.console = Console() if HAS_RICH else None
        self.auth_broker: Optional[AuthSessionBroker] = None
        self.oauth_complete = False
        self.test_results = []
        
    async def setup_oauth_session(self) -> bool:
        """Setup session-scoped OAuth authentication."""
        if self.console:
            self.console.print("\n[bold blue]🔐 Setting up Session-Scoped OAuth Authentication[/bold blue]")
        
        try:
            self.auth_broker = get_auth_broker()
            
            # Show OAuth progress
            with OAuthProgressFlow() as progress:
                progress.step("Checking cached credentials...")
                
                credentials = await self.auth_broker.get_authenticated_credentials(
                    provider="authkit",
                    force_refresh=False
                )
                
                if credentials.is_valid():
                    progress.complete("OAuth session ready - using cached credentials")
                    if self.console:
                        self.console.print(f"[green]✅ OAuth credentials cached until {credentials.expires_at}[/green]")
                else:
                    progress.step("Performing fresh OAuth authentication...")
                    credentials = await self.auth_broker.get_authenticated_credentials(
                        provider="authkit", 
                        force_refresh=True
                    )
                    progress.complete("OAuth authentication complete")
                    if self.console:
                        self.console.print(f"[green]✅ Fresh OAuth credentials acquired[/green]")
            
            self.oauth_complete = True
            return True
            
        except Exception as e:
            if self.console:
                self.console.print(f"[red]❌ OAuth setup failed: {e}[/red]")
            return False
    
    async def run_tests_with_tui(self, test_filter: Optional[str] = None):
        """Run tests with full TUI dashboard."""
        if not HAS_TEXTUAL:
            return await self.run_tests_cli(test_filter)
        
        # Create TUI app with OAuth integration
        app = TDDAtomsTUIApp(
            auth_broker=self.auth_broker,
            oauth_complete=self.oauth_complete,
            test_filter=test_filter
        )
        
        await app.run_async()
    
    async def run_tests_cli(self, test_filter: Optional[str] = None):
        """Run tests with CLI progress (fallback when TUI unavailable)."""
        if not self.oauth_complete:
            if self.console:
                self.console.print("[red]❌ OAuth not configured - cannot run tests[/red]")
            return False
        
        # Build pytest command
        cmd = ["python", "-m", "pytest"]
        
        if test_filter:
            if test_filter == "unit":
                cmd.extend(["tests/unit/", "-m", "unit"])
            elif test_filter == "integration":
                cmd.extend(["tests/integration/", "-m", "integration"])
            elif test_filter.startswith("tool:"):
                tool_name = test_filter.split(":", 1)[1]
                cmd.extend(["-k", tool_name])
            else:
                cmd.extend(["-k", test_filter])
        else:
            cmd.append("tests/")
        
        cmd.extend(["-v", "--tb=short"])
        
        if self.console:
            self.console.print(f"\n[bold green]🚀 Running Tests with Session OAuth[/bold green]")
            self.console.print(f"Command: [cyan]{' '.join(cmd)}[/cyan]\n")
        
        # Show live progress
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            TimeElapsedColumn(),
            console=self.console
        ) as progress:
            task = progress.add_task("Running tests...", total=None)
            
            # Run pytest
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
                cwd=Path(__file__).parent.parent
            )
            
            while True:
                line = await process.stdout.readline()
                if not line:
                    break
                
                line_str = line.decode().strip()
                if line_str:
                    progress.update(task, description=f"Running: {line_str[-60:]}")
                    if self.console and not progress.live.is_started:
                        self.console.print(line_str)
            
            await process.wait()
            progress.update(task, description="Tests complete")
        
        return process.returncode == 0
    
    async def run_specific_tool(self, tool_name: str):
        """Run tests for a specific tool."""
        if not self.oauth_complete:
            if self.console:
                self.console.print("[red]❌ OAuth required for tool testing[/red]")
            return False
        
        test_paths = [
            f"tests/unit/tools/test_{tool_name}_tool.py",
            f"tests/integration/test_{tool_name}_integration.py"
        ]
        
        existing_paths = [p for p in test_paths if Path(p).exists()]
        
        if not existing_paths:
            if self.console:
                self.console.print(f"[red]❌ No tests found for tool: {tool_name}[/red]")
            return False
        
        cmd = ["python", "-m", "pytest"] + existing_paths + ["-v"]
        
        if self.console:
            self.console.print(f"\n[bold green]🔧 Testing Tool: {tool_name}[/bold green]")
            self.console.print(f"Files: {', '.join(existing_paths)}\n")
        
        process = subprocess.run(cmd, cwd=Path(__file__).parent.parent)
        return process.returncode == 0


class TDDAtomsTUIApp:
    """TUI App with TDD and OAuth integration."""
    
    def __init__(self, auth_broker: AuthSessionBroker, oauth_complete: bool, test_filter: Optional[str] = None):
        self.auth_broker = auth_broker
        self.oauth_complete = oauth_complete
        self.test_filter = test_filter
        
        if HAS_TEXTUAL:
            from framework.tui import AtomsTUIApp
            self.app = AtomsTUIApp()
            # Integrate OAuth status
            self.app.oauth_complete = oauth_complete
            self.app.auth_broker = auth_broker
    
    async def run_async(self):
        """Run the TUI app."""
        if HAS_TEXTUAL and hasattr(self, 'app'):
            await self.app.run_async()
        else:
            print("TUI not available - falling back to CLI mode")


def main():
    """Main entry point for TDD test runner."""
    parser = argparse.ArgumentParser(description="TDD Test Runner with Session OAuth")
    parser.add_argument("--no-tui", action="store_true", help="Run in CLI mode (no TUI)")
    parser.add_argument("--tool", help="Test specific tool (e.g., workspace, entity)")
    parser.add_argument("--unit", action="store_true", help="Run unit tests only")
    parser.add_argument("--integration", action="store_true", help="Run integration tests only")
    parser.add_argument("--filter", help="Custom test filter")
    
    args = parser.parse_args()
    
    # Determine test filter
    test_filter = None
    if args.tool:
        test_filter = f"tool:{args.tool}"
    elif args.unit:
        test_filter = "unit"
    elif args.integration:
        test_filter = "integration"  
    elif args.filter:
        test_filter = args.filter
    
    # Create and run test runner
    runner = TDDTestRunner(use_tui=not args.no_tui)
    
    async def run():
        # Setup OAuth session first
        oauth_success = await runner.setup_oauth_session()
        if not oauth_success:
            return 1
        
        # Run tests
        if args.tool:
            success = await runner.run_specific_tool(args.tool)
        elif runner.use_tui:
            await runner.run_tests_with_tui(test_filter)
            success = True  # TUI handles its own results
        else:
            success = await runner.run_tests_cli(test_filter)
        
        return 0 if success else 1
    
    try:
        exit_code = asyncio.run(run())
        sys.exit(exit_code)
    except KeyboardInterrupt:
        print("\n🛑 Test run cancelled by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Test runner error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()