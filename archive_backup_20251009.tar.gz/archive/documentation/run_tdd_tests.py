#!/usr/bin/env python3
"""
Simple TDD Test Runner with Session OAuth Integration

This provides the same functionality as the complex TUI but in a simpler format.
All tests require OAuth and use session-scoped authentication.

Usage:
    python tests/run_tdd_tests.py                    # Interactive menu
    python tests/run_tdd_tests.py --all             # Run all tests
    python tests/run_tdd_tests.py --tool workspace  # Test specific tool
    python tests/run_tdd_tests.py --unit           # Unit tests only
"""

import asyncio
import argparse
import os
import sys
import subprocess
from pathlib import Path

_TESTS_DIR = Path(__file__).resolve().parent
_REPO_ROOT = _TESTS_DIR.parents[2]
_SHARED_QA_PATHS = [
    _REPO_ROOT / "clean" / "mcp-QA",
]
for _path in _SHARED_QA_PATHS:
    if _path.exists():
        if str(_path) not in sys.path:
            sys.path.insert(0, str(_path))

# Add parent to path
sys.path.insert(0, str(_TESTS_DIR.parent))

# Import from shared mcp-QA library
from mcp_qa.logging import LogConfig, configure_logging, get_logger
from mcp_qa.oauth import UnifiedCredentialBroker

try:
    from rich.console import Console
    from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn
    from rich.panel import Panel
    console = Console()
    HAS_RICH = True
except ImportError:
    HAS_RICH = False
    console = None


class SimpleTDDRunner:
    """Simple TDD runner with unified OAuth broker."""

    def __init__(self):
        self.broker = None
        self.client = None
        self.credentials = None
        self.logger = get_logger(__name__).bind(component="tdd_runner")

    async def setup_oauth(self):
        """Setup session-scoped OAuth using unified broker."""
        import os

        if console:
            console.print("\n[bold blue]🔐 Setting up Session-Scoped OAuth Authentication[/bold blue]")
        else:
            print("\n🔐 Setting up Session-Scoped OAuth Authentication")

        try:
            # Use shared mcp-QA UnifiedCredentialBroker
            self.broker = UnifiedCredentialBroker(
                mcp_endpoint=os.getenv("MCP_ENDPOINT", "https://mcp.atoms.tech/api/mcp"),
                provider=os.getenv("ATOMS_OAUTH_PROVIDER", "authkit")
            )

            # Get authenticated client and credentials
            self.client, self.credentials = await self.broker.get_authenticated_client()

            self.logger.info(
                "OAuth session established",
                email=self.credentials.email,
                provider=self.credentials.provider,
            )

            if console:
                console.print(f"[green]✅ Authenticated as: {self.credentials.email}[/green]")
            else:
                print(f"✅ Authenticated as: {self.credentials.email}")

            return True

        except Exception as e:
            error_msg = f"❌ OAuth setup failed: {e}"
            self.logger.error("OAuth setup failed", error=str(e))
            if console:
                console.print(f"[red]{error_msg}[/red]")
            else:
                print(error_msg)
            return False
    
    async def run_tests(self, test_args: list):
        """Run tests with session OAuth."""
        if not self.credentials:
            print("❌ OAuth not configured - cannot run tests")
            return False
        
        # Use the same Python that's running this script (handles .venv properly)
        import sys
        python_executable = sys.executable
        cmd = [python_executable, "-m", "pytest"] + test_args + [
            "-v", "--tb=short", "--asyncio-mode=auto"
        ]
        
        if console:
            console.print(f"\n[bold green]🚀 Running Tests with Session OAuth[/bold green]")
            console.print(f"Command: [cyan]{' '.join(cmd)}[/cyan]\n")
        else:
            print(f"\n🚀 Running Tests with Session OAuth")
            print(f"Command: {' '.join(cmd)}\n")

        self.logger.info("Executing pytest command", command=cmd)
        
        # Run pytest
        process = subprocess.run(cmd, cwd=Path(__file__).parent.parent)
        if process.returncode != 0:
            self.logger.error("Pytest run failed", returncode=process.returncode)
        else:
            self.logger.info("Pytest run succeeded", returncode=process.returncode)
        return process.returncode == 0
    
    async def interactive_menu(self):
        """Show interactive test menu."""
        while True:
            if console:
                console.clear()
                console.print(Panel(
                    f"[bold green]🧪 TDD Test Runner with Session OAuth[/bold green]\n\n"
                    f"OAuth Status: [green]✅ Ready[/green]\n"
                    f"Provider: [cyan]{self.credentials.provider}[/cyan]\n"
                    f"Expires: [yellow]{self.credentials.expires_at}[/yellow]",
                    title="Authentication Status",
                    border_style="green"
                ))
                console.print("\n[bold cyan]Test Options:[/bold cyan]")
                console.print("[1] Run all tests")
                console.print("[2] Run unit tests only") 
                console.print("[3] Run integration tests only")
                console.print("[4] Test specific tool")
                console.print("[5] Run custom filter")
                console.print("[q] Quit")
            else:
                print("\n" + "="*50)
                print("🧪 TDD Test Runner with Session OAuth")
                print("="*50)
                print(f"OAuth Status: ✅ Ready ({self.credentials.provider})")
                print(f"Expires: {self.credentials.expires_at}")
                print("\nTest Options:")
                print("[1] Run all tests")
                print("[2] Run unit tests only")
                print("[3] Run integration tests only") 
                print("[4] Test specific tool")
                print("[5] Run custom filter")
                print("[q] Quit")
            
            choice = input("\n👉 Choose option: ").strip().lower()
            
            if choice == 'q':
                break
            elif choice == '1':
                await self.run_tests(["tests/"])
            elif choice == '2':
                await self.run_tests(["tests/unit/", "-m", "unit"])
            elif choice == '3':
                await self.run_tests(["tests/integration/", "-m", "integration"])
            elif choice == '4':
                tool_name = input("\n🔧 Enter tool name (e.g., workspace, entity): ").strip()
                if tool_name:
                    await self.test_specific_tool(tool_name)
            elif choice == '5':
                filter_expr = input("\n🔍 Enter test filter (pytest -k expression): ").strip()
                if filter_expr:
                    await self.run_tests(["tests/", "-k", filter_expr])
            else:
                if console:
                    console.print("[red]Invalid option. Press Enter to continue.[/red]")
                else:
                    print("Invalid option. Press Enter to continue.")
                input()
    
    async def test_specific_tool(self, tool_name: str):
        """Test a specific tool."""
        test_paths = [
            f"tests/unit/tools/test_{tool_name}_tool.py",
            f"tests/integration/test_{tool_name}_integration.py"
        ]
        
        existing_paths = [p for p in test_paths if Path(p).exists()]
        
        if not existing_paths:
            error_msg = f"❌ No tests found for tool: {tool_name}"
            self.logger.warning("No tests found for tool", tool=tool_name)
            if console:
                console.print(f"[red]{error_msg}[/red]")
            else:
                print(error_msg)
            input("Press Enter to continue...")
            return
        
        if console:
            console.print(f"\n[bold green]🔧 Testing Tool: {tool_name}[/bold green]")
            console.print(f"Files: {', '.join(existing_paths)}")
        else:
            print(f"\n🔧 Testing Tool: {tool_name}")
            print(f"Files: {', '.join(existing_paths)}")
        
        self.logger.info("Running tests for specific tool", tool=tool_name, files=existing_paths)
        await self.run_tests(existing_paths)
        input("\nPress Enter to continue...")


async def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(description="TDD Test Runner with Session OAuth")
    parser.add_argument("--all", action="store_true", help="Run all tests")
    parser.add_argument("--unit", action="store_true", help="Run unit tests only")
    parser.add_argument("--integration", action="store_true", help="Run integration tests only")
    parser.add_argument("--tool", help="Test specific tool")
    parser.add_argument("--filter", help="Custom test filter")
    parser.add_argument("--log-level", default=os.getenv("MCP_QA_LOG_LEVEL", "INFO"), help="Log level")
    parser.add_argument("--log-format", choices=["plain", "json"], default=os.getenv("MCP_QA_LOG_FORMAT", "plain"))
    parser.add_argument("--log-no-color", action="store_true", help="Disable colorized logs")
    parser.add_argument("--log-no-timestamp", action="store_true", help="Disable timestamps in logs")
    parser.add_argument("--log-json-indent", type=int, help="Indentation for JSON logs")
    
    args = parser.parse_args()

    log_config = LogConfig(
        level=args.log_level.upper(),
        fmt="json" if args.log_format == "json" else "plain",
        color=not args.log_no_color,
        timestamp=not args.log_no_timestamp,
        json_indent=args.log_json_indent,
    )
    configure_logging(log_config, force=True)
    logger = get_logger(__name__).bind(component="tdd_runner_main")
    logger.debug("Logging configured", config=log_config.__dict__)
    
    runner = SimpleTDDRunner()
    
    # Setup OAuth session
    oauth_success = await runner.setup_oauth()
    if not oauth_success:
        return 1
    
    # Run tests based on arguments
    if args.all:
        success = await runner.run_tests(["tests/"])
    elif args.unit:
        success = await runner.run_tests(["tests/unit/", "-m", "unit"])
    elif args.integration:
        success = await runner.run_tests(["tests/integration/", "-m", "integration"])
    elif args.tool:
        await runner.test_specific_tool(args.tool)
        success = True
    elif args.filter:
        success = await runner.run_tests(["tests/", "-k", args.filter])
    else:
        # Interactive mode
        await runner.interactive_menu()
        success = True
    
    return 0 if success else 1


if __name__ == "__main__":
    try:
        exit_code = asyncio.run(main())
        sys.exit(exit_code)
    except KeyboardInterrupt:
        get_logger(__name__).warning("Test run cancelled by user")
        print("\n🛑 Test run cancelled by user")
        sys.exit(1)
    except Exception as e:
        get_logger(__name__).exception("Test runner error", error=str(e))
        print(f"\n❌ Test runner error: {e}")
        sys.exit(1)