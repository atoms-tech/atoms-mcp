#!/usr/bin/env python3
"""
Script to clean up legacy Supabase authentication references and update them to use AuthKit OAuth only.
"""

import os
import re
from pathlib import Path

def clean_supabase_references():
    """Remove Supabase authentication references from test files."""
    
    test_dir = Path("tests")
    files_to_clean = [
        "test_comprehensive_new.py",
        "test_entity_tool_comprehensive.py", 
        "test_relationship_tool.py",
        "framework/oauth_session.py",
        "framework/health_checks.py",
        "framework/oauth_cache.py",
        "test_all_workflows_live.py",
        "test_error_handling.py",
        "test_end_to_end.py", 
        "test_performance.py",
        "test_query_tool_comprehensive.py",
        "test_integration_workflows.py",
        "generate_query_test_report.py"
    ]
    
    # Patterns to remove/replace
    patterns_to_remove = [
        r'from supabase import create_client',
        r'import.*supabase.*',
        r'NEXT_PUBLIC_SUPABASE_URL.*',
        r'NEXT_PUBLIC_SUPABASE_ANON_KEY.*',
        r'shared_supabase_jwt.*',
        r'create_client\([^)]+\)',
        r'\.auth\.sign_in_with_password.*',
        r'supabase_jwt.*'
    ]
    
    # Replacement patterns
    replacements = [
        (r'@pytest\.fixture.*\ndef supabase_jwt.*?return.*', 
         '# Supabase JWT fixture removed - using AuthKit OAuth only'),
        (r'@pytest\.fixture.*\ndef _supabase_env.*?return.*',
         '# Supabase environment fixture removed - using AuthKit OAuth only'),
        (r'supabase_jwt', 'authkit_session'),
        (r'"Authorization": f"Bearer {supabase_jwt}"',
         '"Content-Type": "application/json"')
    ]
    
    cleaned_files = []
    
    for file_path in files_to_clean:
        full_path = test_dir / file_path
        if not full_path.exists():
            continue
            
        print(f"Cleaning {full_path}...")
        
        try:
            with open(full_path, 'r') as f:
                content = f.read()
            
            original_content = content
            
            # Apply replacements
            for pattern, replacement in replacements:
                content = re.sub(pattern, replacement, content, flags=re.MULTILINE | re.DOTALL)
            
            # Remove specific patterns
            for pattern in patterns_to_remove:
                content = re.sub(pattern, '', content)
            
            # Clean up empty lines
            content = re.sub(r'\n\s*\n\s*\n', '\n\n', content)
            
            if content != original_content:
                with open(full_path, 'w') as f:
                    f.write(content)
                cleaned_files.append(str(full_path))
                print(f"  ✅ Cleaned {full_path}")
            else:
                print(f"  ⏭️  No changes needed for {full_path}")
                
        except Exception as e:
            print(f"  ❌ Error cleaning {full_path}: {e}")
    
    print(f"\n✅ Cleaned {len(cleaned_files)} files:")
    for file in cleaned_files:
        print(f"  - {file}")
    
    print(f"\n🎯 All Supabase authentication references have been removed.")
    print(f"   The system now uses AuthKit OAuth exclusively.")

if __name__ == "__main__":
    clean_supabase_references()