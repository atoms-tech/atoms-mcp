#!/bin/bash
# Install pheno-sdk kits required for testing

set -e

echo "🧪 Installing pheno-sdk kits for test suite..."
echo ""

cd ../../pheno-sdk

kits=("event-kit" "workflow-kit" "authkit-client")

for kit in "${kits[@]}"; do
    echo "📦 Installing $kit for testing..."
    cd "$kit"
    pip install -e .
    cd ..
    echo "✅ $kit installed"
    echo ""
done

echo "🎉 All test dependencies installed!"
echo ""
echo "Now you can run:"
echo "  cd ../../atoms_mcp-old"
echo "  pytest tests/"
