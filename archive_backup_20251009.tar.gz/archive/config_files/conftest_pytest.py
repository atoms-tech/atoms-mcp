"""
Pytest Configuration for Atoms MCP Tests

Uses fast HTTP transport and pytest-native features:
- Leverages pytest-xdist for parallel execution (pytest -n auto)
- Uses pytest cache for result caching  
- 20x faster than STDIO transport
- Native pytest fixtures and markers
"""

import os
import pytest
import pytest_asyncio

# Import mcp-QA pytest adapter
from mcp_qa.testing import (
    HTTPMCPClient,
    SharedSessionManager,
    get_session_manager,
    mcp_client,
    mcp_tool_caller,
    mcp_server_url,
    mcp_auth_token,
)


# ============================================================================
# Session-scoped fixtures (created once per test session)
# ============================================================================

@pytest.fixture(scope="session")
def event_loop_policy():
    """Use asyncio event loop policy."""
    import asyncio
    return asyncio.get_event_loop_policy()


@pytest.fixture(scope="session")
def mcp_server_url_override() -> str:
    """Override MCP server URL for atoms."""
    return os.getenv("MCP_ENDPOINT", "https://mcp.atoms.tech/api/mcp")


@pytest_asyncio.fixture(scope="session")
async def shared_session():
    """
    Get shared OAuth session for all tests.
    
    Uses SharedSessionManager for:
    - Single authentication per test run
    - Token caching between runs
    - Automatic cleanup
    """
    session_manager = get_session_manager(
        provider=os.getenv("ATOMS_OAUTH_PROVIDER", "authkit")
    )
    
    endpoint = os.getenv("MCP_ENDPOINT", "https://mcp.atoms.tech/api/mcp")
    
    # Get authenticated session (cached if available)
    client, credentials = await session_manager.get_session(endpoint)
    
    yield (client, credentials)
    
    # Cleanup handled by pytest_sessionfinish in session_manager


@pytest_asyncio.fixture(scope="session")
async def atoms_mcp_client(mcp_server_url_override, shared_session):
    """
    HTTP-based MCP client for Atoms server.
    
    20x faster than STDIO transport.
    Shared across all tests in the session.
    Uses shared OAuth session for authentication.
    """
    client, credentials = shared_session
    
    # Return the FastMCP client directly (it's already authenticated)
    yield client
    
    # Client cleanup handled by shared session manager


# ============================================================================
# Function-scoped fixtures (created for each test)
# ============================================================================

@pytest_asyncio.fixture
async def atoms_tool_caller(atoms_mcp_client):
    """
    Convenience fixture for calling Atoms MCP tools.
    
    Usage:
        async def test_workspace(atoms_tool_caller):
            result = await atoms_tool_caller("workspace_tool", operation="list_workspaces")
            assert result["success"]
    """
    import json
    
    async def call_tool(tool_name: str, **arguments):
        """Call tool and parse response."""
        result = await atoms_mcp_client.call_tool(tool_name, arguments)
        
        # Parse MCP response format
        if isinstance(result, dict) and "content" in result:
            content = result["content"]
            if content and isinstance(content, list):
                text = content[0].get("text", "")
                return json.loads(text) if text else {}
        
        return result
    
    return call_tool


# ============================================================================
# Pytest configuration
# ============================================================================

def pytest_configure(config):
    """Register custom markers."""
    config.addinivalue_line(
        "markers",
        "atoms_tool(name): mark test as requiring specific Atoms tool"
    )
    config.addinivalue_line(
        "markers",
        "category(name): test category (core, entity, query, etc.)"
    )
    config.addinivalue_line(
        "markers",
        "priority(level): test priority (1=highest, 10=lowest)"
    )


def pytest_collection_modifyitems(config, items):
    """Auto-mark tests based on file location."""
    for item in items:
        # Add category marker based on test name prefix
        if "workspace" in item.nodeid:
            item.add_marker(pytest.mark.category("core"))
        elif "entity" in item.nodeid:
            item.add_marker(pytest.mark.category("entity"))
        elif "query" in item.nodeid:
            item.add_marker(pytest.mark.category("query"))
        elif "relationship" in item.nodeid:
            item.add_marker(pytest.mark.category("relationship"))
        elif "workflow" in item.nodeid:
            item.add_marker(pytest.mark.category("workflow"))


# ============================================================================
# Usage Examples
# ============================================================================

"""
# Run tests sequentially:
pytest tests/ -v

# Run tests in parallel (auto-detect cores):
pytest tests/ -n auto

# Run tests in parallel (8 workers):
pytest tests/ -n 8

# Run specific category:
pytest tests/ -m "category('core')"

# Run with cache (only rerun failures):
pytest tests/ --lf

# Clear cache and run all:
pytest tests/ --cache-clear

# Show slowest tests:
pytest tests/ --durations=10

# Generate HTML report:
pytest tests/ --html=report.html --self-contained-html
"""
