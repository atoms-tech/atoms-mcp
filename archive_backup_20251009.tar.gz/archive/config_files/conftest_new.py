"""New pytest configuration with session-scoped OAuth and TDD-friendly setup.

This replaces the existing conftest.py with:
- Session-scoped OAuth authentication (authenticate once, use everywhere)
- Direct HTTP tool calls (no MCP client overhead)
- Parallel testing support
- Granular tool-specific fixtures
- Multi-provider OAuth support
"""

import os
import sys
import pytest
import pytest_asyncio
from utils.logging_setup import get_logger
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

# Load .env files
from dotenv import load_dotenv
load_dotenv()
load_dotenv(".env.local", override=True)

# Import our fixtures so they're available to all tests
from .fixtures.auth import *
from .fixtures.tools import *
from .fixtures.data import *
from .fixtures.providers import *

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = get_logger(__name__)


def pytest_configure(config):
    """Register custom markers and configure pytest."""
    # Existing markers
    config.addinivalue_line(
        "markers", "integration: marks tests as integration tests (require server running)"
    )
    config.addinivalue_line(
        "markers", "http: marks tests that call MCP via HTTP"
    )
    
    # New TDD markers
    config.addinivalue_line(
        "markers", "unit: marks tests as unit tests (fast, no external dependencies)"
    )
    config.addinivalue_line(
        "markers", "e2e: marks tests as end-to-end tests (full workflows)"
    )
    config.addinivalue_line(
        "markers", "auth: marks tests that require OAuth authentication"
    )
    config.addinivalue_line(
        "markers", "tool: marks tests for specific MCP tools"
    )
    config.addinivalue_line(
        "markers", "provider: marks tests for specific OAuth providers"
    )
    config.addinivalue_line(
        "markers", "parallel: marks tests that can run in parallel"
    )
    config.addinivalue_line(
        "markers", "slow: marks tests that take longer than 5 seconds"
    )


def pytest_collection_modifyitems(config, items):
    """Automatically mark tests based on their location and content."""
    for item in items:
        # Auto-mark based on test file location
        if "unit/" in str(item.fspath):
            item.add_marker(pytest.mark.unit)
        elif "integration/" in str(item.fspath):
            item.add_marker(pytest.mark.integration)
            item.add_marker(pytest.mark.auth)
        elif "e2e/" in str(item.fspath):
            item.add_marker(pytest.mark.e2e)
            item.add_marker(pytest.mark.auth)
            item.add_marker(pytest.mark.slow)
        
        # Auto-mark tool-specific tests
        if "workspace" in item.name.lower():
            item.add_marker(pytest.mark.tool)
        elif "entity" in item.name.lower():
            item.add_marker(pytest.mark.tool)
        elif any(tool in item.name.lower() for tool in ["relationship", "workflow", "query"]):
            item.add_marker(pytest.mark.tool)
        
        # Auto-mark OAuth tests
        if any(fixture in item.fixturenames for fixture in ["authenticated_client", "github_client", "google_client"]):
            item.add_marker(pytest.mark.auth)


def pytest_sessionstart(session):
    """Session startup - show OAuth status."""
    logger.info("🚀 Starting TDD test session with session-scoped OAuth")
    logger.info("🔐 OAuth will be performed ONCE and reused for all tests")


def pytest_sessionfinish(session, exitstatus):
    """Session cleanup."""
    logger.info("✅ TDD test session complete")
    if exitstatus == 0:
        logger.info("🎉 All tests passed!")
    else:
        logger.info(f"❌ Tests completed with exit status: {exitstatus}")


# pytest-xdist support for parallel testing
def pytest_configure_node(node):
    """Configure worker nodes for parallel testing."""
    node.workerinput["worker_id"] = node.workerinput.get("workerid", "master")


@pytest.fixture(scope="session")
def worker_id(request):
    """Get the worker ID for parallel testing."""
    if hasattr(request.config, "workerinput"):
        return request.config.workerinput.get("worker_id", "master")
    return "master"


# Health check for MCP server
@pytest.fixture(scope="session")
def check_mcp_server():
    """Check if MCP server is accessible."""
    import httpx
    
    endpoint = os.getenv("MCP_ENDPOINT", "https://mcp.atoms.tech")
    health_url = endpoint.replace("/api/mcp", "/health")
    
    try:
        response = httpx.get(health_url, timeout=10.0)
        if response.status_code == 200:
            logger.info(f"✅ MCP server is accessible at {endpoint}")
            return True
    except Exception as e:
        logger.warning(f"⚠️ MCP server check failed: {e}")
    
    pytest.skip(f"MCP server not accessible at {endpoint}")


# Environment validation
@pytest.fixture(scope="session", autouse=True)
def validate_test_environment():
    """Validate that required environment variables are set."""
    required_env = [
        "NEXT_PUBLIC_SUPABASE_URL",
        "NEXT_PUBLIC_SUPABASE_ANON_KEY"
    ]
    
    missing = [var for var in required_env if not os.getenv(var)]
    if missing:
        pytest.skip(f"Missing required environment variables: {missing}")
    
    logger.info("✅ Test environment validation passed")


# Performance monitoring for session
@pytest.fixture(scope="session")
def session_performance():
    """Track session-level performance metrics."""
    import time
    
    class SessionPerformance:
        def __init__(self):
            self.start_time = time.time()
            self.oauth_time = None
            self.test_times = []
        
        def mark_oauth_complete(self):
            self.oauth_time = time.time() - self.start_time
            logger.info(f"🔐 OAuth completed in {self.oauth_time:.2f}s")
        
        def add_test_time(self, test_time: float):
            self.test_times.append(test_time)
        
        def get_summary(self):
            total_time = time.time() - self.start_time
            avg_test_time = sum(self.test_times) / len(self.test_times) if self.test_times else 0
            return {
                "total_session_time": total_time,
                "oauth_time": self.oauth_time,
                "total_tests": len(self.test_times),
                "average_test_time": avg_test_time
            }
    
    return SessionPerformance()


# Cleanup hook
@pytest.fixture(scope="session", autouse=True)
def session_cleanup():
    """Session-level cleanup."""
    yield
    
    # Could add cleanup logic here
    # e.g., clean up test data, close connections, etc.
    logger.info("🧹 Session cleanup completed")