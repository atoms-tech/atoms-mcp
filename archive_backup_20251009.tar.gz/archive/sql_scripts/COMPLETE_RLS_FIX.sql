-- ============================================================================
-- COMPLETE RLS & TRIGGER FIX - All Tables
-- ============================================================================
-- Fixes all identified RLS policy and trigger issues across related entities
-- Run in Supabase Dashboard → SQL Editor

-- ============================================================================
-- FIX 1: organization_members RLS Policies
-- ============================================================================
-- Issue: ALL policies with null USING or WITH CHECK clauses
-- Security risk: Missing validation allows unrestricted access

DROP POLICY IF EXISTS "Users can create organization members" ON organization_members;
DROP POLICY IF EXISTS "Users can delete organization members" ON organization_members;
DROP POLICY IF EXISTS "Users can update organization members" ON organization_members;
DROP POLICY IF EXISTS "Users can view org members" ON organization_members;

-- Proper SELECT policy
CREATE POLICY "Users can view org members"
ON organization_members FOR SELECT
USING (organization_id IN (SELECT get_user_organization_ids(auth.uid())));

-- Proper INSERT policy (allows auto_add_org_owner trigger + user creating themselves)
CREATE POLICY "Users can create organization members"
ON organization_members FOR INSERT
WITH CHECK (
    user_id = auth.uid()  -- User adding themselves
    OR NOT EXISTS (  -- Or this is first member (auto-add trigger)
        SELECT 1 FROM organization_members om
        WHERE om.organization_id = NEW.organization_id
    )
);

-- Proper UPDATE policy
CREATE POLICY "Users can update organization members"
ON organization_members FOR UPDATE
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- Proper DELETE policy
CREATE POLICY "Users can delete organization members"
ON organization_members FOR DELETE
USING (user_id = auth.uid());

-- ============================================================================
-- FIX 2: project_members RLS Policy
-- ============================================================================
-- Issue: Policy blocks auto_add_project_owner trigger

DROP POLICY IF EXISTS "Project owners and admins can manage members" ON project_members;

CREATE POLICY "Project owners and admins can manage members" ON project_members
FOR ALL
USING (is_project_owner_or_admin(project_id, auth.uid()))
WITH CHECK (
    is_project_owner_or_admin(project_id, auth.uid())
    OR NOT EXISTS (  -- Allow first member insert
        SELECT 1 FROM project_members pm
        WHERE pm.project_id = NEW.project_id
    )
);

-- ============================================================================
-- FIX 3: trace_links RLS Policy
-- ============================================================================
-- Issue: ALL policy with no WITH CHECK clause blocks INSERT/UPDATE/DELETE

DROP POLICY IF EXISTS "Users can view trace links they have access to" ON trace_links;

CREATE POLICY "Users can manage trace links they have access to"
ON trace_links FOR ALL
USING (
    EXISTS (
        SELECT 1
        FROM project_members pm
        JOIN documents d ON d.project_id = pm.project_id
        WHERE (
            (trace_links.source_type = 'document'::entity_type AND trace_links.source_id = d.id)
            OR (trace_links.target_type = 'document'::entity_type AND trace_links.target_id = d.id)
            OR EXISTS (
                SELECT 1 FROM requirements r
                WHERE (
                    (trace_links.source_type = 'requirement'::entity_type AND trace_links.source_id = r.id)
                    OR (trace_links.target_type = 'requirement'::entity_type AND trace_links.target_id = r.id)
                )
                AND r.document_id = d.id
            )
        )
        AND pm.user_id = auth.uid()
        AND pm.status = 'active'::user_status
    )
)
WITH CHECK (
    EXISTS (
        SELECT 1
        FROM project_members pm
        JOIN documents d ON d.project_id = pm.project_id
        WHERE (
            (source_type = 'document'::entity_type AND source_id = d.id)
            OR (target_type = 'document'::entity_type AND target_id = d.id)
            OR EXISTS (
                SELECT 1 FROM requirements r
                WHERE (
                    (source_type = 'requirement'::entity_type AND source_id = r.id)
                    OR (target_type = 'requirement'::entity_type AND target_id = r.id)
                )
                AND r.document_id = d.id
            )
        )
        AND pm.user_id = auth.uid()
        AND pm.status = 'active'::user_status
    )
);

-- ============================================================================
-- FIX 4: handle_updated_by Function (for backfill operations)
-- ============================================================================
-- Already fixed - has proper fallback logic

-- ============================================================================
-- FIX 5: test_req Table RLS Policies
-- ============================================================================
-- Issue: NO policies - all access blocked

DROP POLICY IF EXISTS "Org members can view test_req" ON test_req;
DROP POLICY IF EXISTS "Org members can create test_req" ON test_req;
DROP POLICY IF EXISTS "Org members can update test_req" ON test_req;
DROP POLICY IF EXISTS "Org members can delete test_req" ON test_req;

CREATE POLICY "Users can view tests" ON test_req FOR SELECT
USING (
    project_id IN (
        SELECT p.id FROM projects p
        WHERE p.organization_id IN (
            SELECT organization_id FROM organization_members
            WHERE user_id = auth.uid() AND status = 'active'
        )
        OR p.created_by = auth.uid()
    )
);

CREATE POLICY "Users can create tests" ON test_req FOR INSERT
WITH CHECK (
    project_id IN (
        SELECT p.id FROM projects p
        WHERE p.organization_id IN (
            SELECT organization_id FROM organization_members
            WHERE user_id = auth.uid() AND status = 'active'
        )
        OR p.created_by = auth.uid()
    )
);

CREATE POLICY "Users can update tests" ON test_req FOR UPDATE
USING (created_by = auth.uid());

CREATE POLICY "Users can delete tests" ON test_req FOR DELETE
USING (created_by = auth.uid());

-- ============================================================================
-- VERIFICATION
-- ============================================================================

-- Count policies by table
SELECT
    tablename,
    COUNT(*) as policy_count,
    COUNT(CASE WHEN with_check IS NOT NULL THEN 1 END) as with_with_check,
    COUNT(CASE WHEN qual IS NOT NULL THEN 1 END) as with_using
FROM pg_policies
WHERE tablename IN ('organization_members', 'project_members', 'trace_links', 'test_req')
GROUP BY tablename
ORDER BY tablename;
