-- ============================================
-- RLS POLICIES AUDIT SCRIPT
-- Complete audit of all Row-Level Security policies
-- ============================================

-- ============================================
-- 1. RLS ENABLED STATUS
-- ============================================
SELECT
    '=== TABLES WITH RLS ENABLED ===' as section;

SELECT
    schemaname,
    tablename,
    CASE rowsecurity
        WHEN true THEN '✅ RLS ENABLED'
        ELSE '❌ RLS DISABLED'
    END as rls_status,
    CASE rowsecurity
        WHEN true THEN 'Policies enforced'
        ELSE 'NO SECURITY - All access allowed'
    END as impact
FROM pg_tables
WHERE schemaname = 'public'
AND tablename IN (
    'organizations',
    'projects',
    'documents',
    'requirements',
    'organization_members',
    'project_members',
    'profiles',
    'test_req',
    'trace_links',
    'assignments'
)
ORDER BY rowsecurity DESC, tablename;

-- ============================================
-- 2. ALL RLS POLICIES BY TABLE
-- ============================================
SELECT
    '=== ALL RLS POLICIES ===' as section;

SELECT
    tablename,
    policyname,
    CASE cmd
        WHEN 'SELECT' THEN '📖 SELECT'
        WHEN 'INSERT' THEN '➕ INSERT'
        WHEN 'UPDATE' THEN '✏️  UPDATE'
        WHEN 'DELETE' THEN '🗑️  DELETE'
        WHEN 'ALL' THEN '🔓 ALL OPS'
        ELSE cmd
    END as operation,
    CASE permissive
        WHEN 'PERMISSIVE' THEN '✅ Permissive (OR logic)'
        ELSE '⚠️  Restrictive (AND logic)'
    END as policy_type,
    roles,
    SUBSTRING(qual::text, 1, 100) as using_clause,
    SUBSTRING(with_check::text, 1, 100) as with_check_clause
FROM pg_policies
WHERE schemaname = 'public'
ORDER BY
    tablename,
    CASE cmd
        WHEN 'SELECT' THEN 1
        WHEN 'INSERT' THEN 2
        WHEN 'UPDATE' THEN 3
        WHEN 'DELETE' THEN 4
        ELSE 5
    END,
    policyname;

-- ============================================
-- 3. CRITICAL TABLES - DETAILED POLICY ANALYSIS
-- ============================================

-- ORGANIZATIONS TABLE
SELECT
    '=== ORGANIZATIONS TABLE POLICIES ===' as section;

SELECT
    policyname,
    cmd as operation,
    roles,
    CASE
        WHEN qual IS NOT NULL THEN 'USING: ' || SUBSTRING(qual::text, 1, 200)
        ELSE 'No USING clause'
    END as using_clause,
    CASE
        WHEN with_check IS NOT NULL THEN 'WITH CHECK: ' || SUBSTRING(with_check::text, 1, 200)
        ELSE 'No WITH CHECK clause'
    END as with_check_clause
FROM pg_policies
WHERE tablename = 'organizations'
ORDER BY cmd;

-- PROJECTS TABLE
SELECT
    '=== PROJECTS TABLE POLICIES ===' as section;

SELECT
    policyname,
    cmd as operation,
    roles,
    CASE
        WHEN qual IS NOT NULL THEN 'USING: ' || SUBSTRING(qual::text, 1, 200)
        ELSE 'No USING clause'
    END as using_clause,
    CASE
        WHEN with_check IS NOT NULL THEN 'WITH CHECK: ' || SUBSTRING(with_check::text, 1, 200)
        ELSE 'No WITH CHECK clause'
    END as with_check_clause
FROM pg_policies
WHERE tablename = 'projects'
ORDER BY cmd;

-- ORGANIZATION_MEMBERS TABLE
SELECT
    '=== ORGANIZATION_MEMBERS TABLE POLICIES ===' as section;

SELECT
    policyname,
    cmd as operation,
    roles,
    CASE
        WHEN qual IS NOT NULL THEN 'USING: ' || SUBSTRING(qual::text, 1, 200)
        ELSE 'No USING clause'
    END as using_clause,
    CASE
        WHEN with_check IS NOT NULL THEN 'WITH CHECK: ' || SUBSTRING(with_check::text, 1, 200)
        ELSE 'No WITH CHECK clause'
    END as with_check_clause
FROM pg_policies
WHERE tablename = 'organization_members'
ORDER BY cmd;

-- DOCUMENTS TABLE
SELECT
    '=== DOCUMENTS TABLE POLICIES ===' as section;

SELECT
    policyname,
    cmd as operation,
    roles,
    CASE
        WHEN qual IS NOT NULL THEN 'USING: ' || SUBSTRING(qual::text, 1, 200)
        ELSE 'No USING clause'
    END as using_clause,
    CASE
        WHEN with_check IS NOT NULL THEN 'WITH CHECK: ' || SUBSTRING(with_check::text, 1, 200)
        ELSE 'No WITH CHECK clause'
    END as with_check_clause
FROM pg_policies
WHERE tablename = 'documents'
ORDER BY cmd;

-- ============================================
-- 4. POLICY GAPS (Missing Policies)
-- ============================================
SELECT
    '=== POLICY GAPS (Tables with RLS but missing policies) ===' as section;

WITH table_operations AS (
    SELECT tablename, 'SELECT' as op FROM pg_tables WHERE schemaname = 'public' AND rowsecurity = true
    UNION ALL
    SELECT tablename, 'INSERT' FROM pg_tables WHERE schemaname = 'public' AND rowsecurity = true
    UNION ALL
    SELECT tablename, 'UPDATE' FROM pg_tables WHERE schemaname = 'public' AND rowsecurity = true
    UNION ALL
    SELECT tablename, 'DELETE' FROM pg_tables WHERE schemaname = 'public' AND rowsecurity = true
),
existing_policies AS (
    SELECT tablename, cmd as op FROM pg_policies WHERE schemaname = 'public'
    UNION
    SELECT tablename, 'SELECT' FROM pg_policies WHERE cmd = 'ALL' AND schemaname = 'public'
    UNION
    SELECT tablename, 'INSERT' FROM pg_policies WHERE cmd = 'ALL' AND schemaname = 'public'
    UNION
    SELECT tablename, 'UPDATE' FROM pg_policies WHERE cmd = 'ALL' AND schemaname = 'public'
    UNION
    SELECT tablename, 'DELETE' FROM pg_policies WHERE cmd = 'ALL' AND schemaname = 'public'
)
SELECT
    to.tablename,
    to.op as missing_operation,
    '❌ No policy defined - will DENY ALL by default!' as impact
FROM table_operations to
WHERE NOT EXISTS (
    SELECT 1 FROM existing_policies ep
    WHERE ep.tablename = to.tablename
    AND ep.op = to.op
)
AND to.tablename IN (
    'organizations', 'projects', 'documents', 'requirements',
    'organization_members', 'project_members'
)
ORDER BY to.tablename, to.op;

-- ============================================
-- 5. POLICY RESTRICTIVENESS ANALYSIS
-- ============================================
SELECT
    '=== POLICY RESTRICTIVENESS ANALYSIS ===' as section;

SELECT
    tablename,
    cmd as operation,
    COUNT(*) as policy_count,
    CASE
        WHEN COUNT(*) = 0 THEN '❌ DENY ALL (no policies)'
        WHEN COUNT(*) = 1 THEN '⚠️  Single policy (might be restrictive)'
        WHEN COUNT(*) > 1 THEN '✅ Multiple policies (more flexible)'
    END as flexibility,
    string_agg(policyname, ', ') as policy_names
FROM pg_policies
WHERE tablename IN ('organizations', 'projects', 'documents', 'organization_members')
AND schemaname = 'public'
GROUP BY tablename, cmd
ORDER BY tablename, cmd;

-- ============================================
-- 6. ROLE-BASED RESTRICTIONS
-- ============================================
SELECT
    '=== POLICIES THAT CHECK USER ROLE ===' as section;

SELECT
    tablename,
    policyname,
    cmd as operation,
    CASE
        WHEN qual::text ILIKE '%role%owner%' OR with_check::text ILIKE '%role%owner%'
            THEN '🔒 REQUIRES OWNER ROLE'
        WHEN qual::text ILIKE '%role%admin%' OR with_check::text ILIKE '%role%admin%'
            THEN '🔒 REQUIRES ADMIN ROLE'
        WHEN qual::text ILIKE '%role%' OR with_check::text ILIKE '%role%'
            THEN '🔒 CHECKS SOME ROLE'
        ELSE '✅ No role restriction'
    END as role_restriction,
    SUBSTRING(
        COALESCE(qual::text, '') || ' ' || COALESCE(with_check::text, ''),
        1, 150
    ) as policy_excerpt
FROM pg_policies
WHERE tablename IN ('organizations', 'projects', 'documents', 'organization_members', 'project_members')
AND (
    qual::text ILIKE '%role%'
    OR with_check::text ILIKE '%role%'
)
ORDER BY
    CASE
        WHEN qual::text ILIKE '%owner%' OR with_check::text ILIKE '%owner%' THEN 1
        WHEN qual::text ILIKE '%admin%' OR with_check::text ILIKE '%admin%' THEN 2
        ELSE 3
    END,
    tablename;

-- ============================================
-- 7. TEST SPECIFIC OPERATIONS
-- ============================================
SELECT
    '=== CAN USER CREATE PROJECT IN PHENOTYPE ORG? ===' as section;

-- Check if user is member
SELECT
    EXISTS (
        SELECT 1
        FROM organization_members om
        WHERE om.organization_id = '98861958-7438-4950-a1db-b3923561a6e2'
        AND om.user_id = :'TEST_USER_ID'
        AND om.status = 'active'
    ) as is_member,
    (
        SELECT om.role
        FROM organization_members om
        WHERE om.organization_id = '98861958-7438-4950-a1db-b3923561a6e2'
        AND om.user_id = :'TEST_USER_ID'
    ) as user_role,
    CASE
        WHEN EXISTS (
            SELECT 1
            FROM organization_members om
            WHERE om.organization_id = '98861958-7438-4950-a1db-b3923561a6e2'
            AND om.user_id = :'TEST_USER_ID'
            AND om.role IN ('owner', 'admin')
            AND om.status = 'active'
        ) THEN '✅ YES - User is owner/admin'
        WHEN EXISTS (
            SELECT 1
            FROM organization_members om
            WHERE om.organization_id = '98861958-7438-4950-a1db-b3923561a6e2'
            AND om.user_id = :'TEST_USER_ID'
            AND om.status = 'active'
        ) THEN '⚠️  MAYBE - User is member but not owner/admin (depends on policy)'
        ELSE '❌ NO - User is not a member'
    END as can_create_project;

-- ============================================
-- 8. SIMULATE auth.uid() FOR TESTING
-- ============================================
SELECT
    '=== SIMULATE auth.uid() CONTEXT ===' as section;

-- This shows what auth.uid() returns for our test user when they make requests
SELECT
    :'TEST_USER_ID' as simulated_auth_uid,
    'authenticated' as simulated_auth_role,
    'This is what database sees when user makes RLS-protected requests' as note;

-- ============================================
-- 9. RECOMMENDATIONS
-- ============================================
SELECT
    '=== RECOMMENDATIONS ===' as section;

SELECT
    'Check Result' as category,
    'Action' as recommendation
WHERE false  -- Just a header

UNION ALL

SELECT
    'User has NO owner roles',
    '→ Run: UPDATE organization_members SET role = ''owner'' WHERE user_id = ''' || :'TEST_USER_ID' || ''' AND organization_id IN (<test-org-ids>);'
WHERE NOT EXISTS (
    SELECT 1 FROM organization_members
    WHERE user_id = :'TEST_USER_ID'
    AND role = 'owner'
)

UNION ALL

SELECT
    'Projects table has no INSERT policy',
    '→ Add policy: CREATE POLICY "Members can create projects" ON projects FOR INSERT WITH CHECK (...)'
WHERE NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE tablename = 'projects'
    AND (cmd = 'INSERT' OR cmd = 'ALL')
)

UNION ALL

SELECT
    'organization_members has no DELETE policy',
    '→ Add policy: CREATE POLICY "Owners can delete members" ON organization_members FOR DELETE USING (...)'
WHERE NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE tablename = 'organization_members'
    AND (cmd = 'DELETE' OR cmd = 'ALL')
);

-- ============================================
-- EXECUTION NOTES
-- ============================================
/*
HOW TO RUN THIS SCRIPT:
1. Copy entire script
2. Paste into Supabase SQL Editor
3. Replace TEST_USER_ID value if needed (line 6)
4. Click "Run"
5. Review all sections
6. Use generated SQL from section 7 to promote user if needed

WHAT TO LOOK FOR:
- Section 2: What roles does user have?
- Section 4: Which orgs can user create projects in?
- Section 5: Which orgs can user manage members in?
- Section 6: What permission gaps exist?
- Section 9: Specific recommendations based on findings

COMMON FIXES:
- If user has no 'owner' roles → Promote on test orgs (section 7 SQL)
- If table has no INSERT policy → Add permissive policy
- If policy requires 'owner' but user is 'admin' → Relax policy or promote user
*/
