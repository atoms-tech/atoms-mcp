-- Final solution: Only update embedding column, avoid triggers

-- Create the function
CREATE OR REPLACE FUNCTION update_embedding_only(
    p_table_name text,
    p_record_id uuid,
    p_embedding vector(768)
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    -- Only update embedding, don't touch updated_at or updated_by
    -- This avoids triggering the updated_by trigger
    EXECUTE format('UPDATE %I SET embedding = $1 WHERE id = $2', p_table_name)
    USING p_embedding, p_record_id;
END;
$$;

-- Grant permissions
GRANT EXECUTE ON FUNCTION update_embedding_only(text, uuid, vector) TO service_role;
GRANT EXECUTE ON FUNCTION update_embedding_only(text, uuid, vector) TO authenticated;

-- Test it
SELECT update_embedding_only(
    'organizations',
    '8b9e419c-6c8e-4d57-a201-9b7bb8b237dd',
    array_fill(0.0, ARRAY[768])::vector
);

-- Verify it worked
SELECT id, name, embedding IS NOT NULL as has_embedding
FROM organizations
WHERE id = '8b9e419c-6c8e-4d57-a201-9b7bb8b237dd';
