-- ============================================================================
-- Entity Creation & RLS Fixes (2025-10-07)
-- Addresses:
--   * Organization slug CHECK constraint failures (underscores in timestamps)
--   * Infinite recursion in project_members RLS policy blocking project creation
--   * Documents/test_req RLS preventing creation for legitimate project members
-- ============================================================================

BEGIN;

-- --------------------------------------------------------------------------
-- 1. Normalize slugs before they hit CHECK constraints
-- --------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.normalize_slug(input_slug text)
RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
    normalized text;
BEGIN
    IF input_slug IS NULL THEN
        RETURN NULL;
    END IF;

    normalized := lower(trim(input_slug));
    normalized := regexp_replace(normalized, '[^a-z0-9]+', '-', 'g');
    normalized := regexp_replace(normalized, '-{2,}', '-', 'g');
    normalized := trim(both '-' FROM normalized);

    IF normalized IS NULL OR normalized = '' THEN
        RAISE EXCEPTION 'Slug cannot be empty after normalization';
    END IF;

    RETURN normalized;
END;
$$;

COMMENT ON FUNCTION public.normalize_slug(text)
    IS 'Normalizes user-provided slugs to lowercase hyphenated format (replaces underscores).';

CREATE OR REPLACE FUNCTION public.apply_slug_normalization()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
    IF NEW.slug IS NOT NULL THEN
        NEW.slug := public.normalize_slug(NEW.slug);
    END IF;
    RETURN NEW;
END;
$$;

COMMENT ON FUNCTION public.apply_slug_normalization()
    IS 'Trigger helper that normalizes slug fields before insert/update.';

DROP TRIGGER IF EXISTS tr_normalize_slug_organizations ON public.organizations;
CREATE TRIGGER tr_normalize_slug_organizations
    BEFORE INSERT OR UPDATE ON public.organizations
    FOR EACH ROW
    EXECUTE FUNCTION public.apply_slug_normalization();

DROP TRIGGER IF EXISTS tr_normalize_slug_projects ON public.projects;
CREATE TRIGGER tr_normalize_slug_projects
    BEFORE INSERT OR UPDATE ON public.projects
    FOR EACH ROW
    EXECUTE FUNCTION public.apply_slug_normalization();

DROP TRIGGER IF EXISTS tr_normalize_slug_documents ON public.documents;
CREATE TRIGGER tr_normalize_slug_documents
    BEFORE INSERT OR UPDATE ON public.documents
    FOR EACH ROW
    EXECUTE FUNCTION public.apply_slug_normalization();

-- --------------------------------------------------------------------------
-- 2. Helper functions that bypass RLS recursion safely
-- --------------------------------------------------------------------------
DROP FUNCTION IF EXISTS public.user_can_access_project(uuid);
DROP FUNCTION IF EXISTS public.user_can_access_project(uuid, uuid);
CREATE OR REPLACE FUNCTION public.user_can_access_project(p_project_id uuid, p_user_id uuid)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public, pg_temp
STABLE
AS $$
    SELECT EXISTS (
        SELECT 1
        FROM projects p
        WHERE p.id = p_project_id
          AND (
                p.created_by = p_user_id
             OR EXISTS (
                    SELECT 1
                    FROM project_members pm
                    WHERE pm.project_id = p.id
                      AND pm.user_id = p_user_id
                      AND pm.status = 'active'
                      AND pm.is_deleted = false
                )
             OR EXISTS (
                    SELECT 1
                    FROM organization_members om
                    WHERE om.organization_id = p.organization_id
                      AND om.user_id = p_user_id
                      AND om.status = 'active'
                      AND om.is_deleted = false
                )
          )
    );
$$;

COMMENT ON FUNCTION public.user_can_access_project(uuid, uuid)
    IS 'Returns true when the supplied user has access to the project (creator, project member, or org admin/member).';

GRANT EXECUTE ON FUNCTION public.user_can_access_project(uuid, uuid) TO authenticated, anon, service_role;

DROP FUNCTION IF EXISTS public.project_has_members(uuid);
CREATE OR REPLACE FUNCTION public.project_has_members(p_project_id uuid)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public, pg_temp
STABLE
AS $$
    SELECT EXISTS (
        SELECT 1
        FROM project_members pm
        WHERE pm.project_id = p_project_id
          AND pm.is_deleted = false
    );
$$;

COMMENT ON FUNCTION public.project_has_members(uuid)
    IS 'Checks if a project already has at least one (non-deleted) member. SECURITY DEFINER avoids RLS recursion.';

GRANT EXECUTE ON FUNCTION public.project_has_members(uuid) TO authenticated, anon, service_role;

DROP FUNCTION IF EXISTS public.project_member_can_manage(uuid);
DROP FUNCTION IF EXISTS public.project_member_can_manage(uuid, uuid);
CREATE OR REPLACE FUNCTION public.project_member_can_manage(p_project_id uuid, p_user_id uuid)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public, pg_temp
STABLE
AS $$
    SELECT EXISTS (
        SELECT 1
        FROM project_members pm
        WHERE pm.project_id = p_project_id
          AND pm.user_id = p_user_id
          AND pm.role IN ('owner', 'admin')
          AND pm.status = 'active'
          AND pm.is_deleted = false
    )
    OR EXISTS (
        SELECT 1
        FROM projects p
        WHERE p.id = p_project_id
          AND p.created_by = p_user_id
    )
    OR EXISTS (
        SELECT 1
        FROM organization_members om
        JOIN projects p ON p.organization_id = om.organization_id
        WHERE p.id = p_project_id
          AND om.user_id = p_user_id
          AND om.role IN ('owner', 'admin')
          AND om.status = 'active'
          AND om.is_deleted = false
    );
$$;

COMMENT ON FUNCTION public.project_member_can_manage(uuid, uuid)
    IS 'True when user is project owner/admin or corresponding org owner/admin (used for project_members RLS).';

GRANT EXECUTE ON FUNCTION public.project_member_can_manage(uuid, uuid) TO authenticated, anon, service_role;

-- --------------------------------------------------------------------------
-- 3. Ensure project auto-owner trigger bypasses RLS
-- --------------------------------------------------------------------------
DROP TRIGGER IF EXISTS after_project_insert ON public.projects;
DROP FUNCTION IF EXISTS public.handle_new_project();

CREATE OR REPLACE FUNCTION public.handle_new_project()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, pg_temp
AS $$
BEGIN
  INSERT INTO public.project_members (org_id, project_id, user_id, role, status)
  VALUES (
    NEW.organization_id,
    NEW.id,
    COALESCE(NEW.created_by, auth.uid()),
    'owner'::project_role,
    'active'::user_status
  )
  ON CONFLICT (project_id, user_id)
  DO UPDATE SET
    role = 'owner'::project_role,
    status = 'active'::user_status,
    is_deleted = false,
    updated_at = timezone('utc'::text, now());

  RETURN NEW;
END;
$$;

CREATE TRIGGER after_project_insert
  AFTER INSERT ON public.projects
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_project();

COMMENT ON FUNCTION public.handle_new_project()
    IS 'Adds project creator as owner using SECURITY DEFINER so it bypasses RLS.';

-- --------------------------------------------------------------------------
-- 4. Project members policy (avoid recursive lookups)
-- --------------------------------------------------------------------------
DROP POLICY IF EXISTS "Project owners and admins can manage members" ON public.project_members;

CREATE POLICY "Project owners and admins can manage members"
ON public.project_members
FOR ALL
TO authenticated
USING (
    public.project_member_can_manage(project_id, auth.uid())
)
WITH CHECK (
    public.project_member_can_manage(project_id, auth.uid())
    OR NOT public.project_has_members(project_id)
);

COMMENT ON POLICY "Project owners and admins can manage members" ON public.project_members
    IS 'Allows owners/admins to manage members and lets the first membership insert succeed for auto-add trigger.';

-- --------------------------------------------------------------------------
-- 5. Documents RLS (allow inserts for real project members)
-- --------------------------------------------------------------------------
DROP POLICY IF EXISTS "Users can view documents" ON public.documents;
DROP POLICY IF EXISTS "Users can create documents" ON public.documents;
DROP POLICY IF EXISTS "Users can update documents" ON public.documents;
DROP POLICY IF EXISTS "Users can delete documents" ON public.documents;
DROP POLICY IF EXISTS "Project members can manage documents" ON public.documents;

CREATE POLICY "Project members can manage documents"
ON public.documents
FOR ALL
TO authenticated
USING (public.user_can_access_project(project_id, auth.uid()))
WITH CHECK (public.user_can_access_project(project_id, auth.uid()));

COMMENT ON POLICY "Project members can manage documents" ON public.documents
    IS 'Single policy covering SELECT/INSERT/UPDATE/DELETE for users who have project access via org/project membership.';

-- --------------------------------------------------------------------------
-- 6. test_req RLS (mirror requirements logic for tests)
-- --------------------------------------------------------------------------
DROP POLICY IF EXISTS "Users can view tests" ON public.test_req;
DROP POLICY IF EXISTS "Users can create tests" ON public.test_req;
DROP POLICY IF EXISTS "Users can update tests" ON public.test_req;
DROP POLICY IF EXISTS "Users can delete tests" ON public.test_req;
DROP POLICY IF EXISTS "Project members can manage tests" ON public.test_req;

CREATE POLICY "Project members can manage tests"
ON public.test_req
FOR ALL
TO authenticated
USING (public.user_can_access_project(project_id, auth.uid()))
WITH CHECK (public.user_can_access_project(project_id, auth.uid()));

COMMENT ON POLICY "Project members can manage tests" ON public.test_req
    IS 'Allows legitimate project members to create/read/update/delete test cases.';

COMMIT;
