-- Fix: project_members RLS blocking project creation
-- Issue: "Project owners and admins can manage members" policy has no WITH CHECK clause
-- This blocks auto_add_project_owner trigger from adding creator as member

-- Drop and recreate the policy with proper WITH CHECK clause
DROP POLICY IF EXISTS "Project owners and admins can manage members" ON project_members;

CREATE POLICY "Project owners and admins can manage members" ON project_members
FOR ALL
USING (
    is_project_owner_or_admin(project_id, auth.uid())
)
WITH CHECK (
    -- Allow insert if user is owner/admin of the project
    -- OR if this is the initial member being added (for auto_add_project_owner trigger)
    is_project_owner_or_admin(project_id, auth.uid())
    OR NOT EXISTS (
        SELECT 1 FROM project_members pm
        WHERE pm.project_id = NEW.project_id
    )
);

COMMENT ON POLICY "Project owners and admins can manage members" ON project_members IS
'Allows project owners/admins to manage members. Also allows auto-add trigger to add first member.';
