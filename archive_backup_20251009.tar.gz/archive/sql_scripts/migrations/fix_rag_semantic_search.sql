-- Fix: RAG Semantic Search NoneType multiplication error
-- Issue: Embeddings are NULL in database, causing "unsupported operand type(s) for *: 'NoneType' and 'int'"

-- Check which entities have NULL embeddings
SELECT
    'requirements' as table_name,
    COUNT(*) as total,
    COUNT(embedding) as with_embedding,
    COUNT(*) - COUNT(embedding) as null_embeddings
FROM requirements
UNION ALL
SELECT
    'documents' as table_name,
    COUNT(*) as total,
    COUNT(embedding) as with_embedding,
    COUNT(*) - COUNT(embedding) as null_embeddings
FROM documents;

-- The issue is that embeddings are NULL for most/all entities
-- The vector search SQL tries to calculate distance with NULL embeddings
-- This causes: NULL * similarity_threshold = error

-- Solutions:
-- 1. Generate embeddings for all existing entities (run backfill)
-- 2. OR: Update vector search to filter out NULL embeddings BEFORE distance calculation

-- Immediate fix: Check the vector search function/SQL and add NULL check
-- Example fix in SQL query:
/*
SELECT *
FROM requirements
WHERE embedding IS NOT NULL  -- Add this check!
ORDER BY embedding <-> %s::vector
LIMIT %s
*/

COMMENT ON COLUMN requirements.embedding IS
'Vector embedding - NULL values cause semantic search to fail. Run embedding backfill to populate.';
