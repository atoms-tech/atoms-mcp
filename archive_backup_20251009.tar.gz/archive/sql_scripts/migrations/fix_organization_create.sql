-- Fix: Auto-set created_by and updated_by on INSERT for organizations
-- This fixes the "new row for relation organizations" constraint violation

-- Create or replace the function to handle both INSERT and UPDATE
CREATE OR REPLACE FUNCTION handle_organization_audit_fields()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        -- On INSERT, set both created_by and updated_by
        NEW.created_by = COALESCE(NEW.created_by, auth.uid());
        NEW.updated_by = COALESCE(NEW.updated_by, auth.uid(), NEW.created_by);
    ELSIF TG_OP = 'UPDATE' THEN
        -- On UPDATE, use auth.uid() if available, otherwise preserve or use created_by
        NEW.updated_by = COALESCE(auth.uid(), OLD.updated_by, NEW.created_by, OLD.created_by);
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop old UPDATE-only trigger
DROP TRIGGER IF EXISTS tr_update_orgs ON organizations;

-- Create combined INSERT + UPDATE trigger
CREATE TRIGGER tr_organization_audit
    BEFORE INSERT OR UPDATE ON organizations
    FOR EACH ROW
    EXECUTE FUNCTION handle_organization_audit_fields();

COMMENT ON TRIGGER tr_organization_audit ON organizations IS
'Auto-sets created_by/updated_by fields on INSERT/UPDATE';
