-- Add RLS policies for test_req table (same pattern as requirements)

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Org members can view test_req" ON test_req;
DROP POLICY IF EXISTS "Org members can create test_req" ON test_req;
DROP POLICY IF EXISTS "Org members can update test_req" ON test_req;
DROP POLICY IF EXISTS "Org members can delete test_req" ON test_req;
DROP POLICY IF EXISTS "Users can view tests" ON test_req;
DROP POLICY IF EXISTS "Users can create tests" ON test_req;
DROP POLICY IF EXISTS "Users can update tests" ON test_req;
DROP POLICY IF EXISTS "Users can delete tests" ON test_req;

-- Allow users to view tests in their accessible projects
CREATE POLICY "Users can view tests" ON test_req FOR SELECT
USING (
    project_id IN (
        SELECT p.id FROM projects p
        WHERE p.organization_id IN (
            SELECT organization_id FROM organization_members
            WHERE user_id = auth.uid() AND status = 'active'
        )
        OR p.created_by = auth.uid()
    )
);

-- Allow users to create tests in their projects
CREATE POLICY "Users can create tests" ON test_req FOR INSERT
WITH CHECK (
    project_id IN (
        SELECT p.id FROM projects p
        WHERE p.organization_id IN (
            SELECT organization_id FROM organization_members
            WHERE user_id = auth.uid() AND status = 'active'
        )
        OR p.created_by = auth.uid()
    )
);

-- Allow users to update/delete their own tests
CREATE POLICY "Users can update tests" ON test_req FOR UPDATE
USING (created_by = auth.uid());

CREATE POLICY "Users can delete tests" ON test_req FOR DELETE
USING (created_by = auth.uid());
