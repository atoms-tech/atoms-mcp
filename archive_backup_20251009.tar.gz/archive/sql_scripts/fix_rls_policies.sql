-- Atoms MCP Server - RLS Policy Fixes
-- Fix Row-Level Security policies to allow MCP operations
-- Execute these in Supabase SQL Editor

-- ============================================
-- 1. PROJECTS TABLE - Allow Creation
-- ============================================

-- Drop existing restrictive policy if it exists
DROP POLICY IF EXISTS "Users can create projects in their orgs" ON projects;

-- Allow users to create projects in organizations they're members of
CREATE POLICY "MCP users can create projects in their orgs"
ON projects FOR INSERT
TO authenticated
WITH CHECK (
  organization_id IN (
    SELECT organization_id
    FROM organization_members
    WHERE user_id = auth.uid()
    AND status = 'active'
    AND is_deleted = false
  )
);

-- Allow users to read projects in their orgs
DROP POLICY IF EXISTS "Users can read projects in their orgs" ON projects;
CREATE POLICY "MCP users can read projects in their orgs"
ON projects FOR SELECT
TO authenticated
USING (
  organization_id IN (
    SELECT organization_id
    FROM organization_members
    WHERE user_id = auth.uid()
    AND status = 'active'
    AND is_deleted = false
  )
);

-- Allow users to update projects in their orgs
DROP POLICY IF EXISTS "Users can update projects in their orgs" ON projects;
CREATE POLICY "MCP users can update projects in their orgs"
ON projects FOR UPDATE
TO authenticated
USING (
  organization_id IN (
    SELECT organization_id
    FROM organization_members
    WHERE user_id = auth.uid()
    AND status = 'active'
    AND is_deleted = false
  )
);

-- ============================================
-- 2. ORGANIZATION_MEMBERS TABLE - Member Management
-- ============================================

-- Allow organization owners to manage members
DROP POLICY IF EXISTS "Org owners can manage members" ON organization_members;
CREATE POLICY "MCP org owners can manage members"
ON organization_members FOR ALL
TO authenticated
USING (
  organization_id IN (
    SELECT organization_id
    FROM organization_members AS om
    WHERE om.user_id = auth.uid()
    AND om.role IN ('owner', 'admin')
    AND om.status = 'active'
    AND om.is_deleted = false
  )
)
WITH CHECK (
  organization_id IN (
    SELECT organization_id
    FROM organization_members AS om
    WHERE om.user_id = auth.uid()
    AND om.role IN ('owner', 'admin')
    AND om.status = 'active'
    AND om.is_deleted = false
  )
);

-- Allow users to read organization members for orgs they belong to
DROP POLICY IF EXISTS "Users can read org members" ON organization_members;
CREATE POLICY "MCP users can read org members"
ON organization_members FOR SELECT
TO authenticated
USING (
  organization_id IN (
    SELECT organization_id
    FROM organization_members AS om
    WHERE om.user_id = auth.uid()
    AND om.status = 'active'
    AND om.is_deleted = false
  )
);

-- ============================================
-- 3. DOCUMENTS TABLE - Allow Creation
-- ============================================

-- Allow users to create documents in projects they have access to
DROP POLICY IF EXISTS "Users can create documents" ON documents;
CREATE POLICY "MCP users can create documents in their projects"
ON documents FOR INSERT
TO authenticated
WITH CHECK (
  project_id IN (
    SELECT p.id
    FROM projects p
    JOIN organization_members om ON p.organization_id = om.organization_id
    WHERE om.user_id = auth.uid()
    AND om.status = 'active'
    AND om.is_deleted = false
  )
);

-- Allow users to read documents in their projects
DROP POLICY IF EXISTS "Users can read documents" ON documents;
CREATE POLICY "MCP users can read documents in their projects"
ON documents FOR SELECT
TO authenticated
USING (
  project_id IN (
    SELECT p.id
    FROM projects p
    JOIN organization_members om ON p.organization_id = om.organization_id
    WHERE om.user_id = auth.uid()
    AND om.status = 'active'
    AND om.is_deleted = false
  )
);

-- Allow users to update documents in their projects
DROP POLICY IF EXISTS "Users can update documents" ON documents;
CREATE POLICY "MCP users can update documents in their projects"
ON documents FOR UPDATE
TO authenticated
USING (
  project_id IN (
    SELECT p.id
    FROM projects p
    JOIN organization_members om ON p.organization_id = om.organization_id
    WHERE om.user_id = auth.uid()
    AND om.status = 'active'
    AND om.is_deleted = false
  )
);

-- ============================================
-- 4. REQUIREMENTS TABLE - Full CRUD Access
-- ============================================

-- Allow users to create requirements in their documents
DROP POLICY IF EXISTS "Users can create requirements" ON requirements;
CREATE POLICY "MCP users can create requirements in their documents"
ON requirements FOR INSERT
TO authenticated
WITH CHECK (
  document_id IN (
    SELECT d.id
    FROM documents d
    JOIN projects p ON d.project_id = p.id
    JOIN organization_members om ON p.organization_id = om.organization_id
    WHERE om.user_id = auth.uid()
    AND om.status = 'active'
    AND om.is_deleted = false
  )
);

-- Read requirements
DROP POLICY IF EXISTS "Users can read requirements" ON requirements;
CREATE POLICY "MCP users can read requirements in their documents"
ON requirements FOR SELECT
TO authenticated
USING (
  document_id IN (
    SELECT d.id
    FROM documents d
    JOIN projects p ON d.project_id = p.id
    JOIN organization_members om ON p.organization_id = om.organization_id
    WHERE om.user_id = auth.uid()
    AND om.status = 'active'
    AND om.is_deleted = false
  )
);

-- Update requirements
DROP POLICY IF EXISTS "Users can update requirements" ON requirements;
CREATE POLICY "MCP users can update requirements in their documents"
ON requirements FOR UPDATE
TO authenticated
USING (
  document_id IN (
    SELECT d.id
    FROM documents d
    JOIN projects p ON d.project_id = p.id
    JOIN organization_members om ON p.organization_id = om.organization_id
    WHERE om.user_id = auth.uid()
    AND om.status = 'active'
    AND om.is_deleted = false
  )
);

-- ============================================
-- 5. VERIFICATION QUERIES
-- ============================================

-- Check current RLS policies
SELECT schemaname, tablename, policyname, permissive, roles, cmd, qual, with_check
FROM pg_policies
WHERE tablename IN ('projects', 'organization_members', 'documents', 'requirements')
ORDER BY tablename, policyname;

-- Test project creation permission
SELECT
  p.id,
  p.name,
  p.organization_id,
  om.user_id,
  om.role,
  om.status
FROM projects p
LEFT JOIN organization_members om ON p.organization_id = om.organization_id
WHERE om.user_id = auth.uid()
LIMIT 5;

-- ============================================
-- 6. ALTERNATIVE: Service Role Bypass (Nuclear Option)
-- ============================================

-- If you want MCP server to bypass ALL RLS (use with caution):
-- Update MCP server to use service_role key instead of user JWT
-- Set SUPABASE_SERVICE_ROLE_KEY in MCP environment
-- This gives full database access - use only if you trust the MCP server completely

-- ============================================
-- NOTES
-- ============================================
-- After running these policies:
-- 1. Test project creation via MCP
-- 2. Test member management via MCP
-- 3. Test document/requirement creation
-- 4. Monitor for any permission errors
-- 5. Consider adding more granular policies based on roles (owner/admin/member/viewer)
