-- ============================================================================
-- Fix RLS Permissions for test_req and properties tables
-- ============================================================================
-- These tables are missing proper RLS policies and permissions
-- causing "permission denied" errors
-- ============================================================================

-- ============================================================================
-- FIX 1: Grant permissions on test_req table
-- ============================================================================

-- Grant SELECT permission to authenticated users
GRANT SELECT ON test_req TO authenticated;
GRANT SELECT ON test_req TO service_role;

-- Grant ALL permissions to service_role (for admin operations)
GRANT ALL ON test_req TO service_role;

-- Enable RLS if not already enabled
ALTER TABLE test_req ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Users can view test_req" ON test_req;
DROP POLICY IF EXISTS "Users can create test_req" ON test_req;
DROP POLICY IF EXISTS "Users can update test_req" ON test_req;
DROP POLICY IF EXISTS "Users can delete test_req" ON test_req;

-- Create basic RLS policies for test_req
-- Note: test_req table HAS is_deleted column, so we can use it in policies
CREATE POLICY "Users can view test_req"
ON test_req FOR SELECT
TO authenticated
USING (is_deleted = false);

CREATE POLICY "Users can create test_req"
ON test_req FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "Users can update test_req"
ON test_req FOR UPDATE
TO authenticated
USING (is_deleted = false)
WITH CHECK (is_deleted = false);

CREATE POLICY "Users can delete test_req"
ON test_req FOR DELETE
TO authenticated
USING (true);

-- ============================================================================
-- FIX 2: Grant permissions on properties table
-- ============================================================================

-- Grant SELECT permission to authenticated users
GRANT SELECT ON properties TO authenticated;
GRANT SELECT ON properties TO service_role;

-- Grant ALL permissions to service_role
GRANT ALL ON properties TO service_role;

-- Enable RLS if not already enabled
ALTER TABLE properties ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Users can view properties" ON properties;
DROP POLICY IF EXISTS "Users can create properties" ON properties;
DROP POLICY IF EXISTS "Users can update properties" ON properties;
DROP POLICY IF EXISTS "Users can delete properties" ON properties;

-- Create basic RLS policies for properties
-- Note: properties table HAS is_deleted column, so we can use it in policies
CREATE POLICY "Users can view properties"
ON properties FOR SELECT
TO authenticated
USING (is_deleted = false);

CREATE POLICY "Users can create properties"
ON properties FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "Users can update properties"
ON properties FOR UPDATE
TO authenticated
USING (is_deleted = false)
WITH CHECK (is_deleted = false);

CREATE POLICY "Users can delete properties"
ON properties FOR DELETE
TO authenticated
USING (true);

-- ============================================================================
-- VERIFICATION
-- ============================================================================

-- Check permissions
SELECT
    table_schema,
    table_name,
    grantee,
    privilege_type
FROM information_schema.role_table_grants
WHERE table_name IN ('test_req', 'properties')
ORDER BY table_name, grantee, privilege_type;

-- Check RLS policies
SELECT
    schemaname,
    tablename,
    policyname,
    permissive,
    roles,
    cmd
FROM pg_policies
WHERE tablename IN ('test_req', 'properties')
ORDER BY tablename, policyname;
