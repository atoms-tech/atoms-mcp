-- Fix RLS Policy for Projects Table
-- This allows organization members to create projects

-- Drop existing restrictive INSERT policy if it exists
DROP POLICY IF EXISTS "Enable insert for authenticated users only" ON projects;
DROP POLICY IF EXISTS "Users can insert projects" ON projects;

-- Create new INSERT policy that allows organization members
CREATE POLICY "Organization members can create projects"
ON projects
FOR INSERT
TO authenticated
WITH CHECK (
  -- Allow if user is a member of the organization
  EXISTS (
    SELECT 1
    FROM organization_members
    WHERE organization_id = new.organization_id
    AND user_id = auth.uid()
    AND status = 'active'
    AND is_deleted = false
  )
  OR
  -- Allow if user is the creator
  auth.uid() = new.created_by
);

-- Ensure UPDATE policy is also correct
DROP POLICY IF EXISTS "Users can update own projects" ON projects;

CREATE POLICY "Organization members can update projects"
ON projects
FOR UPDATE
TO authenticated
USING (
  -- Can update if member of the project's organization
  EXISTS (
    SELECT 1
    FROM organization_members
    WHERE organization_id = projects.organization_id
    AND user_id = auth.uid()
    AND status = 'active'
    AND is_deleted = false
  )
  OR
  -- Or if they created it
  created_by = auth.uid()
)
WITH CHECK (
  -- Same check for the new values
  EXISTS (
    SELECT 1
    FROM organization_members
    WHERE organization_id = new.organization_id
    AND user_id = auth.uid()
    AND status = 'active'
    AND is_deleted = false
  )
  OR
  auth.uid() = new.created_by
);

-- Ensure SELECT policy allows org members to view projects
DROP POLICY IF EXISTS "Users can view own projects" ON projects;

CREATE POLICY "Organization members can view projects"
ON projects
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1
    FROM organization_members
    WHERE organization_id = projects.organization_id
    AND user_id = auth.uid()
    AND status = 'active'
    AND is_deleted = false
  )
  OR
  created_by = auth.uid()
);

-- Ensure DELETE policy (soft delete)
DROP POLICY IF EXISTS "Users can delete own projects" ON projects;

CREATE POLICY "Organization members can delete projects"
ON projects
FOR DELETE
TO authenticated
USING (
  EXISTS (
    SELECT 1
    FROM organization_members
    WHERE organization_id = projects.organization_id
    AND user_id = auth.uid()
    AND status = 'active'
    AND is_deleted = false
  )
  OR
  created_by = auth.uid()
);

-- Grant necessary permissions
GRANT SELECT, INSERT, UPDATE, DELETE ON projects TO authenticated;
