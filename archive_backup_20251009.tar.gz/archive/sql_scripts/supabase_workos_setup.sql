-- Supabase setup for WorkOS integration
-- Run this in your Supabase SQL Editor

-- 1. Create a function to handle new user creation from WorkOS
-- This ensures WorkOS users are properly synced to your existing user structure
CREATE OR REPLACE FUNCTION public.handle_workos_user()
RETURNS trigger AS $$
BEGIN
  -- Insert into your existing users/profiles table structure
  -- Adjust table name and columns based on your existing schema
  INSERT INTO public.profiles (id, email, full_name, created_at, updated_at)
  VALUES (
    NEW.id, 
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email),
    NOW(),
    NOW()
  )
  ON CONFLICT (id) DO UPDATE SET
    email = EXCLUDED.email,
    full_name = COALESCE(EXCLUDED.full_name, profiles.full_name),
    updated_at = NOW();
  
  RETURN NEW;
END;
$$ language plpgsql security definer;

-- 2. Create trigger to sync WorkOS users to your profiles table
DROP TRIGGER IF EXISTS on_workos_user_created ON auth.users;
CREATE TRIGGER on_workos_user_created
  AFTER INSERT OR UPDATE ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_workos_user();

-- 3. Update your existing profiles table to handle WorkOS users (if needed)
-- Add columns for WorkOS integration if they don't exist
DO $$
BEGIN
  -- Add workos_user_id column if it doesn't exist
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name = 'profiles' AND column_name = 'workos_user_id') THEN
    ALTER TABLE profiles ADD COLUMN workos_user_id TEXT;
    CREATE INDEX IF NOT EXISTS idx_profiles_workos_user_id ON profiles(workos_user_id);
  END IF;
  
  -- Add provider column if it doesn't exist
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name = 'profiles' AND column_name = 'auth_provider') THEN
    ALTER TABLE profiles ADD COLUMN auth_provider TEXT DEFAULT 'email';
  END IF;
END
$$;

-- 4. Create function to link WorkOS users with existing Supabase users by email
CREATE OR REPLACE FUNCTION public.link_workos_user(
  workos_user_id TEXT,
  user_email TEXT
) RETURNS UUID AS $$
DECLARE
  existing_user_id UUID;
BEGIN
  -- Find existing user by email
  SELECT id INTO existing_user_id 
  FROM auth.users 
  WHERE email = user_email;
  
  IF existing_user_id IS NOT NULL THEN
    -- Update profile with WorkOS user ID
    UPDATE public.profiles 
    SET workos_user_id = link_workos_user.workos_user_id,
        auth_provider = 'workos',
        updated_at = NOW()
    WHERE id = existing_user_id;
    
    RETURN existing_user_id;
  END IF;
  
  RETURN NULL;
END;
$$ language plpgsql security definer;

-- 5. Create RLS policies for WorkOS integration
-- Allow WorkOS service to read user data for validation
CREATE POLICY "WorkOS service can read user profiles" ON profiles
  FOR SELECT
  TO service_role
  USING (true);

-- Allow WorkOS service to update profiles during sync
CREATE POLICY "WorkOS service can update profiles" ON profiles
  FOR UPDATE
  TO service_role
  USING (true);

-- 6. Create a view for WorkOS user lookup (optional)
CREATE OR REPLACE VIEW public.workos_users AS
SELECT 
  p.id,
  p.email,
  p.full_name,
  p.workos_user_id,
  p.auth_provider,
  au.email_confirmed_at,
  au.last_sign_in_at,
  au.created_at
FROM public.profiles p
JOIN auth.users au ON p.id = au.id
WHERE p.auth_provider IN ('workos', 'email');

-- Grant access to the view
GRANT SELECT ON public.workos_users TO service_role;

-- 7. Create function to validate user credentials for WorkOS proxy
CREATE OR REPLACE FUNCTION public.validate_user_credentials(
  user_email TEXT,
  check_password TEXT DEFAULT NULL
) RETURNS JSONB AS $$
DECLARE
  user_record RECORD;
  result JSONB;
BEGIN
  -- Get user from auth.users
  SELECT au.id, au.email, au.encrypted_password, au.email_confirmed_at,
         p.full_name, p.workos_user_id, p.auth_provider
  INTO user_record
  FROM auth.users au
  LEFT JOIN public.profiles p ON au.id = p.id
  WHERE au.email = user_email
    AND au.email_confirmed_at IS NOT NULL;
  
  IF user_record IS NULL THEN
    RETURN jsonb_build_object(
      'success', false,
      'error', 'User not found or email not confirmed'
    );
  END IF;
  
  -- For OAuth users (GitHub, Google), password check is skipped
  IF user_record.auth_provider IN ('github', 'google') THEN
    RETURN jsonb_build_object(
      'success', true,
      'user', jsonb_build_object(
        'id', user_record.id,
        'email', user_record.email,
        'full_name', COALESCE(user_record.full_name, ''),
        'auth_provider', user_record.auth_provider,
        'workos_user_id', user_record.workos_user_id
      )
    );
  END IF;
  
  -- For email/password users, validate password if provided
  -- Note: This is a simplified check - in production you'd use proper password hashing
  IF check_password IS NOT NULL THEN
    -- Password validation would happen here
    -- For now, we'll assume it's handled by the application layer
    NULL;
  END IF;
  
  RETURN jsonb_build_object(
    'success', true,
    'user', jsonb_build_object(
      'id', user_record.id,
      'email', user_record.email,
      'full_name', COALESCE(user_record.full_name, ''),
      'auth_provider', COALESCE(user_record.auth_provider, 'email'),
      'workos_user_id', user_record.workos_user_id
    )
  );
END;
$$ language plpgsql security definer;

-- Grant execute permission to service role
GRANT EXECUTE ON FUNCTION public.validate_user_credentials(TEXT, TEXT) TO service_role;
GRANT EXECUTE ON FUNCTION public.link_workos_user(TEXT, TEXT) TO service_role;

-- 8. Create audit table for WorkOS integration events (optional)
CREATE TABLE IF NOT EXISTS public.workos_audit_log (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id),
  event_type TEXT NOT NULL,
  event_data JSONB,
  workos_user_id TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS on audit log
ALTER TABLE public.workos_audit_log ENABLE ROW LEVEL SECURITY;

-- Create policy for audit log
CREATE POLICY "Service role can access audit log" ON public.workos_audit_log
  FOR ALL
  TO service_role
  USING (true);

-- Create index for performance
CREATE INDEX IF NOT EXISTS idx_workos_audit_user_id ON public.workos_audit_log(user_id);
CREATE INDEX IF NOT EXISTS idx_workos_audit_created_at ON public.workos_audit_log(created_at);

-- 9. Create function to log WorkOS events
CREATE OR REPLACE FUNCTION public.log_workos_event(
  user_id UUID,
  event_type TEXT,
  event_data JSONB DEFAULT NULL,
  workos_user_id TEXT DEFAULT NULL
) RETURNS UUID AS $$
DECLARE
  log_id UUID;
BEGIN
  INSERT INTO public.workos_audit_log (user_id, event_type, event_data, workos_user_id)
  VALUES (user_id, event_type, event_data, workos_user_id)
  RETURNING id INTO log_id;
  
  RETURN log_id;
END;
$$ language plpgsql security definer;

GRANT EXECUTE ON FUNCTION public.log_workos_event(UUID, TEXT, JSONB, TEXT) TO service_role;