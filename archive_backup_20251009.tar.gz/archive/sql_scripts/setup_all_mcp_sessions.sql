-- ============================================================================
-- Complete MCP Sessions Setup Script
-- Run this in Supabase SQL Editor to set up persistent session storage
-- ============================================================================

-- Step 1: Create mcp_sessions table
-- ============================================================================

CREATE TABLE IF NOT EXISTS mcp_sessions (
    -- Unique session identifier (UUID format recommended)
    session_id TEXT PRIMARY KEY,

    -- User identifier from OAuth/Supabase auth
    user_id UUID NOT NULL,

    -- OAuth tokens and user information
    -- Structure: {
    --   "access_token": "...",
    --   "refresh_token": "...",
    --   "expires_in": 3600,
    --   "token_type": "Bearer",
    --   "user": {"id": "...", "email": "..."}
    -- }
    oauth_data JSONB NOT NULL,

    -- MCP connection state (for stateful tool operations)
    -- Can store workspace context, last query, etc.
    mcp_state JSONB DEFAULT '{}'::jsonb,

    -- Timestamps
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),

    -- Session expiry (auto-cleanup after this time)
    expires_at TIMESTAMPTZ NOT NULL,

    -- Constraints
    CONSTRAINT valid_session_id CHECK (length(session_id) > 0),
    CONSTRAINT valid_oauth_data CHECK (jsonb_typeof(oauth_data) = 'object'),
    CONSTRAINT valid_mcp_state CHECK (jsonb_typeof(mcp_state) = 'object'),
    CONSTRAINT expires_after_creation CHECK (expires_at > created_at)
);

-- Step 2: Create indexes for performance
-- ============================================================================

CREATE INDEX IF NOT EXISTS idx_mcp_sessions_user_id
    ON mcp_sessions(user_id);

CREATE INDEX IF NOT EXISTS idx_mcp_sessions_expires_at
    ON mcp_sessions(expires_at);

CREATE INDEX IF NOT EXISTS idx_mcp_sessions_created_at
    ON mcp_sessions(created_at);

-- Step 3: Create trigger for updated_at
-- ============================================================================

CREATE OR REPLACE FUNCTION update_mcp_sessions_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_update_mcp_sessions_updated_at ON mcp_sessions;

CREATE TRIGGER trigger_update_mcp_sessions_updated_at
    BEFORE UPDATE ON mcp_sessions
    FOR EACH ROW
    EXECUTE FUNCTION update_mcp_sessions_updated_at();

-- Step 4: Create auto-cleanup function for expired sessions
-- ============================================================================

CREATE OR REPLACE FUNCTION cleanup_expired_mcp_sessions()
RETURNS INTEGER AS $$
DECLARE
    deleted_count INTEGER;
BEGIN
    DELETE FROM mcp_sessions
    WHERE expires_at < NOW();

    GET DIAGNOSTICS deleted_count = ROW_COUNT;

    RETURN deleted_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Step 5: Enable Row Level Security (RLS)
-- ============================================================================

ALTER TABLE mcp_sessions ENABLE ROW LEVEL SECURITY;

-- Step 6: Create RLS policies
-- ============================================================================

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Users can view own sessions" ON mcp_sessions;
DROP POLICY IF EXISTS "Users can create own sessions" ON mcp_sessions;
DROP POLICY IF EXISTS "Users can update own sessions" ON mcp_sessions;
DROP POLICY IF EXISTS "Users can delete own sessions" ON mcp_sessions;
DROP POLICY IF EXISTS "Service role can manage all sessions" ON mcp_sessions;
DROP POLICY IF EXISTS "Anonymous users can create sessions" ON mcp_sessions;

-- Policy: Users can view their own sessions
CREATE POLICY "Users can view own sessions"
    ON mcp_sessions
    FOR SELECT
    USING (
        auth.uid() = user_id
        OR auth.jwt() ->> 'role' = 'service_role'
    );

-- Policy: Users can create their own sessions
CREATE POLICY "Users can create own sessions"
    ON mcp_sessions
    FOR INSERT
    WITH CHECK (
        auth.uid() = user_id
        OR auth.jwt() ->> 'role' = 'service_role'
    );

-- Policy: Users can update their own sessions
CREATE POLICY "Users can update own sessions"
    ON mcp_sessions
    FOR UPDATE
    USING (
        auth.uid() = user_id
        OR auth.jwt() ->> 'role' = 'service_role'
    )
    WITH CHECK (
        auth.uid() = user_id
        OR auth.jwt() ->> 'role' = 'service_role'
    );

-- Policy: Users can delete their own sessions
CREATE POLICY "Users can delete own sessions"
    ON mcp_sessions
    FOR DELETE
    USING (
        auth.uid() = user_id
        OR auth.jwt() ->> 'role' = 'service_role'
    );

-- Policy: Allow anonymous session creation (for OAuth flow)
-- Sessions created during OAuth before user is fully authenticated
CREATE POLICY "Anonymous users can create sessions"
    ON mcp_sessions
    FOR INSERT
    WITH CHECK (true);

-- Step 7: Grant permissions
-- ============================================================================

-- Grant usage on the table to authenticated and anon users
GRANT ALL ON mcp_sessions TO authenticated;
GRANT ALL ON mcp_sessions TO anon;
GRANT ALL ON mcp_sessions TO service_role;

-- Step 8: Create helper functions
-- ============================================================================

-- Function: Get active session by ID
CREATE OR REPLACE FUNCTION get_active_session(p_session_id TEXT)
RETURNS TABLE (
    session_id TEXT,
    user_id UUID,
    oauth_data JSONB,
    mcp_state JSONB,
    created_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ,
    expires_at TIMESTAMPTZ
) AS $$
BEGIN
    RETURN QUERY
    SELECT
        s.session_id,
        s.user_id,
        s.oauth_data,
        s.mcp_state,
        s.created_at,
        s.updated_at,
        s.expires_at
    FROM mcp_sessions s
    WHERE s.session_id = p_session_id
      AND s.expires_at > NOW();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function: Update session activity (extend expiry)
CREATE OR REPLACE FUNCTION update_session_activity(
    p_session_id TEXT,
    p_ttl_hours INTEGER DEFAULT 24
)
RETURNS BOOLEAN AS $$
DECLARE
    updated_count INTEGER;
BEGIN
    UPDATE mcp_sessions
    SET expires_at = NOW() + (p_ttl_hours || ' hours')::INTERVAL
    WHERE session_id = p_session_id
      AND expires_at > NOW();

    GET DIAGNOSTICS updated_count = ROW_COUNT;

    RETURN updated_count > 0;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================================================
-- Verification Queries (run these to confirm setup)
-- ============================================================================

-- Check table exists
SELECT
    schemaname,
    tablename,
    tableowner
FROM pg_tables
WHERE tablename = 'mcp_sessions';

-- Check columns
SELECT
    column_name,
    data_type,
    is_nullable,
    column_default
FROM information_schema.columns
WHERE table_name = 'mcp_sessions'
ORDER BY ordinal_position;

-- Check indexes
SELECT
    indexname,
    indexdef
FROM pg_indexes
WHERE tablename = 'mcp_sessions';

-- Check RLS status
SELECT
    schemaname,
    tablename,
    rowsecurity
FROM pg_tables
WHERE tablename = 'mcp_sessions';

-- Check policies
SELECT
    policyname,
    permissive,
    roles,
    cmd,
    qual,
    with_check
FROM pg_policies
WHERE tablename = 'mcp_sessions';

-- ============================================================================
-- Success!
-- ============================================================================

-- If all queries above return results, your setup is complete!
-- Next: Deploy your MCP server and test OAuth flow
