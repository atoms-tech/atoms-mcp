-- ============================================
-- USER ROLES AUDIT SCRIPT
-- Check what permissions test user has
-- ============================================

-- ⚠️ IMPORTANT: Replace this user ID with yours if different
-- Current test user ID: 79355ae7-3b97-4f94-95bc-060a403788d4

-- ============================================
-- 1. USER PROFILE
-- ============================================
SELECT '=== USER PROFILE ===' as section;

SELECT
    id,
    email,
    full_name,
    status,
    is_approved,
    login_count,
    last_login_at,
    created_at
FROM profiles
WHERE id = '79355ae7-3b97-4f94-95bc-060a403788d4';

-- ============================================
-- 2. ORGANIZATION MEMBERSHIPS
-- ============================================
SELECT '=== ORGANIZATION MEMBERSHIPS ===' as section;

SELECT
    o.id as org_id,
    o.name as organization_name,
    o.slug as org_slug,
    o.type as org_type,
    om.role as user_role,
    om.status as membership_status,
    om.last_active_at,
    om.created_at as member_since,
    CASE
        WHEN om.role = 'owner' THEN '✅ OWNER - Full permissions'
        WHEN om.role = 'admin' THEN '⚠️  ADMIN - Most permissions'
        WHEN om.role = 'editor' THEN '⚠️  EDITOR - Limited permissions'
        WHEN om.role = 'member' THEN '⚠️  MEMBER - Read permissions only'
        ELSE '❓ UNKNOWN ROLE'
    END as permission_level
FROM organization_members om
JOIN organizations o ON om.organization_id = o.id
WHERE om.user_id = '79355ae7-3b97-4f94-95bc-060a403788d4'
AND om.is_deleted = false
ORDER BY
    CASE om.role
        WHEN 'owner' THEN 1
        WHEN 'admin' THEN 2
        WHEN 'editor' THEN 3
        WHEN 'member' THEN 4
        ELSE 5
    END,
    o.name;

-- Count by role
SELECT
    '=== MEMBERSHIP SUMMARY ===' as section;

SELECT
    om.role,
    COUNT(*) as count,
    CASE om.role
        WHEN 'owner' THEN 'Can: Create/Update/Delete projects, Manage members'
        WHEN 'admin' THEN 'Can: Create/Update/Delete projects, Manage some members'
        WHEN 'editor' THEN 'Can: Update projects/documents'
        WHEN 'member' THEN 'Can: Read only'
        ELSE 'Unknown permissions'
    END as typical_permissions
FROM organization_members om
WHERE om.user_id = '79355ae7-3b97-4f94-95bc-060a403788d4'
AND om.is_deleted = false
GROUP BY om.role
ORDER BY
    CASE om.role
        WHEN 'owner' THEN 1
        WHEN 'admin' THEN 2
        WHEN 'editor' THEN 3
        WHEN 'member' THEN 4
        ELSE 5
    END;

-- ============================================
-- 3. PROJECT MEMBERSHIPS
-- ============================================
SELECT
    '=== PROJECT MEMBERSHIPS ===' as section;

SELECT
    p.id as project_id,
    p.name as project_name,
    o.name as organization_name,
    pm.role as project_role,
    pm.status as membership_status,
    pm.created_at as member_since
FROM project_members pm
JOIN projects p ON pm.project_id = p.id
JOIN organizations o ON p.organization_id = o.organization_id
WHERE pm.user_id = '79355ae7-3b97-4f94-95bc-060a403788d4'
AND pm.is_deleted = false
ORDER BY p.name
LIMIT 20;

-- ============================================
-- 4. ORGANIZATIONS WHERE USER CAN CREATE PROJECTS
-- ============================================
SELECT
    '=== ORGS WHERE USER CAN CREATE PROJECTS ===' as section;

SELECT
    o.id,
    o.name,
    o.type,
    om.role,
    CASE
        WHEN om.role IN ('owner', 'admin') THEN '✅ CAN CREATE PROJECTS'
        WHEN om.role = 'editor' THEN '⚠️  MIGHT CREATE (depends on policy)'
        ELSE '❌ CANNOT CREATE PROJECTS'
    END as can_create_projects
FROM organizations o
JOIN organization_members om ON o.id = om.organization_id
WHERE om.user_id = '79355ae7-3b97-4f94-95bc-060a403788d4'
AND om.status = 'active'
AND om.is_deleted = false
AND o.is_deleted = false
ORDER BY om.role, o.name
LIMIT 20;

-- ============================================
-- 5. ORGANIZATIONS WHERE USER CAN MANAGE MEMBERS
-- ============================================
SELECT
    '=== ORGS WHERE USER CAN MANAGE MEMBERS ===' as section;

SELECT
    o.id,
    o.name,
    om.role,
    o.member_count as total_members,
    CASE
        WHEN om.role = 'owner' THEN '✅ CAN ADD/REMOVE ALL MEMBERS'
        WHEN om.role = 'admin' THEN '⚠️  CAN MANAGE SOME MEMBERS (depends on policy)'
        ELSE '❌ CANNOT MANAGE MEMBERS'
    END as can_manage_members
FROM organizations o
JOIN organization_members om ON o.id = om.organization_id
WHERE om.user_id = '79355ae7-3b97-4f94-95bc-060a403788d4'
AND om.status = 'active'
AND om.is_deleted = false
AND o.is_deleted = false
ORDER BY om.role, o.name
LIMIT 20;

-- ============================================
-- 6. PERMISSION GAPS
-- ============================================
SELECT
    '=== PERMISSION GAPS (Organizations with limited access) ===' as section;

SELECT
    o.name as organization,
    om.role as current_role,
    CASE om.role
        WHEN 'member' THEN 'Cannot create projects, Cannot manage members'
        WHEN 'editor' THEN 'Cannot manage members, Project creation depends on policy'
        WHEN 'admin' THEN 'Member management might be limited'
        ELSE 'No known gaps'
    END as limitations
FROM organizations o
JOIN organization_members om ON o.id = om.organization_id
WHERE om.user_id = '79355ae7-3b97-4f94-95bc-060a403788d4'
AND om.role != 'owner'
AND om.status = 'active'
AND om.is_deleted = false
ORDER BY
    CASE om.role
        WHEN 'member' THEN 1
        WHEN 'editor' THEN 2
        WHEN 'admin' THEN 3
        ELSE 4
    END;

-- ============================================
-- 7. QUICK FIX SQL (Copy-paste if needed)
-- ============================================
SELECT
    '=== QUICK FIX: PROMOTE USER TO OWNER ===' as section;

-- Generate UPDATE statements to promote user to owner on test orgs
SELECT
    'UPDATE organization_members SET role = ''owner'' WHERE id = ''' || om.id || '''; -- ' || o.name as sql_to_run
FROM organization_members om
JOIN organizations o ON om.organization_id = o.id
WHERE om.user_id = '79355ae7-3b97-4f94-95bc-060a403788d4'
AND om.role != 'owner'
AND om.status = 'active'
AND o.name ILIKE '%test%' OR o.name ILIKE '%demo%' OR o.name ILIKE '%phenotype%'
ORDER BY o.name;

-- ============================================
-- 8. SUMMARY STATS
-- ============================================
SELECT
    '=== SUMMARY ===' as section;

SELECT
    'Total Organizations' as metric,
    COUNT(*) as value
FROM organization_members
WHERE user_id = '79355ae7-3b97-4f94-95bc-060a403788d4'
AND is_deleted = false

UNION ALL

SELECT
    'Owner of' as metric,
    COUNT(*) as value
FROM organization_members
WHERE user_id = '79355ae7-3b97-4f94-95bc-060a403788d4'
AND role = 'owner'
AND is_deleted = false

UNION ALL

SELECT
    'Admin of' as metric,
    COUNT(*) as value
FROM organization_members
WHERE user_id = '79355ae7-3b97-4f94-95bc-060a403788d4'
AND role = 'admin'
AND is_deleted = false

UNION ALL

SELECT
    'Editor of' as metric,
    COUNT(*) as value
FROM organization_members
WHERE user_id = '79355ae7-3b97-4f94-95bc-060a403788d4'
AND role = 'editor'
AND is_deleted = false

UNION ALL

SELECT
    'Member of' as metric,
    COUNT(*) as value
FROM organization_members
WHERE user_id = '79355ae7-3b97-4f94-95bc-060a403788d4'
AND role = 'member'
AND is_deleted = false;
