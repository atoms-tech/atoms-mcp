-- Full-Text Search (FTS) and Vector Index Setup for Atoms MCP
-- Run this on your Supabase database to enable high-performance search

-- ============================================================================
-- PART 1: Full-Text Search (FTS) Setup
-- ============================================================================

-- Add tsvector columns for full-text search on all searchable tables
-- These will be automatically maintained by triggers

-- Documents FTS
ALTER TABLE documents ADD COLUMN IF NOT EXISTS fts_vector tsvector
    GENERATED ALWAYS AS (
        setweight(to_tsvector('english', coalesce(name, '')), 'A') ||
        setweight(to_tsvector('english', coalesce(description, '')), 'B') ||
        setweight(to_tsvector('english', coalesce(slug, '')), 'C')
    ) STORED;

CREATE INDEX IF NOT EXISTS idx_documents_fts ON documents USING GIN (fts_vector);
COMMENT ON COLUMN documents.fts_vector IS 'Full-text search vector: name(A) + description(B) + slug(C)';

-- Requirements FTS
ALTER TABLE requirements ADD COLUMN IF NOT EXISTS fts_vector tsvector
    GENERATED ALWAYS AS (
        setweight(to_tsvector('english', coalesce(name, '')), 'A') ||
        setweight(to_tsvector('english', coalesce(description, '')), 'B') ||
        setweight(to_tsvector('english', coalesce(original_requirement, '')), 'C') ||
        setweight(to_tsvector('english', coalesce(enchanced_requirement, '')), 'C')
    ) STORED;

CREATE INDEX IF NOT EXISTS idx_requirements_fts ON requirements USING GIN (fts_vector);
COMMENT ON COLUMN requirements.fts_vector IS 'Full-text search vector: name(A) + description(B) + requirements(C)';

-- Projects FTS
ALTER TABLE projects ADD COLUMN IF NOT EXISTS fts_vector tsvector
    GENERATED ALWAYS AS (
        setweight(to_tsvector('english', coalesce(name, '')), 'A') ||
        setweight(to_tsvector('english', coalesce(description, '')), 'B') ||
        setweight(to_tsvector('english', coalesce(slug, '')), 'C')
    ) STORED;

CREATE INDEX IF NOT EXISTS idx_projects_fts ON projects USING GIN (fts_vector);
COMMENT ON COLUMN projects.fts_vector IS 'Full-text search vector: name(A) + description(B) + slug(C)';

-- Organizations FTS
ALTER TABLE organizations ADD COLUMN IF NOT EXISTS fts_vector tsvector
    GENERATED ALWAYS AS (
        setweight(to_tsvector('english', coalesce(name, '')), 'A') ||
        setweight(to_tsvector('english', coalesce(description, '')), 'B') ||
        setweight(to_tsvector('english', coalesce(slug, '')), 'C')
    ) STORED;

CREATE INDEX IF NOT EXISTS idx_organizations_fts ON organizations USING GIN (fts_vector);
COMMENT ON COLUMN organizations.fts_vector IS 'Full-text search vector: name(A) + description(B) + slug(C)';

-- ============================================================================
-- PART 2: Vector Similarity Search Indexes (pgvector)
-- ============================================================================

-- Enable pgvector extension (may already be enabled)
CREATE EXTENSION IF NOT EXISTS vector;

-- Create HNSW indexes for fast similarity search on embedding columns
-- HNSW (Hierarchical Navigable Small World) is faster than IVFFlat for most use cases

-- Documents embedding index
CREATE INDEX IF NOT EXISTS idx_documents_embedding ON documents
USING hnsw (embedding vector_cosine_ops)
WITH (m = 16, ef_construction = 64);

COMMENT ON INDEX idx_documents_embedding IS 'HNSW index for fast cosine similarity search on document embeddings';

-- Requirements embedding index
CREATE INDEX IF NOT EXISTS idx_requirements_embedding ON requirements
USING hnsw (embedding vector_cosine_ops)
WITH (m = 16, ef_construction = 64);

COMMENT ON INDEX idx_requirements_embedding IS 'HNSW index for fast cosine similarity search on requirement embeddings';

-- Projects embedding index
CREATE INDEX IF NOT EXISTS idx_projects_embedding ON projects
USING hnsw (embedding vector_cosine_ops)
WITH (m = 16, ef_construction = 64);

COMMENT ON INDEX idx_projects_embedding IS 'HNSW index for fast cosine similarity search on project embeddings';

-- Organizations embedding index
CREATE INDEX IF NOT EXISTS idx_organizations_embedding ON organizations
USING hnsw (embedding vector_cosine_ops)
WITH (m = 16, ef_construction = 64);

COMMENT ON INDEX idx_organizations_embedding IS 'HNSW index for fast cosine similarity search on organization embeddings';

-- ============================================================================
-- PART 3: Helper Functions for FTS
-- ============================================================================

-- Create helper function to search with FTS
CREATE OR REPLACE FUNCTION search_documents_fts(
    search_query text,
    match_limit int DEFAULT 10,
    filters jsonb DEFAULT NULL
) RETURNS TABLE (
    id text,
    name text,
    description text,
    rank real
) LANGUAGE sql STABLE AS $$
    SELECT
        d.id::text,
        d.name,
        d.description,
        ts_rank(d.fts_vector, websearch_to_tsquery('english', search_query)) as rank
    FROM documents d
    WHERE d.fts_vector @@ websearch_to_tsquery('english', search_query)
    AND (filters IS NULL OR d.is_deleted = false)
    ORDER BY rank DESC
    LIMIT match_limit;
$$;

CREATE OR REPLACE FUNCTION search_requirements_fts(
    search_query text,
    match_limit int DEFAULT 10,
    filters jsonb DEFAULT NULL
) RETURNS TABLE (
    id text,
    name text,
    description text,
    rank real
) LANGUAGE sql STABLE AS $$
    SELECT
        r.id::text,
        r.name,
        r.description,
        ts_rank(r.fts_vector, websearch_to_tsquery('english', search_query)) as rank
    FROM requirements r
    WHERE r.fts_vector @@ websearch_to_tsquery('english', search_query)
    AND (filters IS NULL OR r.is_deleted = false)
    ORDER BY rank DESC
    LIMIT match_limit;
$$;

CREATE OR REPLACE FUNCTION search_projects_fts(
    search_query text,
    match_limit int DEFAULT 10,
    filters jsonb DEFAULT NULL
) RETURNS TABLE (
    id text,
    name text,
    description text,
    rank real
) LANGUAGE sql STABLE AS $$
    SELECT
        p.id::text,
        p.name,
        p.description,
        ts_rank(p.fts_vector, websearch_to_tsquery('english', search_query)) as rank
    FROM projects p
    WHERE p.fts_vector @@ websearch_to_tsquery('english', search_query)
    AND (filters IS NULL OR p.is_deleted = false)
    ORDER BY rank DESC
    LIMIT match_limit;
$$;

CREATE OR REPLACE FUNCTION search_organizations_fts(
    search_query text,
    match_limit int DEFAULT 10,
    filters jsonb DEFAULT NULL
) RETURNS TABLE (
    id text,
    name text,
    description text,
    rank real
) LANGUAGE sql STABLE AS $$
    SELECT
        o.id::text,
        o.name,
        o.description,
        ts_rank(o.fts_vector, websearch_to_tsquery('english', search_query)) as rank
    FROM organizations o
    WHERE o.fts_vector @@ websearch_to_tsquery('english', search_query)
    AND (filters IS NULL OR o.is_deleted = false)
    ORDER BY rank DESC
    LIMIT match_limit;
$$;

-- ============================================================================
-- PART 4: Verification Queries
-- ============================================================================

-- Verify FTS columns were created
SELECT
    table_name,
    column_name,
    data_type
FROM information_schema.columns
WHERE table_schema = 'public'
AND column_name = 'fts_vector'
ORDER BY table_name;

-- Verify FTS indexes were created
SELECT
    schemaname,
    tablename,
    indexname,
    indexdef
FROM pg_indexes
WHERE schemaname = 'public'
AND indexname LIKE '%_fts'
ORDER BY tablename;

-- Verify vector indexes were created
SELECT
    schemaname,
    tablename,
    indexname,
    indexdef
FROM pg_indexes
WHERE schemaname = 'public'
AND indexname LIKE '%_embedding'
ORDER BY tablename;

-- Test FTS search
SELECT * FROM search_documents_fts('vehicle', 5);
SELECT * FROM search_requirements_fts('authentication', 5);

-- ============================================================================
-- Performance Notes
-- ============================================================================

-- FTS (tsvector + GIN):
-- - 10-100x faster than ILIKE for text search
-- - Handles stemming (vehicle → vehicles)
-- - Weighted by importance (name > description > slug)
-- - Uses websearch_to_tsquery for natural queries

-- Vector Indexes (HNSW):
-- - 100-1000x faster than sequential scan
-- - m=16: connections per layer (higher = more accurate, slower build)
-- - ef_construction=64: candidate list size (higher = better quality)
-- - Optimal for 70%+ data with embeddings

-- Expected Performance:
-- - FTS keyword search: 10-50ms (was 500ms+ with ILIKE)
-- - Vector semantic search: 20-100ms (was 1000ms+ without index)
