-- Create a function to update embeddings that bypasses triggers
-- This function sets updated_by explicitly and uses SECURITY DEFINER
-- to run with the privileges of the function owner (bypassing auth.uid())

CREATE OR REPLACE FUNCTION update_embedding_backfill(
    p_table_name text,
    p_record_id uuid,
    p_embedding vector(768),
    p_updated_by uuid
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER  -- Run with function owner privileges
AS $$
BEGIN
    -- Dynamically update the specified table
    EXECUTE format(
        'UPDATE %I SET embedding = $1, updated_at = NOW(), updated_by = $2 WHERE id = $3',
        p_table_name
    )
    USING p_embedding, p_updated_by, p_record_id;
END;
$$;

-- Grant execute permission to service_role
GRANT EXECUTE ON FUNCTION update_embedding_backfill(text, uuid, vector, uuid) TO service_role;
GRANT EXECUTE ON FUNCTION update_embedding_backfill(text, uuid, vector, uuid) TO authenticated;

-- Test the function
-- SELECT update_embedding_backfill('organizations', '8b9e419c-6c8e-4d57-a201-9b7bb8b237dd', array_fill(0.0, ARRAY[768])::vector, '79355ae7-3b97-4f94-95bc-060a403788d4');
