-- Test the RPC function with a document that actually exists

DO $$
DECLARE
    test_doc_id uuid;
    test_created_by uuid;
BEGIN
    -- Get a document that definitely exists
    SELECT id, created_by INTO test_doc_id, test_created_by
    FROM documents
    WHERE is_deleted = false
    LIMIT 1;

    IF test_doc_id IS NOT NULL THEN
        RAISE NOTICE 'Testing with document ID: %', test_doc_id;

        -- Update using RPC function
        PERFORM update_embedding_backfill(
            'documents',
            test_doc_id,
            array_fill(0.1, ARRAY[768])::vector,
            test_created_by
        );

        RAISE NOTICE '✅ RPC function works!';
    ELSE
        RAISE NOTICE '❌ No documents found';
    END IF;
END $$;

-- Verify the update worked
SELECT id, name, embedding IS NOT NULL as has_embedding
FROM documents
WHERE embedding IS NOT NULL
ORDER BY updated_at DESC
LIMIT 5;

-- Count how many documents still need embeddings
SELECT COUNT(*) as documents_needing_embeddings
FROM documents
WHERE embedding IS NULL
AND is_deleted = false;
