-- SAFE Fix RLS Policy for Projects Table
-- This ADDS organization-based policies WITHOUT removing auth protection
-- IMPORTANT: This is additive - we keep authenticated user protection

-- ============================================
-- STRATEGY: ADD organization-aware policies alongside existing ones
-- This creates PERMISSIVE (OR) policies that expand access rather than restrict
-- ============================================

-- ============================================
-- 1. ADD INSERT policy for organization members (PERMISSIVE = OR logic)
-- ============================================
-- This policy will be evaluated WITH the existing auth policy
-- User can insert if: (authenticated) OR (org member) = More permissive

-- Drop if exists, then create (PostgreSQL doesn't support IF NOT EXISTS for policies)
DROP POLICY IF EXISTS "Organization members can create projects" ON projects;

CREATE POLICY "Organization members can create projects"
ON projects
FOR INSERT
TO authenticated
WITH CHECK (
  -- Allow if user is a member of the organization
  EXISTS (
    SELECT 1
    FROM organization_members
    WHERE organization_id = NEW.organization_id
    AND user_id = auth.uid()
    AND status = 'active'
    AND is_deleted = false
  )
);

-- ============================================
-- 2. ADD SELECT policy for organization members
-- ============================================
DROP POLICY IF EXISTS "Organization members can view projects" ON projects;

CREATE POLICY "Organization members can view projects"
ON projects
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1
    FROM organization_members
    WHERE organization_id = projects.organization_id
    AND user_id = auth.uid()
    AND status = 'active'
    AND is_deleted = false
  )
  OR created_by = auth.uid()
);

-- ============================================
-- 3. ADD UPDATE policy for organization members
-- ============================================
DROP POLICY IF EXISTS "Organization members can update projects" ON projects;

CREATE POLICY "Organization members can update projects"
ON projects
FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1
    FROM organization_members
    WHERE organization_id = projects.organization_id
    AND user_id = auth.uid()
    AND status = 'active'
    AND is_deleted = false
  )
  OR created_by = auth.uid()
)
WITH CHECK (
  EXISTS (
    SELECT 1
    FROM organization_members
    WHERE organization_id = NEW.organization_id
    AND user_id = auth.uid()
    AND status = 'active'
    AND is_deleted = false
  )
  OR auth.uid() = NEW.created_by
);

-- ============================================
-- 4. ADD DELETE policy for organization members
-- ============================================
DROP POLICY IF EXISTS "Organization members can delete projects" ON projects;

CREATE POLICY "Organization members can delete projects"
ON projects
FOR DELETE
TO authenticated
USING (
  EXISTS (
    SELECT 1
    FROM organization_members
    WHERE organization_id = projects.organization_id
    AND user_id = auth.uid()
    AND status = 'active'
    AND is_deleted = false
  )
  OR created_by = auth.uid()
);

-- ============================================
-- 5. OPTIONAL: Only if you want to consolidate, DROP old restrictive policies
-- ============================================
-- UNCOMMENT THESE ONLY IF THE ABOVE POLICIES DON'T WORK
-- AND you've verified the existing policies are too restrictive

-- DROP POLICY IF EXISTS "Enable insert for authenticated users only" ON projects;
-- DROP POLICY IF EXISTS "Users can insert projects" ON projects;
-- DROP POLICY IF EXISTS "Users can update own projects" ON projects;
-- DROP POLICY IF EXISTS "Users can view own projects" ON projects;
-- DROP POLICY IF EXISTS "Users can delete own projects" ON projects;

-- ============================================
-- 6. VERIFICATION QUERY
-- ============================================
-- Run this to see all policies:
SELECT
    policyname,
    cmd as operation,
    permissive,
    CASE
        WHEN permissive = 'PERMISSIVE' THEN '✅ OR logic (expands access)'
        ELSE '⚠️ RESTRICTIVE (AND logic - limits access)'
    END as policy_type,
    roles,
    substring(qual::text, 1, 80) as using_clause,
    substring(with_check::text, 1, 80) as with_check_clause
FROM pg_policies
WHERE tablename = 'projects'
ORDER BY cmd, policyname;

-- ============================================
-- NOTES
-- ============================================
/*
PERMISSIVE vs RESTRICTIVE Policies:
- PERMISSIVE (default): Policies are combined with OR logic
  - User passes if ANY permissive policy passes
  - Example: "auth only" OR "org member" = More access

- RESTRICTIVE: Policies are combined with AND logic
  - User must pass ALL restrictive policies
  - Used to create mandatory security checks

Our strategy: Use PERMISSIVE policies to expand access safely
- Keep existing "authenticated users only" protection
- Add new "organization members" check
- Result: Users can create projects if they're authenticated OR org members
*/

-- ============================================
-- TESTING
-- ============================================
-- Test 1: Check if user is org member
SELECT
    EXISTS (
        SELECT 1
        FROM organization_members
        WHERE organization_id = 'cdbbd19b-65af-4dc0-a76e-bba24a550159'
        AND user_id = '79355ae7-3b97-4f94-95bc-060a403788d4'
        AND status = 'active'
        AND is_deleted = false
    ) as is_org_member;

-- Test 2: Simulate project creation check
-- This simulates what the RLS policy will check
SELECT
    'User can create project' as test,
    EXISTS (
        SELECT 1
        FROM organization_members
        WHERE organization_id = 'cdbbd19b-65af-4dc0-a76e-bba24a550159'
        AND user_id = '79355ae7-3b97-4f94-95bc-060a403788d4'
        AND status = 'active'
        AND is_deleted = false
    ) as policy_check_result;

-- ============================================
-- GRANT PERMISSIONS (if needed)
-- ============================================
GRANT SELECT, INSERT, UPDATE, DELETE ON projects TO authenticated;
GRANT SELECT ON organization_members TO authenticated;
