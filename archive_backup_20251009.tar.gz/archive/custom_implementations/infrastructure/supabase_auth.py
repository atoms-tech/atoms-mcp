"""Backward-compatible shim for shared SupabaseAuthAdapter."""

from authkit_client import SupabaseAuthAdapter

__all__ = ["SupabaseAuthAdapter"]
