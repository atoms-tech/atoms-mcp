-- ============================================
-- FIX RLS POLICIES FOR ALL CORE TABLES
-- Ensures service role can read/write for backfill operations
-- Also fixes organization member policies for project creation
-- ============================================

-- ============================================
-- 1. ORGANIZATIONS TABLE
-- ============================================

-- Grant permissions to service_role (for backfill script)
GRANT ALL ON organizations TO service_role;

-- Ensure authenticated users can read orgs they're members of
DROP POLICY IF EXISTS "Organization members can view organizations" ON organizations;

CREATE POLICY "Organization members can view organizations"
ON organizations
FOR SELECT
TO authenticated
USING (
  id IN (
    SELECT organization_id
    FROM organization_members
    WHERE user_id = auth.uid()
    AND status = 'active'
    AND is_deleted = false
  )
);

-- Allow creating organizations
DROP POLICY IF EXISTS "Users can create organizations" ON organizations;

CREATE POLICY "Users can create organizations"
ON organizations
FOR INSERT
TO authenticated
WITH CHECK (true);  -- Any authenticated user can create org

-- Allow updating own organizations
DROP POLICY IF EXISTS "Organization members can update organizations" ON organizations;

CREATE POLICY "Organization members can update organizations"
ON organizations
FOR UPDATE
TO authenticated
USING (
  id IN (
    SELECT organization_id
    FROM organization_members
    WHERE user_id = auth.uid()
    AND role IN ('owner', 'admin')
    AND status = 'active'
    AND is_deleted = false
  )
);

-- ============================================
-- 2. PROJECTS TABLE
-- ============================================

-- Grant permissions to service_role (for backfill script)
GRANT ALL ON projects TO service_role;

-- Organization members can create projects
DROP POLICY IF EXISTS "Organization members can create projects" ON projects;

CREATE POLICY "Organization members can create projects"
ON projects
FOR INSERT
TO authenticated
WITH CHECK (
  NEW.organization_id IN (
    SELECT organization_id
    FROM organization_members
    WHERE user_id = auth.uid()
    AND status = 'active'
    AND is_deleted = false
  )
);

-- Organization members can view projects
DROP POLICY IF EXISTS "Organization members can view projects" ON projects;

CREATE POLICY "Organization members can view projects"
ON projects
FOR SELECT
TO authenticated
USING (
  organization_id IN (
    SELECT organization_id
    FROM organization_members
    WHERE user_id = auth.uid()
    AND status = 'active'
    AND is_deleted = false
  )
  OR created_by = auth.uid()
);

-- Organization members can update projects
DROP POLICY IF EXISTS "Organization members can update projects" ON projects;

CREATE POLICY "Organization members can update projects"
ON projects
FOR UPDATE
TO authenticated
USING (
  organization_id IN (
    SELECT organization_id
    FROM organization_members
    WHERE user_id = auth.uid()
    AND status = 'active'
    AND is_deleted = false
  )
  OR created_by = auth.uid()
)
WITH CHECK (
  NEW.organization_id IN (
    SELECT organization_id
    FROM organization_members
    WHERE user_id = auth.uid()
    AND status = 'active'
    AND is_deleted = false
  )
  OR auth.uid() = NEW.created_by
);

-- Organization members can delete projects
DROP POLICY IF EXISTS "Organization members can delete projects" ON projects;

CREATE POLICY "Organization members can delete projects"
ON projects
FOR DELETE
TO authenticated
USING (
  organization_id IN (
    SELECT organization_id
    FROM organization_members
    WHERE user_id = auth.uid()
    AND status = 'active'
    AND is_deleted = false
  )
  OR created_by = auth.uid()
);

-- ============================================
-- 3. DOCUMENTS TABLE
-- ============================================

-- Grant permissions to service_role (for backfill script)
GRANT ALL ON documents TO service_role;

-- Organization members can access documents in their projects
DROP POLICY IF EXISTS "Organization members can view documents" ON documents;

CREATE POLICY "Organization members can view documents"
ON documents
FOR SELECT
TO authenticated
USING (
  project_id IN (
    SELECT p.id
    FROM projects p
    JOIN organization_members om ON p.organization_id = om.organization_id
    WHERE om.user_id = auth.uid()
    AND om.status = 'active'
    AND om.is_deleted = false
  )
);

DROP POLICY IF EXISTS "Organization members can create documents" ON documents;

CREATE POLICY "Organization members can create documents"
ON documents
FOR INSERT
TO authenticated
WITH CHECK (
  NEW.project_id IN (
    SELECT p.id
    FROM projects p
    JOIN organization_members om ON p.organization_id = om.organization_id
    WHERE om.user_id = auth.uid()
    AND om.status = 'active'
    AND om.is_deleted = false
  )
);

DROP POLICY IF EXISTS "Organization members can update documents" ON documents;

CREATE POLICY "Organization members can update documents"
ON documents
FOR UPDATE
TO authenticated
USING (
  project_id IN (
    SELECT p.id
    FROM projects p
    JOIN organization_members om ON p.organization_id = om.organization_id
    WHERE om.user_id = auth.uid()
    AND om.status = 'active'
    AND om.is_deleted = false
  )
);

-- ============================================
-- 4. REQUIREMENTS TABLE
-- ============================================

-- Grant permissions to service_role (for backfill script)
GRANT ALL ON requirements TO service_role;

-- Organization members can access requirements
DROP POLICY IF EXISTS "Organization members can view requirements" ON requirements;

CREATE POLICY "Organization members can view requirements"
ON requirements
FOR SELECT
TO authenticated
USING (
  document_id IN (
    SELECT d.id
    FROM documents d
    JOIN projects p ON d.project_id = p.id
    JOIN organization_members om ON p.organization_id = om.organization_id
    WHERE om.user_id = auth.uid()
    AND om.status = 'active'
    AND om.is_deleted = false
  )
);

DROP POLICY IF EXISTS "Organization members can create requirements" ON requirements;

CREATE POLICY "Organization members can create requirements"
ON requirements
FOR INSERT
TO authenticated
WITH CHECK (
  NEW.document_id IN (
    SELECT d.id
    FROM documents d
    JOIN projects p ON d.project_id = p.id
    JOIN organization_members om ON p.organization_id = om.organization_id
    WHERE om.user_id = auth.uid()
    AND om.status = 'active'
    AND om.is_deleted = false
  )
);

DROP POLICY IF EXISTS "Organization members can update requirements" ON requirements;

CREATE POLICY "Organization members can update requirements"
ON requirements
FOR UPDATE
TO authenticated
USING (
  document_id IN (
    SELECT d.id
    FROM documents d
    JOIN projects p ON d.project_id = p.id
    JOIN organization_members om ON p.organization_id = om.organization_id
    WHERE om.user_id = auth.uid()
    AND om.status = 'active'
    AND om.is_deleted = false
  )
);

-- ============================================
-- 5. ORGANIZATION_MEMBERS TABLE
-- ============================================

-- Grant permissions to service_role
GRANT ALL ON organization_members TO service_role;

-- Allow users to view members of orgs they belong to
DROP POLICY IF EXISTS "Organization members can view members" ON organization_members;

CREATE POLICY "Organization members can view members"
ON organization_members
FOR SELECT
TO authenticated
USING (
  organization_id IN (
    SELECT organization_id
    FROM organization_members
    WHERE user_id = auth.uid()
    AND status = 'active'
    AND is_deleted = false
  )
);

-- ============================================
-- 6. VERIFICATION QUERIES
-- ============================================

-- Check policies were created
SELECT
    '=== POLICIES CREATED ===' as section;

SELECT
    tablename,
    COUNT(*) as policy_count,
    string_agg(policyname, ', ' ORDER BY policyname) as policies
FROM pg_policies
WHERE tablename IN ('organizations', 'projects', 'documents', 'requirements', 'organization_members')
GROUP BY tablename
ORDER BY tablename;

-- Check service_role grants
SELECT
    '=== SERVICE ROLE GRANTS ===' as section;

SELECT
    tablename,
    string_agg(privilege_type, ', ' ORDER BY privilege_type) as privileges
FROM information_schema.table_privileges
WHERE grantee = 'service_role'
AND table_name IN ('organizations', 'projects', 'documents', 'requirements', 'organization_members')
GROUP BY tablename
ORDER BY tablename;

-- ============================================
-- NOTES
-- ============================================
/*
This script:
1. Grants ALL privileges to service_role for backfill operations
2. Creates organization-aware RLS policies for authenticated users
3. Uses PERMISSIVE (OR logic) policies - safe to add alongside existing
4. Allows any authenticated user to create organizations
5. Requires organization membership for all other operations

After running this script:
- Backfill script should work (service_role has full access)
- MCP users can create projects in orgs they're members of
- RLS properly enforces organization boundaries
*/
