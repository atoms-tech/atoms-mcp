-- Fix RLS policies for mcp_sessions table to allow service role access
-- Run this in Supabase SQL Editor if you're getting "permission denied" errors

-- Verify service role can bypass RLS
SELECT current_setting('role');

-- Drop all existing policies
DROP POLICY IF EXISTS "Users can view own sessions" ON mcp_sessions;
DROP POLICY IF EXISTS "Users can create own sessions" ON mcp_sessions;
DROP POLICY IF EXISTS "Users can update own sessions" ON mcp_sessions;
DROP POLICY IF EXISTS "Users can delete own sessions" ON mcp_sessions;
DROP POLICY IF EXISTS "Service role can manage all sessions" ON mcp_sessions;
DROP POLICY IF EXISTS "Anonymous users can create sessions" ON mcp_sessions;

-- Create simplified policies that explicitly allow service_role

-- Policy: Service role has full access (bypasses user_id check)
CREATE POLICY "Service role full access"
    ON mcp_sessions
    FOR ALL
    USING (auth.jwt() ->> 'role' = 'service_role')
    WITH CHECK (auth.jwt() ->> 'role' = 'service_role');

-- Policy: Allow anonymous session creation during OAuth flow
CREATE POLICY "Anonymous session creation"
    ON mcp_sessions
    FOR INSERT
    WITH CHECK (true);

-- Policy: Users can view their own sessions
CREATE POLICY "Users view own sessions"
    ON mcp_sessions
    FOR SELECT
    USING (auth.uid() = user_id);

-- Policy: Users can update their own sessions
CREATE POLICY "Users update own sessions"
    ON mcp_sessions
    FOR UPDATE
    USING (auth.uid() = user_id)
    WITH CHECK (auth.uid() = user_id);

-- Policy: Users can delete their own sessions
CREATE POLICY "Users delete own sessions"
    ON mcp_sessions
    FOR DELETE
    USING (auth.uid() = user_id);

-- Verify policies
SELECT policyname, cmd, permissive, roles
FROM pg_policies
WHERE tablename = 'mcp_sessions'
ORDER BY policyname;
