-- Add standard JWT claims to Supabase auth configuration
-- This fixes the 401 issue where middleware can't find user_id in AuthKit tokens
--
-- Apply this via Supabase Dashboard → Authentication → Settings → Custom Claims
-- Or via SQL if you have a custom claims function

-- Your current JWT claims:
-- {
--   "role": "authenticated",
--   "user_role": "{{organization_membership.role}}"
-- }

-- Should be updated to include standard OAuth/JWT claims:
-- {
--   "sub": "{{.User.ID}}",                    -- Standard JWT subject (user ID) - REQUIRED
--   "email": "{{.User.Email}}",               -- User email
--   "role": "authenticated",                   -- Supabase role
--   "user_role": "{{organization_membership.role}}"  -- Your custom claim
-- }

-- HOW TO UPDATE:
-- 1. Go to Supabase Dashboard → Settings → Auth
-- 2. Find "Additional Claims" or "Custom Claims" section
-- 3. Update the JSON template to include:

/*
{
  "sub": "{{.User.ID}}",
  "email": "{{.User.Email}}",
  "role": "authenticated",
  "user_role": "{{organization_membership.role}}"
}
*/

-- Alternative: If using a custom claims SQL function, update it:

CREATE OR REPLACE FUNCTION auth.custom_access_token_hook(event jsonb)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
AS $$
DECLARE
    claims jsonb;
    user_id uuid;
BEGIN
    user_id := (event->>'user_id')::uuid;

    -- Build custom claims
    claims := jsonb_build_object(
        'sub', user_id,                          -- Standard JWT subject - REQUIRED
        'email', (event->'claims'->>'email'),    -- User email
        'role', (event->'claims'->>'role'),      -- Supabase role
        'user_role', (
            SELECT role FROM organization_members
            WHERE user_id = user_id
            LIMIT 1
        )
    );

    RETURN claims;
END;
$$;

-- Then enable the hook in dashboard or via:
-- Dashboard → Authentication → Hooks → Custom Access Token

COMMENT ON FUNCTION auth.custom_access_token_hook IS
'Adds standard JWT claims (sub, email) required by MCP middleware';
