-- ============================================================================
-- COMPREHENSIVE FIX SQL SCRIPT FOR CRUD ISSUES
-- Generated: 2025-10-06
-- Environment: Main Branch (Commit 6412be9)
-- ============================================================================

-- ============================================================================
-- ROOT CAUSES IDENTIFIED:
-- ============================================================================
--
-- 1. PROJECT CREATE (🟥 CRITICAL):
--    - handle_new_project trigger inserts into project_members
--    - RLS policy on project_members requires user to already be owner/admin
--    - Chicken-and-egg problem: can't insert member record without being member
--    - FIX: Make handle_new_project SECURITY DEFINER to bypass RLS
--
-- 2. ORGANIZATION UPDATE (🟥):
--    - RLS policy only allows created_by to update
--    - Organization admins/owners should be able to update
--    - FIX: Update RLS policy to check organization_members role
--
-- 3. PROJECT UPDATE (🟨):
--    - RLS policy only allows created_by to update
--    - Organization members and project members should be able to update
--    - FIX: Update RLS policy to check both org and project membership
--
-- 4. DOCUMENT UPDATE (🟥):
--    - RLS policy only allows created_by to update
--    - Project/org members should be able to update documents
--    - FIX: Update RLS policy to check project/org membership with role-based access
--
-- 5. PROJECT DUPLICATION (🟥):
--    - Same issue as Project Create - RLS on project_members
--    - FIX: Fixed by making handle_new_project SECURITY DEFINER
--
-- 6. DOCUMENT DUPLICATION (🟥):
--    - Blocks aren't transferred - likely application logic issue
--    - But ensure RLS doesn't prevent block creation for project members
--    - FIX: Verify blocks RLS policy is correct (already seems OK)
--
-- ============================================================================

BEGIN;

-- ============================================================================
-- FIX 1: PROJECT CREATION - Make handle_new_project SECURITY DEFINER
-- ============================================================================
-- This allows the trigger to bypass RLS when inserting the project owner
-- into project_members table

DROP TRIGGER IF EXISTS after_project_insert ON projects;
DROP FUNCTION IF EXISTS handle_new_project();

CREATE OR REPLACE FUNCTION public.handle_new_project()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER  -- THIS IS THE KEY FIX - bypasses RLS
SET search_path TO 'public', 'pg_temp'
AS $function$
BEGIN
  -- Insert the project creator as a project member with the 'owner' role
  INSERT INTO public.project_members (org_id, project_id, user_id, role, status)
  VALUES (
    NEW.organization_id,
    NEW.id,
    NEW.created_by,
    'owner'::project_role,
    'active'::user_status
  )
  ON CONFLICT (project_id, user_id)
  DO UPDATE SET
    role = 'owner'::project_role,
    status = 'active'::user_status,
    is_deleted = false,
    updated_at = timezone('utc'::text, now());

  RETURN NEW;
END;
$function$;

CREATE TRIGGER after_project_insert
  AFTER INSERT ON public.projects
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_project();

COMMENT ON FUNCTION handle_new_project() IS
  'Automatically adds project creator as owner. SECURITY DEFINER to bypass RLS.';


-- ============================================================================
-- FIX 2: ORGANIZATION UPDATE - Allow org admins/owners to update
-- ============================================================================

DROP POLICY IF EXISTS "Users can update organizations" ON organizations;

CREATE POLICY "Users can update organizations"
ON organizations
FOR UPDATE
TO public
USING (
  -- Creator can update
  created_by = auth.uid()
  OR
  -- Organization owners and admins can update
  id IN (
    SELECT organization_id
    FROM organization_members
    WHERE user_id = auth.uid()
      AND role IN ('owner', 'admin')
      AND status = 'active'
      AND is_deleted = false
  )
)
WITH CHECK (
  -- Same check for the updated values
  created_by = auth.uid()
  OR
  id IN (
    SELECT organization_id
    FROM organization_members
    WHERE user_id = auth.uid()
      AND role IN ('owner', 'admin')
      AND status = 'active'
      AND is_deleted = false
  )
);


-- ============================================================================
-- FIX 3: PROJECT UPDATE - Allow org members and project members to update
-- ============================================================================

DROP POLICY IF EXISTS "Users can update projects" ON projects;

CREATE POLICY "Users can update projects"
ON projects
FOR UPDATE
TO public
USING (
  -- Project creator can update
  created_by = auth.uid()
  OR
  -- Organization owners/admins can update
  organization_id IN (
    SELECT organization_id
    FROM organization_members
    WHERE user_id = auth.uid()
      AND role IN ('owner', 'admin')
      AND status = 'active'
      AND is_deleted = false
  )
  OR
  -- Project owners/admins/maintainers/editors can update
  id IN (
    SELECT project_id
    FROM project_members
    WHERE user_id = auth.uid()
      AND role IN ('owner', 'admin', 'maintainer', 'editor')
      AND status = 'active'
      AND is_deleted = false
  )
)
WITH CHECK (
  -- Same check for updated values
  created_by = auth.uid()
  OR
  organization_id IN (
    SELECT organization_id
    FROM organization_members
    WHERE user_id = auth.uid()
      AND role IN ('owner', 'admin')
      AND status = 'active'
      AND is_deleted = false
  )
  OR
  id IN (
    SELECT project_id
    FROM project_members
    WHERE user_id = auth.uid()
      AND role IN ('owner', 'admin', 'maintainer', 'editor')
      AND status = 'active'
      AND is_deleted = false
  )
);


-- ============================================================================
-- FIX 4: DOCUMENT UPDATE - Allow project/org members to update
-- ============================================================================

DROP POLICY IF EXISTS "Users can update documents" ON documents;

CREATE POLICY "Users can update documents"
ON documents
FOR UPDATE
TO authenticated
USING (
  -- Document creator can update
  created_by = auth.uid()
  OR
  -- Project members with editor/maintainer/admin/owner role can update
  project_id IN (
    SELECT pm.project_id
    FROM project_members pm
    WHERE pm.user_id = auth.uid()
      AND pm.role IN ('owner', 'admin', 'maintainer', 'editor')
      AND pm.status = 'active'
      AND pm.is_deleted = false
  )
  OR
  -- Organization admins/owners can update
  project_id IN (
    SELECT p.id
    FROM projects p
    JOIN organization_members om ON om.organization_id = p.organization_id
    WHERE om.user_id = auth.uid()
      AND om.role IN ('owner', 'admin')
      AND om.status = 'active'
      AND om.is_deleted = false
  )
)
WITH CHECK (
  -- Same check for updated values
  created_by = auth.uid()
  OR
  project_id IN (
    SELECT pm.project_id
    FROM project_members pm
    WHERE pm.user_id = auth.uid()
      AND pm.role IN ('owner', 'admin', 'maintainer', 'editor')
      AND pm.status = 'active'
      AND pm.is_deleted = false
  )
  OR
  project_id IN (
    SELECT p.id
    FROM projects p
    JOIN organization_members om ON om.organization_id = p.organization_id
    WHERE om.user_id = auth.uid()
      AND om.role IN ('owner', 'admin')
      AND om.status = 'active'
      AND om.is_deleted = false
  )
);


-- ============================================================================
-- FIX 5: PROJECT MEMBERS - Add INSERT policy for project creation
-- ============================================================================
-- This ensures that when a project is created, the trigger can insert
-- the owner record. The SECURITY DEFINER on the trigger should handle this,
-- but we also add a WITH CHECK policy to allow inserts for new projects

-- Drop all existing policies on project_members
DROP POLICY IF EXISTS "Project owners and admins can manage members" ON project_members;
DROP POLICY IF EXISTS "Users can view their project memberships" ON project_members;

-- Split into separate policies for better control
CREATE POLICY "Users can view their project memberships"
ON project_members
FOR SELECT
TO authenticated
USING (
  user_id = auth.uid()
  OR
  is_project_owner_or_admin(project_id, auth.uid())
  OR
  project_id IN (
    SELECT p.id
    FROM projects p
    JOIN organization_members om ON om.organization_id = p.organization_id
    WHERE om.user_id = auth.uid()
      AND om.status = 'active'
      AND om.is_deleted = false
  )
);

CREATE POLICY "Project owners and org admins can insert members"
ON project_members
FOR INSERT
TO authenticated
WITH CHECK (
  -- Project owners/admins can add members
  is_project_owner_or_admin(project_id, auth.uid())
  OR
  -- Organization owners/admins can add members to their org's projects
  org_id IN (
    SELECT organization_id
    FROM organization_members
    WHERE user_id = auth.uid()
      AND role IN ('owner', 'admin')
      AND status = 'active'
      AND is_deleted = false
  )
  OR
  -- Allow project creators to be added as owners (for handle_new_project trigger)
  (user_id = auth.uid() AND role = 'owner')
);

CREATE POLICY "Project owners and admins can update members"
ON project_members
FOR UPDATE
TO authenticated
USING (
  is_project_owner_or_admin(project_id, auth.uid())
  OR
  org_id IN (
    SELECT organization_id
    FROM organization_members
    WHERE user_id = auth.uid()
      AND role IN ('owner', 'admin')
      AND status = 'active'
      AND is_deleted = false
  )
)
WITH CHECK (
  is_project_owner_or_admin(project_id, auth.uid())
  OR
  org_id IN (
    SELECT organization_id
    FROM organization_members
    WHERE user_id = auth.uid()
      AND role IN ('owner', 'admin')
      AND status = 'active'
      AND is_deleted = false
  )
);

CREATE POLICY "Project owners and admins can delete members"
ON project_members
FOR DELETE
TO authenticated
USING (
  is_project_owner_or_admin(project_id, auth.uid())
  OR
  org_id IN (
    SELECT organization_id
    FROM organization_members
    WHERE user_id = auth.uid()
      AND role IN ('owner', 'admin')
      AND status = 'active'
      AND is_deleted = false
  )
  OR
  -- Users can remove themselves
  user_id = auth.uid()
);


-- ============================================================================
-- FIX 6: ORGANIZATION DELETE - Allow org owners to delete
-- ============================================================================

DROP POLICY IF EXISTS "Users can delete organizations" ON organizations;

CREATE POLICY "Users can delete organizations"
ON organizations
FOR DELETE
TO public
USING (
  -- Creator can delete
  created_by = auth.uid()
  OR
  -- Organization owners can delete
  id IN (
    SELECT organization_id
    FROM organization_members
    WHERE user_id = auth.uid()
      AND role = 'owner'
      AND status = 'active'
      AND is_deleted = false
  )
);


-- ============================================================================
-- VERIFICATION QUERIES
-- ============================================================================

-- These can be run after applying the fixes to verify everything works

-- Check if RLS policies were created correctly
SELECT
    schemaname,
    tablename,
    policyname,
    cmd,
    permissive
FROM pg_policies
WHERE tablename IN ('organizations', 'projects', 'documents', 'project_members')
ORDER BY tablename, cmd, policyname;

-- Check if trigger function is SECURITY DEFINER
SELECT
    p.proname,
    p.prosecdef,
    pg_get_functiondef(p.oid)
FROM pg_proc p
WHERE p.proname = 'handle_new_project';

COMMIT;

-- ============================================================================
-- NOTES FOR APPLICATION TEAM:
-- ============================================================================
--
-- 1. ORGANIZATION CREATE (🟨):
--    - Database is working correctly
--    - UI needs to refresh after creation or use optimistic updates
--
-- 2. ORGANIZATION UPDATE (✅ FIXED):
--    - Edit permissions now respect org admin/owner roles
--    - Frontend should check user role before showing edit button
--
-- 3. ORGANIZATION DELETE (🟥):
--    - Database policy allows owners to delete
--    - Frontend needs to implement delete UI
--
-- 4. PROJECT CREATE (✅ FIXED):
--    - RLS policy issue resolved with SECURITY DEFINER trigger
--    - Should now work for all organization members
--
-- 5. PROJECT READ (🟨):
--    - Policy looks correct
--    - If still having issues, check organization_members table
--    - Ensure users are properly added to organizations
--
-- 6. PROJECT UPDATE (✅ FIXED):
--    - Now allows org admins and project editors to update
--    - UI should refresh after update
--
-- 7. PROJECT DELETE (🟩):
--    - Already working
--
-- 8. PROJECT DUPLICATION (✅ FIXED):
--    - Fixed by SECURITY DEFINER on handle_new_project
--
-- 9. DOCUMENT CREATE (🟩):
--    - Already working
--
-- 10. DOCUMENT READ (🟩):
--     - Already working
--
-- 11. DOCUMENT UPDATE (✅ FIXED):
--     - Now allows project members and org admins to update
--     - UI should show update permissions based on role
--
-- 12. DOCUMENT DELETE (🟩):
--     - Already working
--
-- 13. DOCUMENT DUPLICATION (🟥):
--     - Database RLS should allow block creation for project members
--     - Check application logic for block duplication
--     - May need to ensure blocks are created with correct document_id
--     - Consider adding a backend endpoint that handles the full duplication
--       process in a transaction
--
-- ============================================================================
