-- ============================================================================
-- RLS Fix - Step by Step (Run each section separately)
-- ============================================================================

-- ============================================================================
-- STEP 1: Fix project_members RLS
-- ============================================================================
-- Run this first, then verify projects can be created

DROP POLICY IF EXISTS "Project owners and admins can manage members" ON project_members CASCADE;

CREATE POLICY "Project owners and admins can manage members"
ON project_members
FOR ALL
USING (is_project_owner_or_admin(project_id, auth.uid()))
WITH CHECK (
    is_project_owner_or_admin(project_id, auth.uid())
    OR NOT EXISTS (
        SELECT 1 FROM project_members pm
        WHERE pm.project_id = project_members.project_id
    )
);

-- Test: Try creating a project via MCP

-- ============================================================================
-- STEP 2: Add test_req RLS Policies
-- ============================================================================
-- Run after project_members fix

-- Drop existing
DROP POLICY IF EXISTS "Org members can view test_req" ON test_req CASCADE;
DROP POLICY IF EXISTS "Org members can create test_req" ON test_req CASCADE;
DROP POLICY IF EXISTS "Org members can update test_req" ON test_req CASCADE;
DROP POLICY IF EXISTS "Org members can delete test_req" ON test_req CASCADE;

-- View policy
CREATE POLICY "Users can view tests"
ON test_req
FOR SELECT
USING (
    project_id IN (
        SELECT p.id FROM projects p
        WHERE p.organization_id IN (
            SELECT organization_id FROM organization_members
            WHERE user_id = auth.uid() AND status = 'active'::user_status
        )
        OR p.created_by = auth.uid()
    )
);

-- Create policy
CREATE POLICY "Users can create tests"
ON test_req
FOR INSERT
WITH CHECK (
    project_id IN (
        SELECT p.id FROM projects p
        WHERE p.organization_id IN (
            SELECT organization_id FROM organization_members
            WHERE user_id = auth.uid() AND status = 'active'::user_status
        )
        OR p.created_by = auth.uid()
    )
);

-- Update policy
CREATE POLICY "Users can update tests"
ON test_req
FOR UPDATE
USING (created_by = auth.uid());

-- Delete policy
CREATE POLICY "Users can delete tests"
ON test_req
FOR DELETE
USING (created_by = auth.uid());

-- Test: Try listing/creating test entities via MCP

-- ============================================================================
-- STEP 3: Fix trace_links RLS
-- ============================================================================
-- Run after test_req policies added

DROP POLICY IF EXISTS "Users can view trace links they have access to" ON trace_links CASCADE;

CREATE POLICY "Users can manage trace links"
ON trace_links
FOR ALL
USING (
    EXISTS (
        SELECT 1 FROM project_members pm
        JOIN documents d ON d.project_id = pm.project_id
        WHERE pm.user_id = auth.uid()
        AND pm.status = 'active'::user_status
        AND (
            (trace_links.source_type = 'document'::entity_type AND trace_links.source_id = d.id)
            OR (trace_links.target_type = 'document'::entity_type AND trace_links.target_id = d.id)
            OR EXISTS (
                SELECT 1 FROM requirements r
                WHERE r.document_id = d.id
                AND (
                    (trace_links.source_type = 'requirement'::entity_type AND trace_links.source_id = r.id)
                    OR (trace_links.target_type = 'requirement'::entity_type AND trace_links.target_id = r.id)
                )
            )
        )
    )
)
WITH CHECK (
    EXISTS (
        SELECT 1 FROM project_members pm
        JOIN documents d ON d.project_id = pm.project_id
        WHERE pm.user_id = auth.uid()
        AND pm.status = 'active'::user_status
        AND (
            (source_type = 'document'::entity_type AND source_id = d.id)
            OR (target_type = 'document'::entity_type AND target_id = d.id)
            OR EXISTS (
                SELECT 1 FROM requirements r
                WHERE r.document_id = d.id
                AND (
                    (source_type = 'requirement'::entity_type AND source_id = r.id)
                    OR (target_type = 'requirement'::entity_type AND target_id = r.id)
                )
            )
        )
    )
);

-- Test: Try creating trace links via MCP
