-- ============================================================================
-- STEP 1: FIX INFINITE RECURSION IN RLS POLICIES
-- Must run FIRST before other fixes
-- ============================================================================

BEGIN;

-- Create bypass function for organization membership lookups
CREATE OR REPLACE FUNCTION public.get_user_organization_ids(p_user_id uuid)
RETURNS TABLE(organization_id uuid)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public, pg_temp
STABLE
AS $$
    SELECT organization_id
    FROM organization_members
    WHERE user_id = p_user_id
      AND status = 'active'
      AND is_deleted = false;
$$;

GRANT EXECUTE ON FUNCTION public.get_user_organization_ids(uuid) TO authenticated, anon, public;

-- Create bypass function for super admin checks
CREATE OR REPLACE FUNCTION public.is_super_admin(p_user_id uuid)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public, pg_temp
STABLE
AS $$
    SELECT EXISTS (
        SELECT 1
        FROM user_roles
        WHERE user_id = p_user_id
          AND admin_role = 'super_admin'
    );
$$;

GRANT EXECUTE ON FUNCTION public.is_super_admin(uuid) TO authenticated, anon, public;

-- Fix organization_members policy (was recursive)
DROP POLICY IF EXISTS "Users can view org members" ON public.organization_members;

CREATE POLICY "Users can view org members"
ON public.organization_members FOR ALL
TO public
USING (
    organization_id IN (
        SELECT get_user_organization_ids((SELECT auth.uid()))
    )
);

-- Fix user_roles policies (were recursive)
DROP POLICY IF EXISTS "Only super admins can update user roles" ON public.user_roles;
DROP POLICY IF EXISTS "Only super admins can create user roles" ON public.user_roles;

CREATE POLICY "Only super admins can update user roles"
ON public.user_roles FOR ALL
TO public
USING (is_super_admin((SELECT auth.uid())));

CREATE POLICY "Only super admins can create user roles"
ON public.user_roles FOR ALL
TO public
WITH CHECK (is_super_admin((SELECT auth.uid())));

-- Fix organization_invitations (had wrong WHERE clause)
DROP POLICY IF EXISTS "Owners and admins can manage invitations" ON public.organization_invitations;

CREATE POLICY "Owners and admins can manage invitations"
ON public.organization_invitations FOR ALL
TO public
USING (
    EXISTS (
        SELECT 1
        FROM organization_members member
        WHERE member.organization_id = organization_invitations.organization_id
          AND member.user_id = (SELECT auth.uid())
          AND member.role IN ('owner', 'admin')
          AND member.status = 'active'
    )
);

COMMIT;
