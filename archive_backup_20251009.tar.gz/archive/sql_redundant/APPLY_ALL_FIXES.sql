-- ============================================================================
-- ATOMS MCP - Apply All Database Fixes
-- ============================================================================
-- Run this in Supabase Dashboard → SQL Editor
-- These fixes resolve all test suite issues

-- ============================================================================
-- FIX 1: Organization Create/Update Trigger
-- ============================================================================
-- Issue: updated_by NOT NULL constraint fails on INSERT/UPDATE
-- Solution: Auto-set from auth.uid() or fallback to created_by

CREATE OR REPLACE FUNCTION handle_organization_audit_fields()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        -- On INSERT, set both created_by and updated_by
        NEW.created_by = COALESCE(NEW.created_by, auth.uid());
        NEW.updated_by = COALESCE(NEW.updated_by, auth.uid(), NEW.created_by);
    ELSIF TG_OP = 'UPDATE' THEN
        -- On UPDATE, use auth.uid() if available, otherwise preserve or use created_by
        NEW.updated_by = COALESCE(auth.uid(), OLD.updated_by, NEW.created_by, OLD.created_by);
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop old trigger if exists
DROP TRIGGER IF EXISTS tr_update_orgs ON organizations;
DROP TRIGGER IF EXISTS tr_organization_audit ON organizations;

-- Create new trigger for both INSERT and UPDATE
CREATE TRIGGER tr_organization_audit
    BEFORE INSERT OR UPDATE ON organizations
    FOR EACH ROW
    EXECUTE FUNCTION handle_organization_audit_fields();

COMMENT ON TRIGGER tr_organization_audit ON organizations IS
'Auto-sets created_by/updated_by fields on INSERT/UPDATE with fallback for service role';

-- ============================================================================
-- FIX 2: project_members RLS Policy
-- ============================================================================
-- Issue: Policy blocks auto_add_project_owner trigger from adding creator
-- Solution: Add WITH CHECK clause to allow first member insert

DROP POLICY IF EXISTS "Project owners and admins can manage members" ON project_members;

CREATE POLICY "Project owners and admins can manage members" ON project_members
FOR ALL
USING (
    is_project_owner_or_admin(project_id, auth.uid())
)
WITH CHECK (
    -- Allow if user is owner/admin OR this is the first member (auto-add trigger)
    is_project_owner_or_admin(project_id, auth.uid())
    OR NOT EXISTS (
        SELECT 1 FROM project_members pm
        WHERE pm.project_id = NEW.project_id
    )
);

-- ============================================================================
-- FIX 3: test_req Table RLS Policies
-- ============================================================================
-- Issue: TABLE_ACCESS_RESTRICTED when listing test entities
-- Solution: Add proper RLS policies matching requirements table pattern

-- Drop existing policies
DROP POLICY IF EXISTS "Org members can view test_req" ON test_req;
DROP POLICY IF EXISTS "Org members can create test_req" ON test_req;
DROP POLICY IF EXISTS "Org members can update test_req" ON test_req;
DROP POLICY IF EXISTS "Org members can delete test_req" ON test_req;
DROP POLICY IF EXISTS "Users can view tests" ON test_req;
DROP POLICY IF EXISTS "Users can create tests" ON test_req;
DROP POLICY IF EXISTS "Users can update tests" ON test_req;
DROP POLICY IF EXISTS "Users can delete tests" ON test_req;

-- Allow users to view tests in their accessible projects
CREATE POLICY "Users can view tests" ON test_req FOR SELECT
USING (
    project_id IN (
        SELECT p.id FROM projects p
        WHERE p.organization_id IN (
            SELECT organization_id FROM organization_members
            WHERE user_id = auth.uid() AND status = 'active'
        )
        OR p.created_by = auth.uid()
    )
);

-- Allow users to create tests in their projects
CREATE POLICY "Users can create tests" ON test_req FOR INSERT
WITH CHECK (
    project_id IN (
        SELECT p.id FROM projects p
        WHERE p.organization_id IN (
            SELECT organization_id FROM organization_members
            WHERE user_id = auth.uid() AND status = 'active'
        )
        OR p.created_by = auth.uid()
    )
);

-- Allow users to update their own tests
CREATE POLICY "Users can update tests" ON test_req FOR UPDATE
USING (created_by = auth.uid());

-- Allow users to delete their own tests
CREATE POLICY "Users can delete tests" ON test_req FOR DELETE
USING (created_by = auth.uid());

-- ============================================================================
-- FIX 3: RAG Semantic Search (Already handled in code)
-- ============================================================================
-- Issue: NoneType error when embeddings are NULL
-- Solution: Code already has empty embedding check (services/vector_search.py line 103)
-- RPC functions already have WHERE embedding IS NOT NULL

-- No SQL changes needed - just run embedding backfill if needed:
-- python scripts/backfill_embeddings.py

-- ============================================================================
-- VERIFICATION QUERIES
-- ============================================================================

-- Verify organization trigger exists
SELECT tgname, pg_get_triggerdef(oid) as definition
FROM pg_trigger
WHERE tgrelid = 'public.organizations'::regclass
AND tgname = 'tr_organization_audit';

-- Verify test_req policies exist
SELECT schemaname, tablename, policyname, cmd
FROM pg_policies
WHERE tablename = 'test_req'
ORDER BY policyname;

-- Check for NULL updated_by in organizations (should be none after trigger)
SELECT COUNT(*) as null_updated_by_count
FROM organizations
WHERE updated_by IS NULL;
