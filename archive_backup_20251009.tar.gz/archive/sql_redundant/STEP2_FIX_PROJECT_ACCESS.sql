-- ============================================================================
-- STEP 2: FIX PROJECT MEMBER ACCESS
-- Run AFTER step 1 (recursion fix)
-- Adds project_members checks to all resource policies
-- ============================================================================

BEGIN;

-- ============================================================================
-- FIX 1: project_members - Users must view their own memberships
-- ============================================================================

DROP POLICY IF EXISTS "Users can view their project memberships" ON public.project_members;

CREATE POLICY "Users can view their project memberships"
ON public.project_members FOR SELECT
TO authenticated
USING (
    (user_id = (SELECT auth.uid()))
    OR
    is_project_owner_or_admin(project_id, (SELECT auth.uid()))
);

-- ============================================================================
-- FIX 2: projects
-- ============================================================================

DROP POLICY IF EXISTS "Users can view projects" ON public.projects;

CREATE POLICY "Users can view projects"
ON public.projects FOR ALL
TO public
USING (
    (created_by = (SELECT auth.uid()))
    OR
    (organization_id IN (
        SELECT id FROM organizations
        WHERE created_by = (SELECT auth.uid())
    ))
    OR
    (organization_id IN (
        SELECT organization_id FROM organization_members
        WHERE user_id = (SELECT auth.uid())
        AND status = 'active'
        AND is_deleted = false
    ))
    OR
    (id IN (
        SELECT project_id FROM project_members
        WHERE user_id = (SELECT auth.uid())
        AND status = 'active'
        AND is_deleted = false
    ))
);

-- ============================================================================
-- FIX 3: documents
-- ============================================================================

DROP POLICY IF EXISTS "Users can view documents" ON public.documents;

CREATE POLICY "Users can view documents"
ON public.documents FOR ALL
TO authenticated
USING (
    (created_by = (SELECT auth.uid()))
    OR
    (project_id IN (
        SELECT id FROM projects
        WHERE created_by = (SELECT auth.uid())
    ))
    OR
    (project_id IN (
        SELECT p.id FROM projects p
        WHERE p.organization_id IN (
            SELECT organization_id FROM organization_members
            WHERE user_id = (SELECT auth.uid())
            AND status = 'active'
            AND is_deleted = false
        )
    ))
    OR
    (project_id IN (
        SELECT project_id FROM project_members
        WHERE user_id = (SELECT auth.uid())
        AND status = 'active'
        AND is_deleted = false
    ))
);

-- ============================================================================
-- FIX 4: blocks
-- ============================================================================

DROP POLICY IF EXISTS "Organization members can view blocks" ON public.blocks;
DROP POLICY IF EXISTS "Organization members can update blocks" ON public.blocks;
DROP POLICY IF EXISTS "Organization members can delete blocks" ON public.blocks;

CREATE POLICY "Organization members can view blocks"
ON public.blocks FOR ALL
TO public
USING (
    document_id IN (
        SELECT d.id FROM documents d
        JOIN projects p ON d.project_id = p.id
        WHERE
            (p.organization_id IN (
                SELECT organization_id FROM organization_members
                WHERE user_id = (SELECT auth.uid())
                AND status = 'active'
                AND is_deleted = false
            ))
            OR
            (p.id IN (
                SELECT project_id FROM project_members
                WHERE user_id = (SELECT auth.uid())
                AND status = 'active'
                AND is_deleted = false
            ))
    )
);

CREATE POLICY "Organization members can update blocks"
ON public.blocks FOR ALL
TO public
USING (
    document_id IN (
        SELECT d.id FROM documents d
        JOIN projects p ON d.project_id = p.id
        WHERE
            (p.organization_id IN (
                SELECT organization_id FROM organization_members
                WHERE user_id = (SELECT auth.uid())
                AND status = 'active'
                AND is_deleted = false
            ))
            OR
            (p.id IN (
                SELECT project_id FROM project_members
                WHERE user_id = (SELECT auth.uid())
                AND status = 'active'
                AND is_deleted = false
            ))
    )
);

CREATE POLICY "Organization members can delete blocks"
ON public.blocks FOR ALL
TO public
USING (
    document_id IN (
        SELECT d.id FROM documents d
        JOIN projects p ON d.project_id = p.id
        WHERE
            (p.organization_id IN (
                SELECT organization_id FROM organization_members
                WHERE user_id = (SELECT auth.uid())
                AND status = 'active'
                AND is_deleted = false
            ))
            OR
            (p.id IN (
                SELECT project_id FROM project_members
                WHERE user_id = (SELECT auth.uid())
                AND status = 'active'
                AND is_deleted = false
            ))
    )
);

-- ============================================================================
-- FIX 5: requirements
-- ============================================================================

DROP POLICY IF EXISTS "Organization members can view requirements" ON public.requirements;
DROP POLICY IF EXISTS "Organization members can update requirements" ON public.requirements;
DROP POLICY IF EXISTS "Organization members can delete requirements" ON public.requirements;

CREATE POLICY "Organization members can view requirements"
ON public.requirements FOR ALL
TO public
USING (
    document_id IN (
        SELECT d.id FROM documents d
        JOIN projects p ON d.project_id = p.id
        WHERE
            (p.organization_id IN (
                SELECT organization_id FROM organization_members
                WHERE user_id = (SELECT auth.uid())
                AND status = 'active'
                AND is_deleted = false
            ))
            OR
            (p.id IN (
                SELECT project_id FROM project_members
                WHERE user_id = (SELECT auth.uid())
                AND status = 'active'
                AND is_deleted = false
            ))
    )
);

CREATE POLICY "Organization members can update requirements"
ON public.requirements FOR ALL
TO public
USING (
    document_id IN (
        SELECT d.id FROM documents d
        JOIN projects p ON d.project_id = p.id
        WHERE
            (p.organization_id IN (
                SELECT organization_id FROM organization_members
                WHERE user_id = (SELECT auth.uid())
                AND status = 'active'
                AND is_deleted = false
            ))
            OR
            (p.id IN (
                SELECT project_id FROM project_members
                WHERE user_id = (SELECT auth.uid())
                AND status = 'active'
                AND is_deleted = false
            ))
    )
);

CREATE POLICY "Organization members can delete requirements"
ON public.requirements FOR ALL
TO public
USING (
    document_id IN (
        SELECT d.id FROM documents d
        JOIN projects p ON d.project_id = p.id
        WHERE
            (p.organization_id IN (
                SELECT organization_id FROM organization_members
                WHERE user_id = (SELECT auth.uid())
                AND status = 'active'
                AND is_deleted = false
            ))
            OR
            (p.id IN (
                SELECT project_id FROM project_members
                WHERE user_id = (SELECT auth.uid())
                AND status = 'active'
                AND is_deleted = false
            ))
    )
);

-- ============================================================================
-- FIX 6: columns
-- ============================================================================

DROP POLICY IF EXISTS "Org members can view columns" ON public.columns;
DROP POLICY IF EXISTS "Org members can update columns" ON public.columns;
DROP POLICY IF EXISTS "Org members can delete columns" ON public.columns;

CREATE POLICY "Org members can view columns"
ON public.columns FOR ALL
TO authenticated
USING (
    block_id IN (
        SELECT b.id FROM blocks b
        JOIN documents d ON b.document_id = d.id
        JOIN projects p ON d.project_id = p.id
        WHERE
            (p.organization_id IN (
                SELECT organization_id FROM organization_members
                WHERE user_id = (SELECT auth.uid())
                AND status = 'active'
                AND is_deleted = false
            ))
            OR
            (p.id IN (
                SELECT project_id FROM project_members
                WHERE user_id = (SELECT auth.uid())
                AND status = 'active'
                AND is_deleted = false
            ))
    )
);

CREATE POLICY "Org members can update columns"
ON public.columns FOR ALL
TO authenticated
USING (
    block_id IN (
        SELECT b.id FROM blocks b
        JOIN documents d ON b.document_id = d.id
        JOIN projects p ON d.project_id = p.id
        WHERE
            (p.organization_id IN (
                SELECT organization_id FROM organization_members
                WHERE user_id = (SELECT auth.uid())
                AND status = 'active'
                AND is_deleted = false
            ))
            OR
            (p.id IN (
                SELECT project_id FROM project_members
                WHERE user_id = (SELECT auth.uid())
                AND status = 'active'
                AND is_deleted = false
            ))
    )
);

CREATE POLICY "Org members can delete columns"
ON public.columns FOR ALL
TO authenticated
USING (
    block_id IN (
        SELECT b.id FROM blocks b
        JOIN documents d ON b.document_id = d.id
        JOIN projects p ON d.project_id = p.id
        WHERE
            (p.organization_id IN (
                SELECT organization_id FROM organization_members
                WHERE user_id = (SELECT auth.uid())
                AND status = 'active'
                AND is_deleted = false
            ))
            OR
            (p.id IN (
                SELECT project_id FROM project_members
                WHERE user_id = (SELECT auth.uid())
                AND status = 'active'
                AND is_deleted = false
            ))
    )
);

-- ============================================================================
-- FIX 7: properties
-- ============================================================================

DROP POLICY IF EXISTS "Org members can view properties" ON public.properties;
DROP POLICY IF EXISTS "Org members can update properties" ON public.properties;
DROP POLICY IF EXISTS "Org members can delete properties" ON public.properties;

CREATE POLICY "Org members can view properties"
ON public.properties FOR ALL
TO authenticated
USING (
    (document_id IN (
        SELECT d.id FROM documents d
        JOIN projects p ON d.project_id = p.id
        WHERE
            (p.organization_id IN (
                SELECT organization_id FROM organization_members
                WHERE user_id = (SELECT auth.uid())
                AND status = 'active'
                AND is_deleted = false
            ))
            OR
            (p.id IN (
                SELECT project_id FROM project_members
                WHERE user_id = (SELECT auth.uid())
                AND status = 'active'
                AND is_deleted = false
            ))
    ))
    OR
    (project_id IN (
        SELECT p.id FROM projects p
        WHERE
            (p.organization_id IN (
                SELECT organization_id FROM organization_members
                WHERE user_id = (SELECT auth.uid())
                AND status = 'active'
                AND is_deleted = false
            ))
            OR
            (p.id IN (
                SELECT project_id FROM project_members
                WHERE user_id = (SELECT auth.uid())
                AND status = 'active'
                AND is_deleted = false
            ))
    ))
    OR
    (org_id IN (
        SELECT organization_id FROM organization_members
        WHERE user_id = (SELECT auth.uid())
        AND status = 'active'
        AND is_deleted = false
    ))
);

CREATE POLICY "Org members can update properties"
ON public.properties FOR ALL
TO authenticated
USING (
    (document_id IN (
        SELECT d.id FROM documents d
        JOIN projects p ON d.project_id = p.id
        WHERE
            (p.organization_id IN (
                SELECT organization_id FROM organization_members
                WHERE user_id = (SELECT auth.uid())
                AND status = 'active'
                AND is_deleted = false
            ))
            OR
            (p.id IN (
                SELECT project_id FROM project_members
                WHERE user_id = (SELECT auth.uid())
                AND status = 'active'
                AND is_deleted = false
            ))
    ))
    OR
    (project_id IN (
        SELECT p.id FROM projects p
        WHERE
            (p.organization_id IN (
                SELECT organization_id FROM organization_members
                WHERE user_id = (SELECT auth.uid())
                AND status = 'active'
                AND is_deleted = false
            ))
            OR
            (p.id IN (
                SELECT project_id FROM project_members
                WHERE user_id = (SELECT auth.uid())
                AND status = 'active'
                AND is_deleted = false
            ))
    ))
    OR
    (org_id IN (
        SELECT organization_id FROM organization_members
        WHERE user_id = (SELECT auth.uid())
        AND status = 'active'
        AND is_deleted = false
    ))
);

CREATE POLICY "Org members can delete properties"
ON public.properties FOR ALL
TO authenticated
USING (
    (document_id IN (
        SELECT d.id FROM documents d
        JOIN projects p ON d.project_id = p.id
        WHERE
            (p.organization_id IN (
                SELECT organization_id FROM organization_members
                WHERE user_id = (SELECT auth.uid())
                AND status = 'active'
                AND is_deleted = false
            ))
            OR
            (p.id IN (
                SELECT project_id FROM project_members
                WHERE user_id = (SELECT auth.uid())
                AND status = 'active'
                AND is_deleted = false
            ))
    ))
    OR
    (project_id IN (
        SELECT p.id FROM projects p
        WHERE
            (p.organization_id IN (
                SELECT organization_id FROM organization_members
                WHERE user_id = (SELECT auth.uid())
                AND status = 'active'
                AND is_deleted = false
            ))
            OR
            (p.id IN (
                SELECT project_id FROM project_members
                WHERE user_id = (SELECT auth.uid())
                AND status = 'active'
                AND is_deleted = false
            ))
    ))
    OR
    (org_id IN (
        SELECT organization_id FROM organization_members
        WHERE user_id = (SELECT auth.uid())
        AND status = 'active'
        AND is_deleted = false
    ))
);

COMMIT;
