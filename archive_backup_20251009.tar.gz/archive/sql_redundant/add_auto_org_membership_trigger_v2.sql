-- Auto-add creator as organization owner when org is created
-- This ensures RLS policies work correctly for project creation

-- Step 1: Drop existing trigger if it exists
DROP TRIGGER IF EXISTS trigger_auto_add_org_owner ON organizations;

-- Step 2: Drop existing function if it exists
DROP FUNCTION IF EXISTS auto_add_org_owner();

-- Step 3: Create function to add creator as organization owner
CREATE FUNCTION auto_add_org_owner()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
    -- Insert creator as owner in organization_members
    INSERT INTO organization_members (
        organization_id,
        user_id,
        role,
        status,
        is_deleted,
        created_by,
        updated_by
    ) VALUES (
        NEW.id,
        NEW.created_by,
        'owner',
        'active',
        false,
        NEW.created_by,
        NEW.created_by
    )
    ON CONFLICT (organization_id, user_id)
    DO UPDATE SET
        role = EXCLUDED.role,
        status = 'active',
        is_deleted = false,
        updated_at = now(),
        updated_by = EXCLUDED.updated_by;

    RETURN NEW;
END;
$$;

-- Step 4: Create trigger
CREATE TRIGGER trigger_auto_add_org_owner
    AFTER INSERT ON organizations
    FOR EACH ROW
    EXECUTE FUNCTION auto_add_org_owner();

-- Step 5: Grant necessary permissions
GRANT EXECUTE ON FUNCTION auto_add_org_owner() TO authenticated;
