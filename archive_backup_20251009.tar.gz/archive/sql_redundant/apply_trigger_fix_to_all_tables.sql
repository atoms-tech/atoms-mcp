-- Apply the handle_updated_by fix to all tables that use it
-- This is the same fix we applied to organizations table

-- The fix: Only update updated_by when auth context is available
-- Otherwise preserve the existing value

-- Step 1: Check which tables have the tr_update_* trigger
SELECT
    t.tgrelid::regclass AS table_name,
    t.tgname AS trigger_name,
    p.proname AS function_name
FROM pg_trigger t
JOIN pg_proc p ON t.tgfoid = p.oid
WHERE p.proname = 'handle_updated_by'
ORDER BY t.tgrelid::regclass;

-- Step 2: The handle_updated_by function is SHARED across all tables
-- So we only need to fix it once, and all tables using it will benefit

-- This is the fix we already applied (verify it's in place):
SELECT pg_get_functiondef(oid)
FROM pg_proc
WHERE proname = 'handle_updated_by';

-- If the function still has the old code (unconditional new.updated_by = auth.uid()),
-- run this to fix it:

CREATE OR REPLACE FUNCTION public.handle_updated_by()
RETURNS trigger
LANGUAGE plpgsql
AS $function$
begin
    -- Always update timestamp
    new.updated_at = timezone('utc'::text, now());

    -- Only update updated_by if:
    -- 1. It was explicitly changed, OR
    -- 2. We have an auth context (auth.uid() is not null)
    -- Otherwise, preserve the existing value
    IF new.updated_by IS DISTINCT FROM old.updated_by THEN
        -- User explicitly changed it, keep it
        NULL;
    ELSIF auth.uid() IS NOT NULL THEN
        -- Auth context available, update it
        new.updated_by = auth.uid();
    ELSE
        -- No auth context (e.g., during backfills), preserve existing
        new.updated_by = old.updated_by;
    END IF;

    -- Handle soft delete
    if (new.is_deleted = true and old.is_deleted = false) then
        new.deleted_at = timezone('utc'::text, now());
        -- Only set deleted_by if we have auth context
        if auth.uid() IS NOT NULL then
            new.deleted_by = auth.uid();
        else
            new.deleted_by = old.updated_by; -- Use the user who last updated
        end if;
    elsif (new.is_deleted = false and old.is_deleted = true) then
        new.deleted_at = null;
        new.deleted_by = null;
    end if;

    return new;
end;
$function$;

-- Step 3: Verify all tables can now update embeddings without auth context
-- Test on documents table
UPDATE documents
SET embedding = array_fill(0.0, ARRAY[768])::vector
WHERE id = (SELECT id FROM documents WHERE embedding IS NULL LIMIT 1);

-- Check the result
SELECT id, title, updated_by, embedding IS NOT NULL as has_embedding
FROM documents
WHERE embedding IS NOT NULL
ORDER BY updated_at DESC
LIMIT 3;
