"""Comprehensive test suite for relationship_tool.

Tests all relationship types (member, assignment, trace_link, requirement_test, invitation)
and all operations (link, unlink, list, check, update) with various scenarios including:
- Bidirectional relationships
- Source context handling
- Metadata handling
- Filtering and pagination
- Error cases (duplicate links, invalid entities)
- Soft/hard delete behavior
- Cascading behavior

Run with: pytest tests/test_relationship_tool.py -v -s
"""

from __future__ import annotations

import os
import time
import uuid
from typing import Any, Dict, List, Optional

import httpx
import pytest

MCP_BASE_URL = os.getenv("ATOMS_FASTMCP_BASE_URL", "http://127.0.0.1:8000")
MCP_PATH = os.getenv("ATOMS_FASTMCP_HTTP_PATH", "/api/mcp")
TEST_EMAIL = os.getenv("ATOMS_TEST_EMAIL", "kooshapari@kooshapari.com")
TEST_PASSWORD = os.getenv("ATOMS_TEST_PASSWORD", "118118")

pytestmark = [pytest.mark.asyncio, pytest.mark.http]

# Supabase JWT fixture removed - using AuthKit OAuth only