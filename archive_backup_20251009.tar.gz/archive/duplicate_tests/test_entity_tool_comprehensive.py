"""Comprehensive test suite for entity_tool covering all operations and entity types.

This test suite validates:
1. CREATE operations with auto context and explicit IDs
2. READ operations with/without relations
3. UPDATE operations
4. DELETE operations (soft and hard)
5. SEARCH operations with filters and terms
6. LIST operations with pagination
7. BATCH operations
8. Error cases and edge conditions

Entity types covered:
- organization
- project
- document
- requirement
- test
- property

Run with: pytest tests/test_entity_tool_comprehensive.py -v -s
"""

from __future__ import annotations

import os
import time
import uuid
import json
from typing import Any, Dict, List, Optional
from datetime import datetime, timezone

import httpx
import pytest

MCP_BASE_URL = os.getenv("ATOMS_FASTMCP_BASE_URL", "http://127.0.0.1:8000")
MCP_PATH = os.getenv("ATOMS_FASTMCP_HTTP_PATH", "/api/mcp")
TEST_EMAIL = os.getenv("ATOMS_TEST_EMAIL", "kooshapari@kooshapari.com")
TEST_PASSWORD = os.getenv("ATOMS_TEST_PASSWORD", "118118")

pytestmark = [pytest.mark.asyncio, pytest.mark.http]

class TestResults:
    """Track test results for matrix generation."""

    def __init__(self):
        self.results = {}
        self.performance = {}
        self.issues = []

    def record(self, entity_type: str, operation: str, status: str,
               duration_ms: float, notes: str = ""):
        """Record a test result."""
        if entity_type not in self.results:
            self.results[entity_type] = {}

        self.results[entity_type][operation] = {
            "status": status,
            "duration_ms": duration_ms,
            "notes": notes
        }

    def add_issue(self, entity_type: str, operation: str, issue: str):
        """Record an issue discovered during testing."""
        self.issues.append({
            "entity_type": entity_type,
            "operation": operation,
            "issue": issue,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })

    def generate_matrix_report(self) -> str:
        """Generate a comprehensive test matrix report."""
        operations = ["create", "read", "update", "delete", "search", "list", "batch"]
        entity_types = sorted(self.results.keys())

        # Build matrix table
        report = ["# Entity Tool Comprehensive Test Matrix Report\n"]
        report.append(f"Generated: {datetime.now(timezone.utc).isoformat()}\n\n")

        # Summary statistics
        total_tests = sum(len(ops) for ops in self.results.values())
        passed = sum(1 for ops in self.results.values()
                    for result in ops.values() if result["status"] == "PASS")
        failed = total_tests - passed

        report.append(f"## Summary\n")
        report.append(f"- Total Tests: {total_tests}\n")
        report.append(f"- Passed: {passed}\n")
        report.append(f"- Failed: {failed}\n")
        report.append(f"- Pass Rate: {(passed/total_tests*100):.1f}%\n\n")

        # Matrix table
        report.append("## Test Matrix\n\n")
        report.append("| Entity Type | " + " | ".join(operations) + " |\n")
        report.append("|" + "-" * 15 + "|" + "|".join(["-" * 10 for _ in operations]) + "|\n")

        for entity_type in entity_types:
            row = [entity_type]
            for op in operations:
                result = self.results[entity_type].get(op, {})
                status = result.get("status", "N/A")
                emoji = "✅" if status == "PASS" else "❌" if status == "FAIL" else "⏭️"
                row.append(f"{emoji} {status}")
            report.append("| " + " | ".join(row) + " |\n")

        # Performance notes
        report.append("\n## Performance Analysis\n\n")
        for entity_type in entity_types:
            report.append(f"### {entity_type}\n")
            for op, result in self.results[entity_type].items():
                duration = result["duration_ms"]
                report.append(f"- **{op}**: {duration:.2f}ms\n")

        # Issues and edge cases
        if self.issues:
            report.append("\n## Issues Discovered\n\n")
            for issue in self.issues:
                report.append(f"- **{issue['entity_type']}.{issue['operation']}**: {issue['issue']}\n")

        # Detailed results
        report.append("\n## Detailed Results\n\n")
        for entity_type in entity_types:
            report.append(f"### {entity_type}\n\n")
            for op, result in self.results[entity_type].items():
                report.append(f"- **{op}**: {result['status']} ({result['duration_ms']:.2f}ms)")
                if result.get("notes"):
                    report.append(f" - {result['notes']}")
                report.append("\n")

        return "".join(report)

# Global test results tracker
test_results = TestResults()

# Supabase JWT fixture removed - using AuthKit OAuth only